function showElement(id){
    document.getElementById(id).style.display = 'block';
}
          
function hideElement(id){
    document.getElementById(id).style.display = 'none';
}

function showOrHideTypeBienFields(element){

    var selectedItem = element.options[element.selectedIndex].value;

    if(selectedItem == constant ('TYPE_BIEN_APPARTEMENT',ReferenceData) ){
        showElement('divNombreChambres');
        hideElement('divSurface');
        document.getElementById('{{ form.surfaceMin.vars.id }}').value = "";
        document.getElementById('{{ form.surfaceMax.vars.id }}').value = "";
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_MAISON',ReferenceData)){
        showElement('divNombreChambres');
        hideElement('divSurface');
        document.getElementById('{{ form.surfaceMin.vars.id }}').value = "";
        document.getElementById('{{ form.surfaceMax.vars.id }}').value = "";
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_STUDIO',ReferenceData)){
        hideElement('divNombreChambres');
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;
        hideElement('divSurface');
        document.getElementById('{{ form.surfaceMin.vars.id }}').value = "";
        document.getElementById('{{ form.surfaceMax.vars.id }}').value = "";
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_TERRAIN',ReferenceData)){
        showElement('divSurface');
        hideElement('divNombreChambres');
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;

        document.getElementById("{{ form.typeTransaction.vars.id ~ '_1' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_BLOC_TERRAIN',ReferenceData)){
        hideElement('divSurface');
        document.getElementById('{{ form.surfaceMin.vars.id }}').value = "";
        document.getElementById('{{ form.surfaceMax.vars.id }}').value = "";
        hideElement('divNombreChambres');
        document.getElementById('{{ form.nombreChambres.vars.id }}').value = -1;
        document.getElementById('monnaiePrix').innerHTML = 'F/m2';
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;

        document.getElementById("{{ form.typeTransaction.vars.id ~ '_1' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_BOUTIQUE',ReferenceData)){
        showElement('divSurface');
        hideElement('divNombreChambres');
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_MAGASIN',ReferenceData)){
        showElement('divSurface');
        hideElement('divNombreChambres');
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
    if(selectedItem == constant ('TYPE_BIEN_ENTREPOT',ReferenceData)){
        showElement('divSurface');
        hideElement('divNombreChambres');
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById('{{ form.nombreChambres.vars.id }}').selectedIndex = 0;
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }

    if(selectedItem == constant ('TYPE_BIEN_BUREAU',ReferenceData)){
        showElement('divSurface');
        hideElement('divNombreChambres');
        document.getElementById('monnaiePrix').innerHTML = '';
        document.getElementById('nombreChambres').selectedIndex = 0;
        document.getElementById("{{ form.typeTransaction.vars.id ~ '_0' }}").checked = true;
    }
}

    <script src="http://platform.twitter.com/widgets.js" type="text/javascript"></script>
