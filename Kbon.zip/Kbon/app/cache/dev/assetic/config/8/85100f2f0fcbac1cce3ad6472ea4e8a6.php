<?php

// KoutchoumiFrontendBundle::generateLatestAds.rss.twig
return array (
);
