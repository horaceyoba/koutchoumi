<?php

// KoutchoumiFrontendBundle::_shortViewMagasin.html.twig
return array (
  '4e4cb77' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/images/newsletter_icon.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/4e4cb77.png',
      'name' => '4e4cb77',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'ab6e7da' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/images/facebook_logo.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/ab6e7da.png',
      'name' => 'ab6e7da',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'f27ced3' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/css/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/f27ced3.css',
      'name' => 'f27ced3',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '99403f3' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/images/fr/logo_ban.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/99403f3.png',
      'name' => '99403f3',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
