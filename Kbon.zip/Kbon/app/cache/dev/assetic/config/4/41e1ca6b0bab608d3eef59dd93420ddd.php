<?php

// KoutchoumiFrontendBundle::detailsBien.html.twig
return array (
);
