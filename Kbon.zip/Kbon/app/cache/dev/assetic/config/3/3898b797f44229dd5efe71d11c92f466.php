<?php

// KoutchoumiFrontendBundle::getContacts.html.twig
return array (
);
