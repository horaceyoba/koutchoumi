<?php

// KoutchoumiFrontendBundle::error404.html.twig
return array (
);
