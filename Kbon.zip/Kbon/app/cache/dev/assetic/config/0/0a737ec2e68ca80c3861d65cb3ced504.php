<?php

// KoutchoumiFrontendBundle::index.html.twig
return array (
  '4e4cb77' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/images/newsletter_icon.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/4e4cb77.png',
      'name' => '4e4cb77',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'ab6e7da' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/images/facebook_logo.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/ab6e7da.png',
      'name' => 'ab6e7da',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '11f0b70' => 
  array (
    0 => 
    array (
      0 => '@libraries',
      1 => '@KoutchoumiFrontendBundle/Resources/public/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/11f0b70.js',
      'name' => '11f0b70',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
