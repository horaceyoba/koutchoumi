<?php

// KoutchoumiUtilisateurBundle:Default:index.html.twig
return array (
);
