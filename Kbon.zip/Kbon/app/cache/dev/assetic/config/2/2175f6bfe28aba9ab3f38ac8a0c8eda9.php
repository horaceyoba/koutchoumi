<?php

// KoutchoumiUtilisateurBundle:Main:updateBien.html.twig
return array (
  'f27ced3' => 
  array (
    0 => 
    array (
      0 => '@KoutchoumiFrontendBundle/Resources/public/css/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/f27ced3.css',
      'name' => 'f27ced3',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
