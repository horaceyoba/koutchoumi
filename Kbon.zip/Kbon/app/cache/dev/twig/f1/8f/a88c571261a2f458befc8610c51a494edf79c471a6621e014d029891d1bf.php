<?php

/* KoutchoumiFrontendBundle::_bloc_contact_annonceur.html.twig */
class __TwigTemplate_f18fa88c571261a2f458befc8610c51a494edf79c471a6621e014d029891d1bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div style=\"float:left;margin-top:5px;\">
    <div style=\"float: left\">
        <p style=\"font-size: 16px; \"><strong>";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "annonceur"), "nom"), "html", null, true);
        echo "</strong></p>
        <p>[";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "annonceur"), "profil"), "libelle"), "html", null, true);
        echo ", <a id=\"conditions-annonceur\" href=\"javascript:void(0)\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("consulter ses conditions"), "html", null, true);
        echo "</a>]</p>
        
        <p style=\"margin-top: 5px\"> <strong>> ";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Besoin de plus d'infos ?"), "html", null, true);
        echo " </strong><a id=\"question-annonceur\" href=\"javascript:void(0)\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Posez vos questions"), "html", null, true);
        echo "</a>.</p>
        <p style=\"margin-top: 5px\"> <strong>> ";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Intéréssé(e) ?"), "html", null, true);
        echo " </strong><a id=\"contact-annonceur\" href=\"javascript:void(0)\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Programmez une visite"), "html", null, true);
        echo "</a>.</p>
        <p style=\"margin-top: 5px\"> <strong>> ";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Ou mieux..."), "html", null, true);
        echo "</strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Appelez directement l'annonceur"), "html", null, true);
        echo " :</p>
        <p style=\"font-size: 20px; color: #999; text-align: center\"> <strong>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "annonceur"), "numeroTelephone"), "html", null, true);
        echo "</strong></p>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_bloc_contact_annonceur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 9,  46 => 8,  40 => 7,  34 => 6,  27 => 4,  23 => 3,  80 => 19,  75 => 17,  71 => 16,  67 => 15,  63 => 14,  59 => 13,  55 => 12,  50 => 11,  45 => 9,  41 => 8,  37 => 7,  33 => 6,  29 => 5,  24 => 4,  22 => 3,  19 => 1,);
    }
}
