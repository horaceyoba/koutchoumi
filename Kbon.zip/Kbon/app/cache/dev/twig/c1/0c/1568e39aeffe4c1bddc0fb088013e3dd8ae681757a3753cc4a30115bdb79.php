<?php

/* KoutchoumiFrontendBundle::_detailsBienAppartement.html.twig */
class __TwigTemplate_c10c1568e39aeffe4c1bddc0fb088013e3dd8ae681757a3753cc4a30115bdb79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    ";
        // line 2
        echo "
    ";
        // line 3
        $context["ville"] = $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "ville"), "nom");
        // line 4
        echo "    ";
        $context["quartier"] = $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "nom");
        // line 5
        echo "    ";
        $context["surface"] = twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surface"), 0, ".", " ");
        // line 6
        echo "    ";
        $context["prix"] = twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "prix"), 0, ".", " ");
        // line 7
        echo "    ";
        $context["nombreChambres"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreChambres");
        // line 8
        echo "    ";
        $context["typeTransaction"] = $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method");
        // line 9
        echo "    ";
        $context["caution_Avance"] = null;
        // line 10
        echo "

<div id=\"vue_left\">
    <div>
      <p><span class=\"span_to_block10\">";
        // line 14
        echo twig_escape_filter($this->env, $this->getContext($context, "ville"), "html", null, true);
        echo " / ";
        echo twig_escape_filter($this->env, $this->getContext($context, "quartier"), "html", null, true);
        echo "</span></p>
    </div>
    <div class=\"\">
        <h1 class=\"label_index\" style=\"display: inline\">
            ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Appartement"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "typeTransaction"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("à %CITY%"), array("%CITY%" => $this->getContext($context, "ville"))), "html", null, true);
        echo "
        </h1> |
        <span class=\"label_index\">
            ";
        // line 21
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("{1} 1 chambre|]1,+Inf] %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
        // line 24
        echo "        </span> |
        <span class=\"span_to_block10\">
            <span class=\"span_to_block10\">";
        // line 26
        echo twig_escape_filter($this->env, $this->getContext($context, "prix"), "html", null, true);
        echo " Fcfa</span>
        </span>
    </div>
    <em>
        ";
        // line 30
        $context["dateDiff"] = $this->env->getExtension('usermanager_extension')->dateDiffInPlainText(twig_date_format_filter($this->env, "now", "Y-m-d"), twig_date_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "datePublication"), "Y-m-d"));
        // line 31
        echo "        ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("publié"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "dateDiff"), "html", null, true);
        echo " - ";
        echo strtr($this->env->getExtension('translator')->trans("vu <strong>%1%</strong> fois"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreHits")));
        echo "
    </em>
<div class=\"hr\"> </div>
<div style=\"margin-bottom: 10px\">
        <div id=\"infos_cles\" class=\"margin9\" style=\"margin-top: 10px\">
            <div style=\"float: left; width: 200px\">
                ";
        // line 37
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_photos_bien.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
        echo "
            </div>

            <div style=\"margin-left: 210px;width: auto\">
                <p>";
        // line 41
        echo ">";
        echo " <strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Appartement"), "html", null, true);
        echo " ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "avecClimatiseur") != null)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("climatisé"), "html", null, true);
            echo " ";
        }
        // line 42
        echo "                ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method"), "html", null, true);
        echo "
                ";
        // line 43
        echo twig_escape_filter($this->env, strtr("à %CITY%", array("%CITY%" => $this->getContext($context, "ville"))), "html", null, true);
        echo ",";
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "quartier"), "html", null, true);
        echo "</strong>
        ";
        // line 44
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "secteur") != null)) {
            // line 45
            echo "            ";
            echo ",";
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "secteur"), "html", null, true);
        }
        // line 46
        echo "                </p>
                <p>";
        // line 47
        echo ">";
        echo " <strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Loyer"), "html", null, true);
        echo " </strong>:
            ";
        // line 48
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction") == twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")))) {
            // line 49
            echo "            ";
            echo twig_escape_filter($this->env, $this->getContext($context, "prix"), "html", null, true);
            echo " Fcfa /";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("mois"), "html", null, true);
            echo "

                ";
            // line 51
            if ((($this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction") == twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData"))) && ($this->getAttribute($this->getContext($context, "bienImmo"), "nombreMoisAavancer") != 0))) {
                echo " 
                    | ";
                // line 52
                echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("%1% mois d'avance"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreMoisAAvancer"))), "html", null, true);
                echo "
                ";
            }
            // line 54
            echo "
                ";
            // line 55
            if (((($this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction") == twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData"))) && ($this->getAttribute($this->getContext($context, "bienImmo"), "caution") != null)) && ($this->getAttribute($this->getContext($context, "bienImmo"), "prix") > 0))) {
                // line 56
                echo "                ";
                $context["nbremoisCaution"] = ($this->getAttribute($this->getContext($context, "bienImmo"), "caution") / $this->getAttribute($this->getContext($context, "bienImmo"), "prix"));
                // line 57
                echo "                    | ";
                echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("%1% mois de caution"), array("%1%" => $this->getContext($context, "nbremoisCaution"))), "html", null, true);
                echo ".
                ";
            }
            // line 59
            echo "
        ";
        }
        // line 61
        echo "
            ";
        // line 62
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction") == twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")))) {
            // line 63
            echo "            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Prix de vente"), "html", null, true);
            echo " : ";
            echo twig_escape_filter($this->env, $this->getContext($context, "prix"), "html", null, true);
            echo " Fcfa
            ";
        }
        // line 65
        echo "                </p>
                <p>";
        // line 66
        echo ">";
        echo " <strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pièces"), "html", null, true);
        echo "</strong> :
                ";
        // line 67
        $context["nombreSalons"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSalons");
        // line 68
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salon| %nombreSalons% salons", $this->getContext($context, "nombreSalons"), array("%nombreSalons%" => $this->getContext($context, "nombreSalons")), "messages");
        // line 71
        echo "                ";
        echo ",";
        echo "
                ";
        // line 72
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 chambre| %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
        // line 75
        echo "                ";
        echo ",";
        echo "
                ";
        // line 76
        $context["nombreSallesBains"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSallesDeBains");
        // line 77
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salle de bains| %nombreSallesBains% salles de bains", $this->getContext($context, "nombreSallesBains"), array("%nombreSallesBains%" => $this->getContext($context, "nombreSallesBains")), "messages");
        // line 80
        echo "                ";
        echo ",";
        echo "
                ";
        // line 81
        $context["nombreCuisines"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreCuisines");
        // line 82
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 cuisine| %nombreCuisines% cuisines", $this->getContext($context, "nombreCuisines"), array("%nombreCuisines%" => $this->getContext($context, "nombreCuisines")), "messages");
        // line 85
        echo "                <p>";
        echo ">";
        echo " <strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Gardien"), "html", null, true);
        echo "</strong> :
                    
                    ";
        // line 87
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_PAS_DE_GARDIEN", $this->getContext($context, "ReferenceData")))) {
            // line 88
            echo "                            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pas de gardien"), "html", null, true);
            echo "
                    ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_NUIT_UNIQUEMENT", $this->getContext($context, "ReferenceData")))) {
            // line 90
            echo "                            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Nuit uniquement"), "html", null, true);
            echo "
                    ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_24_SUR_24", $this->getContext($context, "ReferenceData")))) {
            // line 92
            echo "                            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("24/24"), "html", null, true);
            echo "
                    ";
        }
        // line 94
        echo "                </p>
                <p>";
        // line 95
        echo ">";
        echo " <strong>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Parking"), "html", null, true);
        echo "</strong> :
                    ";
        // line 96
        if ($this->getAttribute($this->getContext($context, "bienImmo"), "avecParkings")) {
            // line 97
            echo "                        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Oui"), "html", null, true);
            echo "
                    ";
        } else {
            // line 99
            echo "                        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Non"), "html", null, true);
            echo "
                    ";
        }
        // line 101
        echo "                </p>
                ";
        // line 102
        if ((($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") == 0) && ($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") != null))) {
            // line 103
            echo "                    <p>";
            echo ">";
            echo " <strong>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Situé en bordure de route"), "html", null, true);
            echo "</strong>
                ";
        } else {
            // line 105
            echo "                    ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") > 0)) {
                // line 106
                echo "                        <p>";
                echo ">";
                echo " <strong>";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Distance de la route principale"), "html", null, true);
                echo "</strong> ";
                echo ":";
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute"), "html", null, true);
                echo " m</p>
                    ";
            }
            // line 108
            echo "                ";
        }
        // line 109
        echo "            </div>
            <div style=\"clear: both\"></div>
        </div>

    <div id=\"tabs\" class=\"ui-tabs\">

\t<ul>
            <li><a href=\"#tabs-1\" style=\"padding-bottom: 0.1em;padding-top: 0.1em\">";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pièces"), "html", null, true);
        echo "</a></li>
            <li><a href=\"#tabs-2\" style=\"padding-bottom: 0.1em;padding-top: 0.1em\">";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Sécurité"), "html", null, true);
        echo "</a></li>
            <li><a href=\"#tabs-3\" style=\"padding-bottom: 0.1em;padding-top: 0.1em\">";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Accessibilité"), "html", null, true);
        echo "</a></li>
            <li><a href=\"#tabs-4\" style=\"padding-bottom: 0.1em;padding-top: 0.1em\">";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Autres Informations"), "html", null, true);
        echo "</a></li>
\t</ul>

    <div id=\"tabs-1\" class=\"ui-tabs-hide\">
    <ul>
        <li>";
        // line 124
        echo ">";
        echo " 
                ";
        // line 125
        $context["nombreSalons"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSalons");
        // line 126
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salon| %nombreSalons% salons", $this->getContext($context, "nombreSalons"), array("%nombreSalons%" => $this->getContext($context, "nombreSalons")), "messages");
        // line 129
        echo "                ";
        echo ",";
        echo "
                ";
        // line 130
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 chambre| %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
        // line 133
        echo "                ";
        echo ",";
        echo "
                ";
        // line 134
        $context["nombreSallesDeBains"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSallesDeBains");
        // line 135
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salle de bains| %nombreSallesDeBains% salles de bains", $this->getContext($context, "nombreSallesDeBains"), array("%nombreSallesDeBains%" => $this->getContext($context, "nombreSallesDeBains")), "messages");
        // line 138
        echo "                ";
        echo ",";
        echo "
                ";
        // line 139
        $context["nombreCuisines"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreCuisines");
        // line 140
        echo "                ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 cuisine| %nombreCuisines% cuisines", $this->getContext($context, "nombreCuisines"), array("%nombreCuisines%" => $this->getContext($context, "nombreCuisines")), "messages");
        // line 143
        echo "        </li>
        ";
        // line 144
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "surface") != 0)) {
            // line 145
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Surface"), "html", null, true);
            echo ": ";
            echo twig_escape_filter($this->env, $this->getContext($context, "surface"), "html", null, true);
            echo " m<sup>2</sup></li>
        ";
        }
        // line 147
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "surfaceHabitable") != 0)) {
            // line 148
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Surface habitable"), "html", null, true);
            echo ": ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surfaceHabitable"), "html", null, true);
            echo " m<sup>2</sup></li>
        ";
        }
        // line 150
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "isMeuble") != null)) {
            // line 151
            echo "            <li> ";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Meublé"), "html", null, true);
            echo "
                ";
            // line 152
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "mobilierDisponible") != null)) {
                // line 153
                echo "                    ";
                echo ":";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "mobilierDisponible"), "html", null, true);
                echo "
                ";
            }
            // line 155
            echo "            </li>
        ";
        }
        // line 157
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "autresInfosSurChambres") != null)) {
            // line 158
            echo "            <li> ";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Autres infos sur les chambres"), "html", null, true);
            echo " <span class=\"translationServiceBranding\"></span>:
                <div>";
            // line 159
            echo "</div>
            </li>
        ";
        }
        // line 162
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "autresInfosSallesDeBains") != null)) {
            // line 163
            echo "            <li> > ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Autres infos sur les salles de bains"), "html", null, true);
            echo " <span class=\"translationServiceBranding\"></span>:
                <div>";
            // line 164
            echo "</div>
            </li>
        ";
        }
        // line 167
        echo "
        ";
        // line 168
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "avecBalcon") != null)) {
            // line 169
            echo "            ";
            if ($this->getAttribute($this->getContext($context, "bienImmo"), "avecBalcon")) {
                // line 170
                echo "                <li>";
                echo ">";
                echo " ";
                echo $this->env->getExtension('translator')->getTranslator()->trans("Présence d'un balcon", array(), "messages");
                echo "</li>
            ";
            } else {
                // line 172
                echo "                <li>";
                echo ">";
                echo " ";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pas de balcon"), "html", null, true);
                echo "</li>
            ";
            }
            // line 174
            echo "         ";
        }
        // line 175
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "etatSol") != twig_constant("ETAT_SOL_NOTDEFINED", $this->getContext($context, "ReferenceData")))) {
            // line 176
            echo "        <li>";
            echo ">";
            echo " 
                ";
            // line 177
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "etatSol") == twig_constant("ETAT_SOL_CARRELE", $this->getContext($context, "ReferenceData")))) {
                // line 178
                echo "                        ";
                $context["etatSol"] = $this->env->getExtension('translator')->trans("Sol carrelé");
                // line 179
                echo "                ";
            } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etatSol") == twig_constant("ETAT_SOL_CIMENTE", $this->getContext($context, "ReferenceData")))) {
                // line 180
                echo "                        ";
                $context["etatSol"] = $this->env->getExtension('translator')->trans("Sol cimenté");
                // line 181
                echo "                ";
            } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etatSol") == twig_constant("ETAT_SOL_ENMARBRE", $this->getContext($context, "ReferenceData")))) {
                // line 182
                echo "                        ";
                $context["etatSol"] = $this->env->getExtension('translator')->trans("Sol marbré");
                // line 183
                echo "                ";
            }
            // line 184
            echo "            ";
            echo twig_escape_filter($this->env, $this->getContext($context, "etatSol"), "html", null, true);
            echo "
        </li>
        ";
        }
        // line 187
        echo "

    </ul>
    </div>
    <div id=\"tabs-2\" class=\"ui-tabs-hide\">
    <ul>
        <li> >
        
        ";
        // line 195
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "situeDans") == twig_constant("SITUE_DANS_CITE", $this->getContext($context, "ReferenceData")))) {
            // line 196
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Situé dans une cité"), "html", null, true);
            echo "
        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "situeDans") == twig_constant("SITUE_DANS_VILLA", $this->getContext($context, "ReferenceData")))) {
            // line 198
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Situé dans une villa"), "html", null, true);
            echo "
        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "situeDans") == twig_constant("SITUE_DANS_IMMEUBLE", $this->getContext($context, "ReferenceData")))) {
            // line 200
            echo "                ";
            $context["stringToEcho"] = ($this->env->getExtension('translator')->trans("Situé dans un immeuble") . ".");
            // line 201
            echo "                ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "etatImmeuble") != twig_constant("ETAT_IMMEUBLE_NOTDEFINED", $this->getContext($context, "ReferenceData")))) {
                // line 202
                echo "                    ";
                $context["stringToEcho"] = (($this->getContext($context, "stringToEcho") . $this->env->getExtension('translator')->trans("Etat")) . " : ");
                // line 203
                echo "                    ";
                if (($this->getAttribute($this->getContext($context, "bienImmo"), "etatImmeuble") == twig_constant("ETAT_IMMEUBLE_EN_BON_ETAT", $this->getContext($context, "ReferenceData")))) {
                    // line 204
                    echo "                            ";
                    $context["stringToEcho"] = ($this->getContext($context, "stringToEcho") . $this->env->getExtension('translator')->trans("en bon état"));
                    // line 205
                    echo "                    ";
                } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etatImmeuble") == twig_constant("ETAT_IMMEUBLE_NEUF", $this->getContext($context, "ReferenceData")))) {
                    // line 206
                    echo "                            ";
                    $context["stringToEcho"] = ($this->getContext($context, "stringToEcho") . $this->env->getExtension('translator')->trans("neuf"));
                    // line 207
                    echo "                    ";
                } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etatImmeuble") == twig_constant("ETAT_IMMEUBLE_VETUSTE", $this->getContext($context, "ReferenceData")))) {
                    // line 208
                    echo "                            ";
                    $context["stringToEcho"] = ($this->getContext($context, "stringToEcho") . $this->env->getExtension('translator')->trans("vétuste"));
                    // line 209
                    echo "                    ";
                }
                // line 210
                echo "                    ";
                $context["stringToEcho"] = ($this->getContext($context, "stringToEcho") . ".");
                // line 211
                echo "                ";
            }
            // line 212
            echo "                ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "niveauDansImmeuble") > 0)) {
                // line 213
                echo "                    ";
                $context["stringToEcho"] = ($this->getContext($context, "stringToEcho") . strtr($this->env->getExtension('translator')->trans("Niveau %NIV_DS_IMMEUBLE%"), array("%NIV_DS_IMMEUBLE%" => $this->getAttribute($this->getContext($context, "bienImmo"), "niveauDansImmeuble"))));
                // line 214
                echo "                ";
            }
            // line 215
            echo "                ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "nombreNiveauxImmeuble") != null)) {
                // line 216
                echo "                    ";
                $context["stringToEcho"] = (($this->getContext($context, "stringToEcho") . " ") . strtr($this->env->getExtension('translator')->trans("sur %NBRE_NIV_IMMEUBLE%"), array("%NBRE_NIV_IMMEUBLE%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreNiveauxImmeuble"))));
                // line 217
                echo "                ";
            }
            // line 218
            echo "                ";
            echo twig_escape_filter($this->env, $this->getContext($context, "stringToEcho"), "html", null, true);
            echo "
         ";
        }
        // line 220
        echo "        </li>

        ";
        // line 222
        if ($this->getAttribute($this->getContext($context, "bienImmo"), "avecBarriere")) {
            // line 223
            echo "            <li>";
            echo ">";
            echo " ";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Présence d'une barrière", array(), "messages");
            echo "</li>
        ";
        } else {
            // line 225
            echo "            <li>";
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pas de barrière"), "html", null, true);
            echo "</li>
        ";
        }
        // line 227
        echo "
            <li> ";
        // line 228
        echo ">";
        echo " 
        ";
        // line 229
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_PAS_DE_GARDIEN", $this->getContext($context, "ReferenceData")))) {
            // line 230
            echo "                            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pas de gardien"), "html", null, true);
            echo "
        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_NUIT_UNIQUEMENT", $this->getContext($context, "ReferenceData")))) {
            // line 232
            echo "                            ";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Présence d'un gardien (nuit uniquement)", array(), "messages");
            // line 233
            echo "        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "gardien") == twig_constant("GARDIEN_24_SUR_24", $this->getContext($context, "ReferenceData")))) {
            // line 234
            echo "                            ";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Présence d'un gardien (24/24)", array(), "messages");
            // line 235
            echo "        ";
        }
        // line 236
        echo "        </li>
        ";
        // line 237
        if ($this->getAttribute($this->getContext($context, "bienImmo"), "avecParkings")) {
            // line 238
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Avec parking"), "html", null, true);
            echo "</li>
        ";
        } else {
            // line 240
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Pas de parking"), "html", null, true);
            echo "</li>
        ";
        }
        // line 242
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "autresDispositifsSecurite") != null)) {
            // line 243
            echo "            <li>";
            echo ">";
            echo " <";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Autres dispositifs de sécurité"), "html", null, true);
            echo " <span class=\"translationServiceBranding\"></span>:
                <div>";
            // line 244
            echo "</div>
            </li>
        ";
        }
        // line 247
        echo "    </ul>
    </div>

    <div id=\"tabs-3\" class=\"ui-tabs-hide\">
    <ul>
        ";
        // line 252
        if ((($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") != null) && ($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") == 0))) {
            // line 253
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Situé en bordure de route"), "html", null, true);
            echo "
        ";
        } else {
            // line 255
            echo "            ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") > 0)) {
                // line 256
                echo "                <li>";
                echo ">";
                echo " ";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Distance de la route principale"), "html", null, true);
                echo " ";
                echo ":";
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute"), "html", null, true);
                echo " m</li>
            ";
            }
            // line 258
            echo "            ";
            if (($this->getAttribute($this->getContext($context, "bienImmo"), "isAccessibleEnVoiture") == true)) {
                // line 259
                echo "                <li>";
                echo ">";
                echo " ";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Accessible en voiture"), "html", null, true);
                echo "</li>
            ";
            } else {
                // line 261
                echo "                <li>";
                echo ">";
                echo " ";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Accessible en voiture"), "html", null, true);
                echo " ";
                echo ":";
                echo " ";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Non"), "html", null, true);
                echo "</li>
            ";
            }
            // line 263
            echo "        ";
        }
        // line 264
        echo "    </ul>
    </div>
    <div id=\"tabs-4\" class=\"ui-tabs-hide\">
    <div>";
        // line 267
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Eau et électricité"), "html", null, true);
        echo "</div>
    <ul>
        ";
        // line 269
        if ($this->getAttribute($this->getContext($context, "bienImmo"), "isAlimenteParSnec")) {
            // line 270
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Alimenté en eau (SNEC)"), "html", null, true);
            echo "</li>
        ";
        } else {
            // line 272
            echo "            <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Non alimenté par la SNEC"), "html", null, true);
            echo "</li>
        ";
        }
        // line 274
        echo "
        <li>
            ";
        // line 276
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Mode de paiement eau"), "html", null, true);
        echo " ";
        echo ":";
        echo "
                ";
        // line 277
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "modePaiementEau") == twig_constant("MODE_PAIEMENT_CONSOMMATIONS", $this->getContext($context, "ReferenceData")))) {
            // line 278
            echo "                        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("sur consommations"), "html", null, true);
            echo "
                ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "modePaiementEau") == twig_constant("MODE_PAIEMENT_FORFAIT", $this->getContext($context, "ReferenceData")))) {
            // line 280
            echo "                        ";
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("forfait (%1% FCFA)"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "montantForfaitEau"))), "html", null, true);
            echo "
                ";
        }
        // line 282
        echo "        </li>
        <li>
            ";
        // line 284
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Mode de paiement électricité"), "html", null, true);
        echo " ";
        echo ":";
        echo "
            ";
        // line 285
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "modePaiementElectricite") == twig_constant("MODE_PAIEMENT_CONSOMMATIONS", $this->getContext($context, "ReferenceData")))) {
            // line 286
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("sur consommations"), "html", null, true);
            echo "
                ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "modePaiementElectricite") == twig_constant("MODE_PAIEMENT_FORFAIT", $this->getContext($context, "ReferenceData")))) {
            // line 288
            echo "                        ";
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("forfait (%1% FCFA)"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "montantForfaitElectricite"))), "html", null, true);
            echo "
                ";
        }
        // line 290
        echo "                
        </li>
    </ul>

    ";
        // line 294
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "autresInfos") != null)) {
            // line 295
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Informations complémentaires"), "html", null, true);
            echo " <span class=\"translationServiceBranding\"></span>";
            echo ":";
            echo "</div>
        <ul>
            <li><span class=\"margin-left\"> ";
            // line 297
            echo "</span></li>
        </ul>
    ";
        }
        // line 300
        echo "    </div>

   </div>
   </div>
    <div class=\"hr\"></div>
    <div style=\"margin-top: 10px\">
        <strong>";
        // line 306
        echo $this->env->getExtension('translator')->getTranslator()->trans("Contactez l'annonceur", array(), "messages");
        echo "</strong> ";
        echo ":";
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "annonceur"), "numeroTelephone"), "html", null, true);
        echo " |
        <a id=\"question-annonceur-2\" href=\"javascript:void(0)\">";
        // line 307
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Posez vos questions"), "html", null, true);
        echo "</a> |
        <a id=\"contact-annonceur-2\" href=\"javascript:void(0)\">";
        // line 308
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Programmez une visite"), "html", null, true);
        echo "</a>
    </div>
    ";
        // line 310
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_virality.html.twig", array("showText" => 1));
        echo "
</div>
";
        // line 312
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale") != "fr")) {
            // line 313
            echo "    
";
        }
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_detailsBienAppartement.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  882 => 313,  880 => 312,  875 => 310,  870 => 308,  866 => 307,  858 => 306,  850 => 300,  845 => 297,  837 => 295,  835 => 294,  829 => 290,  823 => 288,  817 => 286,  815 => 285,  807 => 284,  803 => 282,  797 => 280,  791 => 278,  789 => 277,  781 => 276,  777 => 274,  769 => 272,  761 => 270,  759 => 269,  754 => 267,  749 => 264,  746 => 263,  734 => 261,  726 => 259,  723 => 258,  711 => 256,  708 => 255,  700 => 253,  698 => 252,  691 => 247,  686 => 244,  679 => 243,  676 => 242,  668 => 240,  660 => 238,  658 => 237,  655 => 236,  652 => 235,  649 => 234,  646 => 233,  643 => 232,  637 => 230,  635 => 229,  631 => 228,  628 => 227,  621 => 225,  613 => 223,  611 => 222,  607 => 220,  601 => 218,  598 => 217,  595 => 216,  592 => 215,  589 => 214,  586 => 213,  583 => 212,  580 => 211,  577 => 210,  574 => 209,  571 => 208,  568 => 207,  565 => 206,  562 => 205,  559 => 204,  556 => 203,  553 => 202,  550 => 201,  547 => 200,  541 => 198,  535 => 196,  533 => 195,  523 => 187,  516 => 184,  513 => 183,  510 => 182,  507 => 181,  504 => 180,  501 => 179,  498 => 178,  496 => 177,  491 => 176,  488 => 175,  485 => 174,  477 => 172,  469 => 170,  466 => 169,  464 => 168,  461 => 167,  456 => 164,  451 => 163,  448 => 162,  443 => 159,  436 => 158,  433 => 157,  429 => 155,  422 => 153,  420 => 152,  413 => 151,  410 => 150,  400 => 148,  397 => 147,  387 => 145,  385 => 144,  382 => 143,  379 => 140,  377 => 139,  372 => 138,  369 => 135,  367 => 134,  362 => 133,  360 => 130,  355 => 129,  352 => 126,  350 => 125,  346 => 124,  338 => 119,  334 => 118,  330 => 117,  326 => 116,  317 => 109,  314 => 108,  302 => 106,  299 => 105,  291 => 103,  289 => 102,  286 => 101,  280 => 99,  274 => 97,  272 => 96,  266 => 95,  263 => 94,  257 => 92,  251 => 90,  245 => 88,  243 => 87,  235 => 85,  232 => 82,  230 => 81,  225 => 80,  222 => 77,  220 => 76,  215 => 75,  213 => 72,  208 => 71,  205 => 68,  203 => 67,  197 => 66,  194 => 65,  186 => 63,  184 => 62,  181 => 61,  177 => 59,  171 => 57,  168 => 56,  163 => 54,  158 => 52,  154 => 51,  144 => 48,  135 => 46,  129 => 45,  120 => 43,  105 => 41,  98 => 37,  84 => 31,  75 => 26,  71 => 24,  69 => 21,  59 => 18,  50 => 14,  44 => 10,  38 => 8,  35 => 7,  32 => 6,  29 => 5,  26 => 4,  24 => 3,  21 => 2,  19 => 1,  196 => 79,  189 => 74,  172 => 61,  170 => 60,  166 => 55,  160 => 56,  156 => 55,  150 => 52,  146 => 49,  142 => 49,  138 => 47,  133 => 44,  127 => 44,  124 => 41,  118 => 39,  115 => 42,  109 => 36,  106 => 35,  100 => 33,  97 => 32,  91 => 30,  88 => 29,  82 => 30,  79 => 26,  73 => 24,  70 => 23,  64 => 21,  61 => 20,  55 => 18,  53 => 17,  45 => 14,  41 => 9,  31 => 5,  28 => 2,);
    }
}
