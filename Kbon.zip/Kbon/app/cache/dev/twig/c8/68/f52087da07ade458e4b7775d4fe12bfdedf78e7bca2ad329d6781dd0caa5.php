<?php

/* KoutchoumiFrontendBundle::_photos_bien.html.twig */
class __TwigTemplate_c868f52087da07ade458e4b7775d4fe12bfdedf78e7bca2ad329d6781dd0caa5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div>
\t";
        // line 3
        echo "        ";
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale") != null)) {
            // line 4
            echo "                <img id=\"mainPhoto\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale"), "chemin"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "title"), "html", null, true);
            echo "\" width=\"197\" height=\"164\" />
        ";
        } else {
            // line 6
            echo "                <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/koutchoumifrontend/images/default_photo.png"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi Immobilier"), "html", null, true);
            echo "\" id=\"mainPhoto\" width=\"197\" height=\"164\"/>
        ";
        }
        // line 8
        echo "</div>
<div>
     ";
        // line 10
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "nombrePhotos") > 0)) {
            // line 11
            echo "        <div class=\"border\">
            ";
            // line 12
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getContext($context, "bienImmo"), "getPhotos", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
                // line 13
                echo "            <a href=\"javascript:setMainPhoto('";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "photo"), "chemin"), "html", null, true);
                echo "')\">
                <img src=\"";
                // line 14
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "photo"), "chemin"), "html", null, true);
                echo "\" width=\"40\" height=\"40\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "title"), "html", null, true);
                echo "\"/>
            </a>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "        </div>
      ";
        }
        // line 19
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_photos_bien.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 19,  70 => 17,  59 => 14,  54 => 13,  50 => 12,  47 => 11,  45 => 10,  41 => 8,  33 => 6,  25 => 4,  22 => 3,  19 => 1,);
    }
}
