<?php

/* KoutchoumiFrontendBundle::_showServicesAndFacilities.html.twig */
class __TwigTemplate_344b5504de4fd6427c9d42af9a5ed1a240fec23b013a72a116805980888513ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((twig_length_filter($this->env, $this->getContext($context, "servicesByType")) > 0)) {
            // line 2
            echo "<script type=\"text/javascript\">
    var accordion_expanded = false;
    \$(function() {
            \$(\"#accordion_services\").accordion();
            \$(\"#services\").hide();
            \$(\"#more_services\").click(function(){
                if(accordion_expanded){
                    accordion_expanded = false;
                    \$(\"#services\").hide();
                    \$(\"#more_services\").html(\"";
            // line 11
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Plus de détails"), "html", null, true);
            echo "\");
                } else{
                    accordion_expanded = true;
                    \$(\"#services\").show();
                    \$(\"#more_services\").html(\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Cacher détails"), "html", null, true);
            echo "\");
                }
            });
    });
</script>
<div style=\"float:left;margin-top:5px;\">
    <div style=\"float: left;\">
        ";
            // line 22
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getContext($context, "typesServicesInShortView"));
            foreach ($context['_seq'] as $context["_key"] => $context["typeService"]) {
                // line 23
                echo "            <img src=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "typeService"), "iconeUrl"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "typeService"), "nom"), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "typeService"), "nom"), "html", null, true);
                echo "\" width=\"40\" height=\"40\"/>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['typeService'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "        <a href=\"javascript:void(0)\" id=\"more_services\" >";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Plus de détails"), "html", null, true);
            echo "</a>
    </div>
    <div id=\"services\" style=\"float:left;\">
        <div id=\"accordion_services\" style=\"float:left;margin-bottom:5px;\">
            ";
            // line 29
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getContext($context, "servicesByType"));
            foreach ($context['_seq'] as $context["nomTypeService"] => $context["services"]) {
                // line 30
                echo "                <h3><a href=\"#\">";
                echo twig_escape_filter($this->env, $this->getContext($context, "nomTypeService"), "html", null, true);
                echo "</a></h3>
                <div>
                    ";
                // line 32
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getContext($context, "services"));
                foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
                    // line 33
                    echo "                    <p>";
                    echo ">";
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "service"), "nom"), "html", null, true);
                    echo " ";
                    echo "-";
                    echo " <em>";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "service"), "localisation"), "html", null, true);
                    echo "</em></p>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 35
                echo "                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['nomTypeService'], $context['services'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 37
            echo "        </div>
        <div style=\"margin-bottom:5px;margin-top:10px;text-align: center;font-size: larger\">
            ";
            // line 39
            $context["nomVille"] = twig_lower_filter($this->env, strtr($this->getAttribute($this->getAttribute($this->getContext($context, "quartier"), "ville"), "nom"), array("é" => "e")));
            // line 40
            echo "            ";
            $context["nomQuartier"] = twig_lower_filter($this->env, strtr(strtr(strtr($this->getAttribute($this->getContext($context, "quartier"), "nom"), array("é" => "e")), array("à" => "a")), array(" " => "")));
            // line 41
            echo "
        ";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Encore plus d'infos sur"), "html", null, true);
            echo "
        <strong>
            <a href=\"";
            // line 44
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("vue_ensemble_quartier_i18n", array("ville" => $this->getContext($context, "nomVille"), "quartier" => $this->getContext($context, "nomQuartier"), "id" => $this->getAttribute($this->getContext($context, "quartier"), "id"))), "html", null, true);
            echo "\">
                ";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "quartier"), "nom"), "html", null, true);
            echo "
            </a>
        </strong>
        </div>
    </div>
</div>
";
        } else {
            // line 52
            echo "<div style=\"float:left;margin-top:5px;\">
    ";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Désolé, mais les services de ce quartier n'ont pas encore été enregistrés sur koutchoumi.com."), "html", null, true);
            echo "
</div>
";
        }
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_showServicesAndFacilities.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 53,  141 => 52,  131 => 45,  127 => 44,  122 => 42,  119 => 41,  116 => 40,  114 => 39,  110 => 37,  103 => 35,  88 => 33,  84 => 32,  78 => 30,  74 => 29,  66 => 25,  53 => 23,  49 => 22,  39 => 15,  32 => 11,  21 => 2,  81 => 19,  76 => 17,  72 => 16,  68 => 15,  64 => 14,  60 => 13,  56 => 12,  51 => 11,  46 => 9,  42 => 8,  38 => 7,  34 => 6,  30 => 5,  25 => 4,  23 => 3,  19 => 1,);
    }
}
