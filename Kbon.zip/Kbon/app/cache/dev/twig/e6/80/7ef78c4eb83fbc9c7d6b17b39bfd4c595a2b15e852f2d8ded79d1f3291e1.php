<?php

/* KoutchoumiFrontendBundle::_showBiensSimilaires.html.twig */
class __TwigTemplate_e6807ef78c4eb83fbc9c7d6b17b39bfd4c595a2b15e852f2d8ded79d1f3291e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["nombreBiensSimilaires"] = twig_length_filter($this->env, $this->getContext($context, "biensSimilaires"));
        // line 2
        if (($this->getContext($context, "nombreBiensSimilaires") > 0)) {
            // line 3
            echo "    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getContext($context, "biensSimilaires"));
            foreach ($context['_seq'] as $context["_key"] => $context["bien"]) {
                // line 4
                echo "        <div class=\"vue_right_content\">
            <table>
                <tr>
                        ";
                // line 7
                $context["alt"] = (((($this->getAttribute($this->getContext($context, "ReferenceData"), "getLibelleTypeBien", array(0 => $this->getAttribute($this->getContext($context, "bien"), "classKey")), "method") . " ") . $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bien"), "typeTransaction")), "method")) . " - ") . $this->getAttribute($this->getAttribute($this->getContext($context, "bien"), "ville"), "nom"));
                // line 8
                echo "                    <td>
                        ";
                // line 9
                if (($this->getAttribute($this->getContext($context, "bien"), "photoPrincipale") != null)) {
                    // line 10
                    echo "                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bien"), "photoPrincipale"), "chemin"), "html", null, true);
                    echo "\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getContext($context, "alt"), "html", null, true);
                    echo "\" width=\"100\" height=\"100\" />
                        ";
                } else {
                    // line 12
                    echo "                            <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/default_photo.png"), "html", null, true);
                    echo "\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getContext($context, "alt"), "html", null, true);
                    echo "\" width=\"100\" height=\"100\"/>
                        ";
                }
                // line 14
                echo "                    </td>
                    <td>

                        <a href=\"";
                // line 17
                echo twig_escape_filter($this->env, $this->env->getExtension('usermanager_extension')->generateURLForBienImmobilierI18n($this->getContext($context, "bien"), $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale")), "html", null, true);
                echo "\">
                                ";
                // line 18
                echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bien"), "shortDescription"), "html", null, true);
                echo "
                        </a>
                    </td>
                </tr>
            </table>
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bien'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 26
            echo "    ";
            echo twig_escape_filter($this->env, $this->getContext($context, "messageIfNothing"), "html", null, true);
            echo " 
";
        }
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_showBiensSimilaires.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 26,  65 => 18,  61 => 17,  56 => 14,  48 => 12,  38 => 9,  35 => 8,  33 => 7,  28 => 4,  23 => 3,  21 => 2,  73 => 18,  69 => 16,  58 => 13,  53 => 12,  49 => 11,  46 => 10,  44 => 9,  40 => 10,  32 => 5,  24 => 3,  22 => 2,  19 => 1,);
    }
}
