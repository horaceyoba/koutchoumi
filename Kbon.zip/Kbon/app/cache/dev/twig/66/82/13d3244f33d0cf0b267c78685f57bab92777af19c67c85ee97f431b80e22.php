<?php

/* KoutchoumiFrontendBundle::_virality.html.twig */
class __TwigTemplate_668213d3244f33d0cf0b267c78685f57bab92777af19c67c85ee97f431b80e22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<div class=\"addthis_toolbox addthis_default_style virality_block\" style=\"margin-top: 10px\">
";
        // line 3
        if (($this->getContext($context, "showText") == 1)) {
            // line 4
            echo "    <span style=\"float: left\"><strong>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Partager"), "html", null, true);
            echo "</strong> : </span>
    <span><a class=\"addthis_button_email virality_item\" title=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Envoyer par email"), "html", null, true);
            echo "\">Email</a></span>
    <span><a class=\"addthis_button_facebook virality_item\" title=\"";
            // line 6
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Facebook")), "html", null, true);
            echo "\">Facebook</a></span>
    <span><a class=\"addthis_button_twitter virality_item\" title=\"";
            // line 7
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Twitter")), "html", null, true);
            echo "\">Twitter</a></span>
    <span><a class=\"addthis_button_google virality_item\" title=\"";
            // line 8
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Google")), "html", null, true);
            echo "\">Google</a></span>
    <span><a class=\"addthis_button_viadeo virality_item\" title=\"";
            // line 9
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Viadeo")), "html", null, true);
            echo "\">Viadeo</a></span>
";
        } else {
            // line 11
            echo "    ";
            echo "ShowText=0";
            echo "
    <span><a class=\"addthis_button_email\" title=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Envoyer par email"), "html", null, true);
            echo "\"></a></span>
    <span><a class=\"addthis_button_facebook virality_item\" title=\"";
            // line 13
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Facebook")), "html", null, true);
            echo "\"></a></span>
    <span><a class=\"addthis_button_twitter virality_item\" title=\"";
            // line 14
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Twitter")), "html", null, true);
            echo "\"></a></span>
    <span><a class=\"addthis_button_google virality_item\" title=\"";
            // line 15
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Google")), "html", null, true);
            echo "\"></a></span>
    <span><a class=\"addthis_button_viadeo virality_item\" title=\"";
            // line 16
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Viadeo")), "html", null, true);
            echo "\"></a></span>
    <span><a class=\"addthis_button_delicious virality_item\" title=\"";
            // line 17
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Partagez sur %1%"), array("%1%" => "Delicious")), "html", null, true);
            echo "\"></a></span>
    <a class=\"addthis_button_expanded virality_item\" title=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Encore + de réseaux"), "html", null, true);
            echo "></a>
";
        }
        // line 20
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_virality.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 20,  79 => 18,  75 => 17,  71 => 16,  67 => 15,  63 => 14,  59 => 13,  55 => 12,  50 => 11,  45 => 9,  41 => 8,  37 => 7,  33 => 6,  29 => 5,  24 => 4,  22 => 3,  19 => 2,);
    }
}
