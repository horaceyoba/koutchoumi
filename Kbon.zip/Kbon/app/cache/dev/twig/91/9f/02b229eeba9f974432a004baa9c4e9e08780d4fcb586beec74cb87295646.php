<?php

/* KoutchoumiFrontendBundle::_shortViewMagasin.html.twig */
class __TwigTemplate_919f02b229eeba9f974432a004baa9c4e9e08780d4fcb586beec74cb87295646 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["url"] = $this->env->getExtension('usermanager_extension')->generateURLForBienImmobilierI18n($this->getContext($context, "bienImmo"), $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale"));
        // line 2
        echo "
<div class=\"content_result\">
    <h4 class=\"title_blue\">
        <a href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">
            ";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Magasin"), "html", null, true);
        echo "  ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method"), "html", null, true);
        echo " -
            ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "ville"), "nom"), "html", null, true);
        echo "/";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "nom"), "html", null, true);
        echo "
        </a>
    </h4>
    <em class=\"margin6\">
        ";
        // line 11
        $context["dateDiff"] = $this->env->getExtension('usermanager_extension')->dateDiffInPlainText(twig_date_format_filter($this->env, "now", "Y-m-d"), twig_date_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "datePublication"), "Y-m-d"));
        // line 12
        echo "        ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("publié"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "dateDiff"), "html", null, true);
        echo " - ";
        echo strtr($this->env->getExtension('translator')->trans("vu <strong>%1%</strong> fois"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreHits")));
        echo "
    </em>
      <table width=\"440\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
          <tr>
            <td width=\"126\" rowspan=\"2\" align=\"center\" valign=\"middle\">
                ";
        // line 17
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale") != null)) {
            // line 18
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale"), "chemin")), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "title"), "html", null, true);
            echo "\" width=\"120\" height=\"120\" />
                ";
        } else {
            // line 20
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/default_photo.png"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi Immobilier"), "html", null, true);
            echo "\" />
                ";
        }
        // line 22
        echo "            </td>
            <td width=\"162\" height=\"15\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">
                    <li>";
        // line 25
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "prix"), 0, ".", " "), "html", null, true);
        echo " FCFA</li>
                    ";
        // line 26
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "surface") != null)) {
            // line 27
            echo "                    <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surface"), 0, ".", " "), "html", null, true);
            echo " m<sup>2</sup></li>
                    ";
        }
        // line 29
        echo "                </ul>
            </td>

            <td width=\"162\" height=\"15\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">

                    ";
        // line 35
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") == 0)) {
            // line 36
            echo "                    <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Situé en bordure de route"), "html", null, true);
            echo "</li>
                    ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute") != null)) {
            // line 38
            echo "                    <li>";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("à %DISTANCE% m de la route"), array("%DISTANCE%" => twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "distanceDeLaRoute"), 0, ".", " "))), "html", null, true);
            echo "</li>
                    ";
        }
        // line 40
        echo "
                    <li>";
        // line 41
        echo ">";
        echo "
                        ";
        // line 42
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "etat") == twig_constant("ETAT_EN_BON_ETAT", $this->getContext($context, "ReferenceData")))) {
            // line 43
            echo "                                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("en bon état"), "html", null, true);
            echo "
                        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etat") == twig_constant("ETAT_NEUF", $this->getContext($context, "ReferenceData")))) {
            // line 45
            echo "                                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("neuf"), "html", null, true);
            echo "
                        ";
        } elseif (($this->getAttribute($this->getContext($context, "bienImmo"), "etat") == twig_constant("ETAT_VETUSTE", $this->getContext($context, "ReferenceData")))) {
            // line 47
            echo "                                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("vétuste"), "html", null, true);
            echo "
                        ";
        }
        // line 49
        echo "                    </li>
                </ul>
            </td>
          </tr>
          <tr>
            <td colspan=\"2\" align=\"left\" valign=\"middle\">
                <p class=\"p_result\">
                    <a href=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">
                        ";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Voir plus de détails"), "html", null, true);
        echo "
                    </a>
                </p>
            </td>
          </tr>
          <tr>
            <td align=\"center\" valign=\"middle\"><span> ";
        // line 63
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "nombrePhotos"), "html", null, true);
        echo " photo(s)</span></td>
            <td colspan=\"2\" align=\"left\" valign=\"top\">&nbsp;</td>
          </tr>
    </table>
</div>";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_shortViewMagasin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 63,  165 => 57,  161 => 56,  152 => 49,  146 => 47,  140 => 45,  134 => 43,  132 => 42,  128 => 41,  125 => 40,  117 => 38,  109 => 36,  107 => 35,  99 => 29,  91 => 27,  89 => 26,  83 => 25,  78 => 22,  70 => 20,  62 => 18,  60 => 17,  47 => 12,  45 => 11,  36 => 7,  30 => 6,  26 => 5,  21 => 2,  19 => 1,);
    }
}
