<?php

/* KoutchoumiFrontendBundle:tools:createWidget.html.twig */
class __TwigTemplate_4144c4441a9f372e8ca8b514187e630e9e619413ee042117f2454ab61435e642 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("KoutchoumiFrontendBundle::layout.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "KoutchoumiFrontendBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"content_alt_title\">
    <h1 class=\"orange\">";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Webmasters, créez votre widget koutchoumi.com"), "html", null, true);
        echo "</h1>
</div>
<div id=\"content_alt_login\">

    <form method=\"post\" action=\"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("create_widget");
        echo "\">
        <div class=\"margin\">
            <p class=\"form_help\">
                ";
        // line 11
        echo $this->env->getExtension('translator')->trans("Le widget koutchoumi.com vous permet de rendre votre site plus <strong>cool</strong> et plus <strong>attractif</strong> en affichant les <strong>dernières annonces immobilières de koutchoumi.com</strong>");
        echo ".
                <a href=\"#widgetDemo\">";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Consultez un aperçu"), "html", null, true);
        echo ".</a>
            </p>
        </div>

        ";
        // line 16
        if ((!$this->getAttribute($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "vars"), "valid"))) {
            // line 17
            echo "            <div class=\"errors\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Oups! Certaines données du formulaire ne sont pas valides"), "html", null, true);
            echo ".</div>
            <div class=\"red2\">";
            // line 18
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "buildKoutchoumiWidgetForm"), 'errors');
            echo "</div>
        ";
        }
        // line 20
        echo "
        <h2 class=\"head\"><span class=\"margin-left\">1. ";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Paramétrez les annonces à afficher"), "html", null, true);
        echo "</span></h2>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 23
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "villeId"), 'label');
        echo "</span>
            ";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "villeId"), 'widget', array("style" => "width:120px"));
        echo "            
            <span class=\"red2\"> ";
        // line 25
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "villeId"), 'errors');
        echo "</span>
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "typeBien"), 'label');
        echo "</span>
            ";
        // line 29
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "typeBien"), 'widget', array("style" => "width:120px"));
        echo "            
            <span class=\"red2\"> ";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "typeBien"), 'errors');
        echo "</span>
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 33
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "nombreAnnoncesAAfficher"), 'label');
        echo "</span>
            ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "nombreAnnoncesAAfficher"), 'widget', array("style" => "width:40px"));
        echo "            
            <span class=\"red2\"> ";
        // line 35
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "nombreAnnoncesAAfficher"), 'errors');
        echo "</span>
        </div>
        
        <br />

        <h2 class=\"head\"><span class=\"margin-left\">2. ";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Personnalisez l'affichage"), "html", null, true);
        echo "</span></h2>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 42
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "langue"), 'label');
        echo "</span>
            ";
        // line 43
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "langue"), 'widget');
        echo "            
            <span class=\"red2\"> ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "langue"), 'errors');
        echo "</span>
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 47
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "largeur"), 'label');
        echo "</span>
            ";
        // line 48
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "largeur"), 'widget', array("style" => "width:50px"));
        echo " pixels           
            <span class=\"red2\"> ";
        // line 49
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "largeur"), 'errors');
        echo "</span>      
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "police"), 'label');
        echo "</span>
            ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "police"), 'widget');
        echo "            
            <span class=\"red2\"> ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "police"), 'errors');
        echo "</span>
        </div>
        <h3 class=\"head3\"><span class=\"margin-left\">2.1. ";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("En-tête du widget"), "html", null, true);
        echo "</span></h3>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 58
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "titre"), 'label');
        echo "</span>
            ";
        // line 59
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "titre"), 'widget', array("style" => "width:200px"));
        echo "           
            <span class=\"red2\"> ";
        // line 60
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "titre"), 'errors');
        echo "</span>      
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 63
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondEnTete"), 'label');
        echo "</span>
            #";
        // line 64
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondEnTete"), 'widget', array("style" => "width:60px"));
        echo "           
            <span class=\"red2\"> ";
        // line 65
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondEnTete"), 'errors');
        echo "</span>      
        </div>
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 68
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleTitre"), 'label');
        echo "</span>
            #";
        // line 69
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleTitre"), 'widget', array("style" => "width:50px"));
        echo " pixels           
            <span class=\"red2\"> ";
        // line 70
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleTitre"), 'errors');
        echo "</span>      
        </div>
        <h3 class=\"head3\"><span class=\"margin-left\">2.2. <?php echo __(\"Corps du widget\")?></span></h3>        
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 74
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondCorps"), 'label');
        echo "</span>
            #";
        // line 75
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondCorps"), 'widget', array("style" => "width:60px"));
        echo "           
            <span class=\"red2\"> ";
        // line 76
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurDeFondCorps"), 'errors');
        echo "</span>      
        </div> 
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 79
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleLiensCorps"), 'label');
        echo "</span>
            #";
        // line 80
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleLiensCorps"), 'widget', array("style" => "width:50px"));
        echo " pixels           
            <span class=\"red2\"> ";
        // line 81
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "tailleLiensCorps"), 'errors');
        echo "</span>      
        </div>
        <h3 class=\"head3\"><span class=\"margin-left\">2.2. <?php echo __(\"Corps du widget\")?></span></h3>        
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 85
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiens"), 'label');
        echo "</span>
            #";
        // line 86
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiens"), 'widget', array("style" => "width:60px"));
        echo "           
            <span class=\"red2\"> ";
        // line 87
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiens"), 'errors');
        echo "</span>      
        </div> 
        <div class=\"margin\">
            <span class=\"span_to_block\">";
        // line 90
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiensOnHover"), 'label');
        echo "</span>
            #";
        // line 91
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiensOnHover"), 'widget', array("style" => "width:60px"));
        echo "           
            <span class=\"red2\"> ";
        // line 92
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "buildKoutchoumiWidgetForm"), "couleurLiensOnHover"), 'errors');
        echo "</span>      
        </div> 
        
        <br />

        <h2 class=\"head\"><span class=\"margin-left\">3. ";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("C'est fini !"), "html", null, true);
        echo "</span></h2>

        <div style=\"margin-top: 20px\">
            <div id=\"widgetDemo\" style=\"float: left;margin-right: 20px\">";
        // line 100
        if (array_key_exists("widgetCode", $context)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("widgetCode"), "html", null, true);
            echo " ";
        }
        echo "</div>
            <div style=\"float: left\">
                <div style=\"margin-bottom: 10px\">
                    <input value=\"";
        // line 103
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Mettre à jour l'aperçu et le code"), "html", null, true);
        echo "\" type=\"submit\" class=\"submit_index\"/>
                </div>
                <p class=\"orange\" style=\"font-weight: bold;font-size: large\">";
        // line 105
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Copiez et collez ce code sur votre page web"), "html", null, true);
        echo "</p>
                <textarea cols=\"80\" rows=\"9\" id=\"widgetCode\" readonly=\"readonly\">";
        // line 106
        if (array_key_exists("widgetCode", $context)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("widgetCode"), "html", null, true);
            echo " ";
        }
        echo "</textarea>
            </div>
            <div class=\"RAS\"></div>
        </div>
        ";
        // line 110
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "buildKoutchoumiWidgetForm"), 'rest');
        echo "
    </form>
</div>

";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle:tools:createWidget.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 110,  300 => 106,  296 => 105,  291 => 103,  281 => 100,  275 => 97,  267 => 92,  263 => 91,  259 => 90,  253 => 87,  249 => 86,  245 => 85,  238 => 81,  234 => 80,  230 => 79,  224 => 76,  220 => 75,  216 => 74,  209 => 70,  205 => 69,  201 => 68,  195 => 65,  191 => 64,  187 => 63,  181 => 60,  177 => 59,  173 => 58,  168 => 56,  163 => 54,  159 => 53,  155 => 52,  149 => 49,  145 => 48,  141 => 47,  135 => 44,  131 => 43,  127 => 42,  122 => 40,  114 => 35,  110 => 34,  106 => 33,  100 => 30,  96 => 29,  92 => 28,  86 => 25,  82 => 24,  78 => 23,  73 => 21,  70 => 20,  65 => 18,  60 => 17,  58 => 16,  51 => 12,  47 => 11,  41 => 8,  34 => 4,  31 => 3,  28 => 2,);
    }
}
