<?php

/* KoutchoumiFrontendBundle::panelNewRefineSearchResults.html.twig */
class __TwigTemplate_f38199984a953d0cf287da935fc13aa0784b1dcef2333424928b4bb46e2bbbfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "    ";
        if ($this->getAttribute($this->getAttribute($this->getContext($context, "form", true), "vars", array(), "any", false, true), "value", array(), "any", true, true)) {
            // line 3
            echo "        ";
            $context["typeBien"] = $this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "form"), "typeBien"), "vars"), "value");
            // line 4
            echo "    ";
        }
        // line 5
        echo "    ";
        // line 6
        echo "    ";
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_APPARTEMENT", $this->getContext($context, "ReferenceData")))) {
            // line 7
            echo "            ";
            $context["displayStyleNombreChambres"] = "block";
            // line 8
            echo "            ";
            $context["displayStyleSurface"] = "none";
            // line 9
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 10
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 11
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 12
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 13
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "block";
            // line 14
            echo "            ";
            $context["displayStyleAvecParking"] = "block";
            // line 15
            echo "            ";
            $context["displayStyleAvecBarriere"] = "block";
            // line 16
            echo "            ";
            $context["displayStyleDistanceRoute"] = "none";
            // line 17
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 18
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 19
            echo "    ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")))) {
            // line 20
            echo "            ";
            $context["displayStyleNombreChambres"] = "block";
            // line 21
            echo "            ";
            $context["displayStyleSurface"] = "none";
            // line 22
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "block";
            // line 23
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 24
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 25
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 26
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "block";
            // line 27
            echo "            ";
            $context["displayStyleAvecParking"] = "block";
            // line 28
            echo "            ";
            $context["displayStyleAvecBarriere"] = "block";
            // line 29
            echo "            ";
            $context["displayStyleDistanceRoute"] = "none";
            // line 30
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 31
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 32
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_STUDIO", $this->getContext($context, "ReferenceData")))) {
            // line 33
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 34
            echo "            ";
            $context["displayStyleSurface"] = "none";
            // line 35
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 36
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 37
            echo "            ";
            $context["displayStyleToilettes"] = "block";
            // line 38
            echo "            ";
            $context["displayStyleSalleDeBains"] = "block";
            // line 39
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 40
            echo "            ";
            $context["displayStyleAvecParking"] = "none";
            // line 41
            echo "            ";
            $context["displayStyleAvecBarriere"] = "block";
            // line 42
            echo "            ";
            $context["displayStyleDistanceRoute"] = "none";
            // line 43
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 44
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 45
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 46
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 47
            echo "            ";
            $context["displayStyleSurface"] = "block";
            // line 48
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 49
            echo "            ";
            $context["displayStyleTitre"] = "block";
            // line 50
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 51
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 52
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 53
            echo "            ";
            $context["displayStyleAvecParking"] = "none";
            // line 54
            echo "            ";
            $context["displayStyleAvecBarriere"] = "none";
            // line 55
            echo "            ";
            $context["displayStyleDistanceRoute"] = "none";
            // line 56
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 57
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 58
            echo "      ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BLOC_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 59
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 60
            echo "            ";
            $context["displayStyleSurface"] = "none";
            // line 61
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 62
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 63
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 64
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 65
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 66
            echo "            ";
            $context["displayStyleAvecParking"] = "none";
            // line 67
            echo "            ";
            $context["displayStyleAvecBarriere"] = "none";
            // line 68
            echo "            ";
            $context["displayStyleDistanceRoute"] = "none";
            // line 69
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 70
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 71
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")))) {
            // line 72
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 73
            echo "            ";
            $context["displayStyleSurface"] = "block";
            // line 74
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 75
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 76
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 77
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 78
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 79
            echo "            ";
            $context["displayStyleAvecParking"] = "none";
            // line 80
            echo "            ";
            $context["displayStyleAvecBarriere"] = "none";
            // line 81
            echo "            ";
            $context["displayStyleDistanceRoute"] = "block";
            // line 82
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 83
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 84
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")))) {
            // line 85
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 86
            echo "            ";
            $context["displayStyleSurface"] = "block";
            // line 87
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 88
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 89
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 90
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 91
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 92
            echo "            ";
            $context["displayStyleAvecParking"] = "none";
            // line 93
            echo "            ";
            $context["displayStyleAvecBarriere"] = "block";
            // line 94
            echo "            ";
            $context["displayStyleDistanceRoute"] = "block";
            // line 95
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 96
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 97
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")))) {
            // line 98
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 99
            echo "            ";
            $context["displayStyleSurface"] = "block";
            // line 100
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 101
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 102
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 103
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 104
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 105
            echo "            ";
            $context["displayStyleAvecParking"] = "block";
            // line 106
            echo "            ";
            $context["displayStyleAvecBarriere"] = "none";
            // line 107
            echo "            ";
            $context["displayStyleDistanceRoute"] = "block";
            // line 108
            echo "            ";
            $context["displayStyleAvecDouche"] = "block";
            // line 109
            echo "            ";
            $context["displayStyleNombrePieces"] = "none";
            // line 110
            echo "     ";
        } elseif (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")))) {
            // line 111
            echo "            ";
            $context["displayStyleNombreChambres"] = "none";
            // line 112
            echo "            ";
            $context["displayStyleSurface"] = "block";
            // line 113
            echo "            ";
            $context["displayStyleTypeMaisonId"] = "none";
            // line 114
            echo "            ";
            $context["displayStyleTitre"] = "none";
            // line 115
            echo "            ";
            $context["displayStyleToilettes"] = "none";
            // line 116
            echo "            ";
            $context["displayStyleSalleDeBains"] = "none";
            // line 117
            echo "            ";
            $context["displayStyleNombreSalleDeBains"] = "none";
            // line 118
            echo "            ";
            $context["displayStyleAvecParking"] = "block";
            // line 119
            echo "            ";
            $context["displayStyleAvecBarriere"] = "none";
            // line 120
            echo "            ";
            $context["displayStyleDistanceRoute"] = "block";
            // line 121
            echo "            ";
            $context["displayStyleAccessibleEnVoiture"] = "block";
            // line 122
            echo "            ";
            $context["displayStyleAvecDouche"] = "none";
            // line 123
            echo "            ";
            $context["displayStyleNombrePieces"] = "block";
            // line 124
            echo "     ";
        } else {
            echo " 
     ";
        }
        // line 127
        echo "
<div id=\"left\">
    <h5 class=\"title_green\"><";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Affinez votre recherche"), "html", null, true);
        echo "</h5>
    <form method=\"get\" action=\"";
        // line 130
        echo $this->env->getExtension('routing')->getPath("show_results");
        echo "\" id=\"trouverBienForm\">
    <div class=\"margin-left2\">
        <span class=\"span_to_block3\">";
        // line 132
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Type de bien"), "html", null, true);
        echo "</span>
        ";
        // line 133
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeBien"), 'widget', array("attr" => array("style" => "width:120px")));
        echo "
    </div>
    <div class=\"margin-left2\">
        <span class=\"span_to_block3\">";
        // line 136
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Transaction"), "html", null, true);
        echo "</span>
        ";
        // line 137
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeTransaction"), 'widget', array("attr" => array("class" => "input_index")));
        echo "
    </div>
    <div class=\"margin-left2\">
        <span class=\"span_to_block3\">";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Ville"), "html", null, true);
        echo "</span>
        ";
        // line 141
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "villeId"), 'widget', array("attr" => array("style" => "width:120px")));
        echo "
    </div>
    <div id=\"divNombreChambres\" class=\"margin-left2\" style=\"display:";
        // line 143
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleNombreChambres"), "html", null, true);
        echo "\">
        <span class=\"span_to_block3\">";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Nombre de chambres"), "html", null, true);
        echo "</span>
        ";
        // line 145
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "nombreChambres"), 'widget', array("attr" => array("style" => "width:100px")));
        echo "
    </div>
    <div id=\"divSurface\" class=\"margin-left2\" style=\"display:";
        // line 147
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleSurface"), "html", null, true);
        echo "\">
        <span class=\"span_to_block3\">";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Surface"), "html", null, true);
        echo "</span>
        ";
        // line 149
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "surfaceMin"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
        <span class=\"margin-left3\"> - </span>
        ";
        // line 151
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "surfaceMax"), 'widget', array("attr" => array("style" => "width:80px")));
        echo " m2
    </div>
    <div class=\"margin-left2\">
        <span class=\"span_to_block3\">";
        // line 154
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Prix"), "html", null, true);
        echo "</span>
        ";
        // line 155
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "prixMin"), 'widget', array("attr" => array("style" => "width:75px")));
        echo "
        <span class=\"margin-left3\"> - </span>
        ";
        // line 157
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "prixMax"), 'widget', array("attr" => array("style" => "width:75px")));
        echo "
        <label class=\"label_index2\" id=\"monnaiePrix\">
            ";
        // line 159
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BLOC_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 160
            echo "                F/m<sup>2</sup>
            ";
        } else {
            // line 162
            echo "                FCFA
            ";
        }
        // line 164
        echo "        </label>
    </div>
        <h5 class=\"title_green\"></h5>

        <div class=\"margin-left2\">
            <span class=\"span_to_block3\">";
        // line 169
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Quartier"), "html", null, true);
        echo "</span>
            ";
        // line 170
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "quartierId"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
            <span id=\"textLoadingQuartiers\" style=\"display: none\">";
        // line 171
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("chargement..."), "html", null, true);
        echo "</span>
        </div>
        <div id=\"errorMsgLoadingQuartiers\" class=\"margin-left2\" style=\"color: red\"></div>

        <div id=\"divNombrePieces\" class=\"margin-left2\" style=\"display:";
        // line 175
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleNombrePieces"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">Nombre de pi&egrave;ces</span>
            ";
        // line 177
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "nombrePiecesMin"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
            <span class=\"margin-left3\">-</span>
            ";
        // line 179
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "nombrePiecesMax"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
        </div>

        <div id=\"divDistanceRoute\" class=\"margin-left2\" style=\"display:";
        // line 182
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleDistanceRoute"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 183
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Distance de la route"), "html", null, true);
        echo "</span>
            ";
        // line 184
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "distanceRouteMin"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
            <span class=\"margin-left3\"> - </span>
            ";
        // line 186
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "distanceRouteMax"), 'widget', array("attr" => array("style" => "width:80px")));
        echo " m
        </div>
        <div class=\"margin-left2\" id=\"divTypeMaisonId\" style=\"display:";
        // line 188
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleTypeMaisonId"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Style de maison"), "html", null, true);
        echo "</span>
            ";
        // line 190
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeMaisonId"), 'widget', array("attr" => array("style" => "width:100px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divSalleDeBains\" style=\"display:";
        // line 192
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleSalleDeBains"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\"><";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Salle de bains"), "html", null, true);
        echo "</span>
            ";
        // line 194
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "situationSalleDeBains"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divToilettes\" style=\"display:";
        // line 196
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleToilettes"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 197
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Toilettes"), "html", null, true);
        echo "</span>
            ";
        // line 198
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "situationToilettes"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divTitre\" style=\"display:";
        // line 200
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleTitre"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 201
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Titré"), "html", null, true);
        echo "</span>
            ";
        // line 202
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "titre"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divNombreSalleDeBains\" style=\"display:";
        // line 204
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleNombreSalleDeBains"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 205
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Nombre de salles de bains"), "html", null, true);
        echo "</span>
            ";
        // line 206
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "minSDB"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
            <span class=\"margin-left3\"> - </span>
            ";
        // line 208
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "maxSDB"), 'widget', array("attr" => array("style" => "width:80px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divAvecDouche\" style=\"display:";
        // line 210
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleAvecDouche"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 211
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Avec douche"), "html", null, true);
        echo " ?</span>
            ";
        // line 212
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "avecDouche"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divAvecParking\" style=\"display:";
        // line 214
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleAvecParking"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 215
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Avec parking ?"), "html", null, true);
        echo "</span>
            ";
        // line 216
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "avecParking"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>
        <div class=\"margin-left2\" id=\"divAvecBarriere\" style=\"display:";
        // line 218
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleAvecBarriere"), "html", null, true);
        echo "\">
            <span class=\"span_to_block3\">";
        // line 219
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Avec barrière ?"), "html", null, true);
        echo "></span>
            ";
        // line 220
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "avecBarriere"), 'widget', array("attr" => array("style" => "width:110px")));
        echo "
        </div>

    <div class=\"margin5\">
        <input type=\"submit\" class=\"submit_index\" value=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Trouvez"), "html", null, true);
        echo "\"/>
    </div>
    ";
        // line 226
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "form"), 'rest');
        echo "
    </form>

</div>
";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::panelNewRefineSearchResults.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  660 => 226,  655 => 224,  648 => 220,  644 => 219,  640 => 218,  635 => 216,  631 => 215,  627 => 214,  622 => 212,  618 => 211,  614 => 210,  609 => 208,  604 => 206,  600 => 205,  596 => 204,  591 => 202,  587 => 201,  583 => 200,  578 => 198,  574 => 197,  570 => 196,  565 => 194,  561 => 193,  557 => 192,  552 => 190,  548 => 189,  544 => 188,  539 => 186,  534 => 184,  526 => 182,  520 => 179,  515 => 177,  510 => 175,  503 => 171,  495 => 169,  484 => 162,  480 => 160,  473 => 157,  468 => 155,  464 => 154,  458 => 151,  453 => 149,  449 => 148,  445 => 147,  440 => 145,  436 => 144,  432 => 143,  423 => 140,  417 => 137,  413 => 136,  407 => 133,  394 => 129,  390 => 127,  384 => 124,  381 => 123,  378 => 122,  375 => 121,  372 => 120,  369 => 119,  366 => 118,  363 => 117,  360 => 116,  357 => 115,  354 => 114,  351 => 113,  348 => 112,  345 => 111,  339 => 109,  336 => 108,  333 => 107,  330 => 106,  327 => 105,  324 => 104,  321 => 103,  318 => 102,  315 => 101,  312 => 100,  309 => 99,  306 => 98,  303 => 97,  300 => 96,  297 => 95,  294 => 94,  288 => 92,  285 => 91,  282 => 90,  279 => 89,  276 => 88,  270 => 86,  267 => 85,  261 => 83,  258 => 82,  252 => 80,  249 => 79,  246 => 78,  243 => 77,  240 => 76,  237 => 75,  234 => 74,  231 => 73,  228 => 72,  225 => 71,  222 => 70,  219 => 69,  216 => 68,  213 => 67,  210 => 66,  207 => 65,  204 => 64,  201 => 63,  198 => 62,  195 => 61,  192 => 60,  189 => 59,  183 => 57,  180 => 56,  177 => 55,  168 => 52,  162 => 50,  156 => 48,  147 => 45,  138 => 42,  132 => 40,  129 => 39,  126 => 38,  123 => 37,  120 => 36,  117 => 35,  114 => 34,  105 => 31,  99 => 29,  96 => 28,  93 => 27,  90 => 26,  87 => 25,  84 => 24,  81 => 23,  72 => 20,  63 => 17,  60 => 16,  57 => 15,  51 => 13,  45 => 11,  39 => 9,  33 => 7,  30 => 6,  19 => 2,  546 => 67,  543 => 66,  533 => 159,  530 => 183,  517 => 149,  511 => 148,  505 => 147,  499 => 170,  493 => 145,  488 => 164,  478 => 159,  472 => 137,  466 => 136,  460 => 135,  454 => 134,  448 => 133,  442 => 132,  437 => 130,  427 => 141,  421 => 124,  415 => 123,  409 => 122,  403 => 132,  398 => 130,  388 => 114,  382 => 113,  376 => 112,  370 => 111,  364 => 110,  358 => 109,  352 => 108,  347 => 106,  342 => 110,  340 => 102,  334 => 99,  326 => 96,  320 => 95,  314 => 94,  307 => 92,  301 => 91,  295 => 90,  291 => 93,  287 => 87,  273 => 87,  268 => 74,  264 => 84,  262 => 71,  257 => 68,  255 => 81,  248 => 61,  245 => 60,  223 => 58,  218 => 57,  215 => 56,  193 => 54,  188 => 53,  186 => 58,  182 => 51,  174 => 54,  171 => 53,  163 => 44,  157 => 42,  155 => 41,  142 => 37,  139 => 36,  125 => 27,  64 => 24,  54 => 14,  48 => 12,  43 => 13,  37 => 10,  25 => 4,  22 => 3,  20 => 1,  165 => 51,  159 => 49,  153 => 47,  150 => 46,  144 => 44,  141 => 43,  135 => 41,  133 => 40,  130 => 39,  124 => 38,  122 => 37,  119 => 36,  113 => 35,  111 => 33,  108 => 32,  102 => 30,  100 => 31,  97 => 30,  91 => 29,  89 => 28,  86 => 27,  80 => 26,  78 => 22,  75 => 21,  69 => 19,  66 => 18,  62 => 21,  58 => 19,  56 => 18,  52 => 15,  50 => 15,  42 => 10,  36 => 8,  31 => 3,  28 => 5,);
    }
}
