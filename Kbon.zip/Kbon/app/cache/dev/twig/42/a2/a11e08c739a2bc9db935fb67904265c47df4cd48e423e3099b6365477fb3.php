<?php

/* KoutchoumiFrontendBundle::index.html.twig */
class __TwigTemplate_42a2a11e08c739a2bc9db935fb67904265c47df4cd48e423e3099b6365477fb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("KoutchoumiFrontendBundle::layout.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "KoutchoumiFrontendBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 3
        $context["nombreChambresALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_STUDIO", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 4
        $context["nombreAppartementsALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_APPARTEMENT", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 5
        $context["nombreMaisonsALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 6
        $context["nombreBoutiquesALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 7
        $context["nombreMagasinsALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 8
        $context["nombreEntrepotsALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 9
        $context["nombreBureauxALouer"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_LOCATION", $this->getContext($context, "ReferenceData")));
        // line 12
        $context["nombreMaisonsAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 13
        $context["nombreTerrainsAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_TERRAIN", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 14
        $context["nombreBoutiquesAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 15
        $context["nombreMagasinsAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 16
        $context["nombreEntrepotsAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 17
        $context["nombreBureauxAVendre"] = $this->env->getExtension('usermanager_extension')->compterBiensDisponibles(twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")), twig_constant("TYPE_TRANSACTION_VENTE", $this->getContext($context, "ReferenceData")));
        // line 20
        if ($this->getAttribute($this->getAttribute($this->getContext($context, "form", true), "vars", array(), "any", false, true), "value", array(), "any", true, true)) {
            // line 21
            $context["typeBien"] = $this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "form"), "typeBien"), "vars"), "value");
        }
        // line 24
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_APPARTEMENT", $this->getContext($context, "ReferenceData")))) {
            // line 25
            $context["displayStyleNombreChambres"] = "block";
            // line 26
            $context["displayStyleSurface"] = "none";
        }
        // line 29
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")))) {
            // line 30
            $context["displayStyleNombreChambres"] = "block";
            // line 31
            $context["displayStyleSurface"] = "none";
        }
        // line 34
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_STUDIO", $this->getContext($context, "ReferenceData")))) {
            // line 35
            $context["displayStyleNombreChambres"] = "none";
            // line 36
            $context["displayStyleSurface"] = "none";
        }
        // line 39
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 40
            $context["displayStyleNombreChambres"] = "none";
            // line 41
            $context["displayStyleSurface"] = "block";
        }
        // line 44
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BLOC_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 45
            $context["displayStyleNombreChambres"] = "none";
            // line 46
            $context["displayStyleSurface"] = "none";
        }
        // line 49
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")))) {
            // line 50
            $context["displayStyleNombreChambres"] = "none";
            // line 51
            $context["displayStyleSurface"] = "block";
        }
        // line 54
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")))) {
            // line 55
            $context["displayStyleNombreChambres"] = "none";
            // line 56
            $context["displayStyleSurface"] = "block";
        }
        // line 59
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")))) {
            // line 60
            $context["displayStyleNombreChambres"] = "none";
            // line 61
            $context["displayStyleSurface"] = "block";
        }
        // line 64
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")))) {
            // line 65
            $context["displayStyleNombreChambres"] = "none";
            // line 66
            $context["displayStyleSurface"] = "block";
        }
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 69
    public function block_body($context, array $blocks = array())
    {
        // line 70
        echo "<h1 align=\"center\" class=\"serieux\">
";
        // line 71
        list($context["serieusesi18n"], $context["url"]) =         array($this->env->getExtension('translator')->trans("sérieuses"), $this->env->getExtension('routing')->getPath("koutchoumi_est_serieux"));
        // line 72
        echo " 
    ";
        // line 74
        echo "    ";
        if ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "fr")) {
            // line 75
            echo "        Annonces immobilières <a href=\"";
            echo $this->env->getExtension('routing')->getPath("koutchoumi_est_serieux");
            echo "\" target=\"_blank\">sérieuses</a> au Cameroun 
    ";
        } elseif ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "en")) {
            // line 77
            echo "        <a href=\"%1%\" target=\"_blank\">Reliable</a> real estate ads in Cameroon
    ";
        }
        // line 80
        echo "</h1>
<div id=\"content_login_form_alt\">    

<form action=\"";
        // line 83
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\" method=\"post\" >
        <div class=\"margin10\">
            <span class=\"span_to_block\">";
        // line 85
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeBien"), 'label');
        echo "</span>
            ";
        // line 86
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeBien"), 'widget', array("style" => "width:150px", "class" => "input_index"));
        echo "
        </div>  
        <div class=\"margin10\">
            <span class=\"span_to_block\">";
        // line 89
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeTransaction"), 'label');
        echo "</span>
            ";
        // line 90
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "typeTransaction"), 'widget', array("class" => "input_index"));
        echo "
        </div>
        <div class=\"margin10\">
            <span class=\"span_to_block\">";
        // line 93
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "villeId"), 'label');
        echo "</span>
            ";
        // line 94
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "villeId"), 'widget', array("style" => "width:150px", "class" => "input_index"));
        echo "
        </div>
        <div class=\"margin10\" id=\"divNombreChambres\" style=\"display:";
        // line 96
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleNombreChambres"), "html", null, true);
        echo "\">
            <span class=\"span_to_block\">";
        // line 97
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "nombreChambres"), 'label');
        echo "</span>
            ";
        // line 98
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "nombreChambres"), 'widget', array("style" => "width:150px", "class" => "input_index"));
        echo "
        </div>
        <div class=\"margin10\" id=\"divSurface\" style=\"display:";
        // line 100
        echo twig_escape_filter($this->env, $this->getContext($context, "displayStyleSurface"), "html", null, true);
        echo "\">
            <span class=\"span_to_block\"><label class=\"label_index\">";
        // line 101
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Combien de m2?"), "html", null, true);
        echo " </label></span>
            <label class=\"label_index2\">";
        // line 102
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Min"), "html", null, true);
        echo ":</label>
            ";
        // line 103
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "surfaceMin"), 'widget', array("style" => "width:100px", "class" => "input_index"));
        echo "
            <label class=\"label_index2\">";
        // line 104
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Max"), "html", null, true);
        echo ":</label>
            ";
        // line 105
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "surfaceMax"), 'widget', array("style" => "width:100px", "class" => "input_index"));
        echo "
        </div>
        <div class=\"margin10\">
            <span class=\"span_to_block\"><label class=\"label_index\">";
        // line 108
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Combien (FCFA)?"), "html", null, true);
        echo " </label></span>
            <label class=\"label_index2\">";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Min"), "html", null, true);
        echo ":</label>
            ";
        // line 110
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "prixMin"), 'widget', array("style" => "width:100px", "class" => "input_index"));
        echo "
            <label class=\"label_index2\">";
        // line 111
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Max"), "html", null, true);
        echo ":</label>
            ";
        // line 112
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "prixMax"), 'widget', array("style" => "width:100px", "class" => "input_index"));
        echo "
            <label class=\"label_index2\" id=\"monnaiePrix\">
                ";
        // line 114
        if (($this->getContext($context, "typeBien") == twig_constant("TYPE_BIEN_BLOC_TERRAIN", $this->getContext($context, "ReferenceData")))) {
            // line 115
            echo "                    F/m<sup>2</sup>
                ";
        }
        // line 117
        echo "            </label>
        </div>    
        
        <div class=\"margin3\">
            <input value=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Trouvez"), "html", null, true);
        echo "\" type=\"submit\" class=\"submit_index\"/>
        </div> 
 ";
        // line 123
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "form"), 'rest');
        echo "
</form>
    
</div>
<div id=\"content_footer\">
    <div style=\"text-align: right\">
        ";
        // line 129
        $context["userlocale"] = $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale");
        echo " ";
        // line 130
        echo "         ";
        // line 131
        echo "        ";
        if ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "fr")) {
            // line 132
            echo "            <a href=\"";
            echo $this->env->getExtension('routing')->getPath("change_language");
            echo "\">English version</a>
        ";
        } else {
            // line 134
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route_params"), "method"), array("_locale" => "fr"))), "html", null, true);
            echo "\">Version en français</a>
        ";
        }
        // line 136
        echo "    </div>
    <hr>
<div id=\"content_hints_home\">
    <div class=\"titre\">";
        // line 139
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Actuellement disponibles !"), "html", null, true);
        echo "</div>
    <h1 class=\"soustitre\">
        <span>> ";
        // line 141
        echo $this->env->getExtension('translator')->getTranslator()->trans("A louer", array(), "messages");
        echo " : </span>
        ";
        // line 142
        $context["routeBiensALouer"] = ((($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale") == "fr")) ? ("bien_a_louer") : ("bien_a_louer_en"));
        // line 143
        echo "        ";
        if (($this->getContext($context, "nombreChambresALouer") != 0)) {
            // line 144
            echo "        ";
            $context["nombreChambres"] = $this->getContext($context, "nombreChambresALouer");
            echo " ";
            // line 145
            echo "            <strong>
                <a href=\"";
            // line 146
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_STUDIO", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("chambre"))), "html", null, true);
            echo "\">
                    ";
            // line 147
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 chambre| %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
            // line 150
            echo "                </a>
            </strong>
        ";
        }
        // line 153
        echo "
        ";
        // line 154
        if (($this->getContext($context, "nombreAppartementsALouer") != 0)) {
            // line 155
            echo "        ";
            $context["nombreAppartements"] = $this->getContext($context, "nombreAppartementsALouer");
            // line 156
            echo "        -
            <strong>
                <a href=\"";
            // line 158
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_APPARTEMENT", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("appartement"))), "html", null, true);
            echo "\">
                    ";
            // line 159
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 appartement| %nombreAppartements% appartements", $this->getContext($context, "nombreAppartements"), array("%nombreAppartements%" => $this->getContext($context, "nombreAppartements")), "messages");
            // line 162
            echo "                </a>
            </strong>
        ";
        }
        // line 165
        echo "
        ";
        // line 166
        if (($this->getContext($context, "nombreMaisonsALouer") != 0)) {
            // line 167
            echo "        ";
            $context["nombreMaisons"] = $this->getContext($context, "nombreMaisonsALouer");
            // line 168
            echo "        -
            <strong>
                <a href=\"";
            // line 170
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("maison"))), "html", null, true);
            echo "\">
                    ";
            // line 171
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 maison| %nombreMaisons% maisons", $this->getContext($context, "nombreMaisons"), array("%nombreMaisons%" => $this->getContext($context, "nombreMaisons")), "messages");
            // line 174
            echo "                </a>
            </strong>
        ";
        }
        // line 177
        echo "                   
        ";
        // line 178
        if (($this->getContext($context, "nombreBoutiquesALouer") != 0)) {
            // line 179
            echo "        ";
            $context["nombreBoutiques"] = $this->getContext($context, "nombreBoutiquesALouer");
            // line 180
            echo "        -
            <strong>
                <a href=\"";
            // line 182
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("boutique"))), "html", null, true);
            echo "\">
                    ";
            // line 183
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 boutique| %nombreBoutiques% boutiques", $this->getContext($context, "nombreBoutiques"), array("%nombreBoutiques%" => $this->getContext($context, "nombreBoutiques")), "messages");
            // line 186
            echo "                </a>
            </strong>
        ";
        }
        // line 189
        echo "
        ";
        // line 190
        if (($this->getContext($context, "nombreMagasinsALouer") != 0)) {
            // line 191
            echo "        ";
            $context["nombreMagasins"] = $this->getContext($context, "nombreMagasinsALouer");
            // line 192
            echo "        -
            <strong>
                <a href=\"";
            // line 194
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("magasin"))), "html", null, true);
            echo "\">
                    ";
            // line 195
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 magasin| %nombreMagasins% magasins", $this->getContext($context, "nombreMagasins"), array("%nombreMagasins%" => $this->getContext($context, "nombreMagasins")), "messages");
            // line 198
            echo "                </a>
            </strong>
        ";
        }
        // line 201
        echo "        
        ";
        // line 202
        if (($this->getContext($context, "nombreEntrepotsALouer") != 0)) {
            // line 203
            echo "        ";
            $context["nombreEntrepots"] = $this->getContext($context, "nombreEntrepotsALouer");
            // line 204
            echo "        -
            <strong>
                <a href=\"";
            // line 206
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("entrepôt"))), "html", null, true);
            echo "\">
                    ";
            // line 207
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 entrepôt| %nombreEntrepots% entrepôts", $this->getContext($context, "nombreEntrepots"), array("%nombreEntrepots%" => $this->getContext($context, "nombreEntrepots")), "messages");
            // line 210
            echo "                </a>
            </strong>
        ";
        }
        // line 213
        echo "        
         ";
        // line 214
        if (($this->getContext($context, "nombreBureauxALouer") != 0)) {
            // line 215
            echo "            ";
            $context["nombreBureaux"] = $this->getContext($context, "nombreBureauxALouer");
            // line 216
            echo "            -
                <strong>
                    <a href=\"";
            // line 218
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensALouer"), array("typeBien" => twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("bureau"))), "html", null, true);
            echo "\">
                        ";
            // line 219
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 bureau| %nombreBureaux% bureaux", $this->getContext($context, "nombreBureaux"), array("%nombreBureaux%" => $this->getContext($context, "nombreBureaux")), "messages");
            // line 222
            echo "                    </a>
                </strong>
        ";
        }
        // line 224
        echo ".

    </h1>
    <h1 class=\"soustitre\">
        <span>> ";
        // line 228
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("A vendre"), "html", null, true);
        echo " : </span>
        ";
        // line 229
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale") == "fr")) {
            // line 230
            echo "            ";
            $context["routeBiensAVendre"] = "bien_a_vendre";
            // line 231
            echo "        ";
        } else {
            // line 232
            echo "            ";
            $context["routeBiensAVendre"] = "bien_a_vendre_en";
            // line 233
            echo "        ";
        }
        // line 234
        echo "
        ";
        // line 235
        if (($this->getContext($context, "nombreMaisonsAVendre") != 0)) {
            // line 236
            echo "        ";
            $context["nombreMaisons"] = $this->getContext($context, "nombreMaisonsAVendre");
            // line 237
            echo "            <strong>
                <a href=\"";
            // line 238
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_MAISON", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("maison"))), "html", null, true);
            echo "\">
                    ";
            // line 239
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 maison| %nombreMaisons% maisons", $this->getContext($context, "nombreMaisons"), array("%nombreMaisons%" => $this->getContext($context, "nombreMaisons")), "messages");
            // line 242
            echo "                </a>
            </strong>
        ";
        }
        // line 245
        echo "         
        ";
        // line 246
        if (($this->getContext($context, "nombreTerrainsAVendre") != 0)) {
            // line 247
            echo "        ";
            $context["nombreTerrains"] = $this->getContext($context, "nombreTerrainsAVendre");
            // line 248
            echo "        -
            <strong>
                <a href=\"";
            // line 250
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_TERRAIN", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("terrain"))), "html", null, true);
            echo "\">
                    ";
            // line 251
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 terrain| %nombreTerrains% terrains", $this->getContext($context, "nombreTerrains"), array("%nombreTerrains%" => $this->getContext($context, "nombreTerrains")), "messages");
            // line 254
            echo "                </a>
            </strong>
        ";
        }
        // line 257
        echo "         
        ";
        // line 258
        if (($this->getContext($context, "nombreBoutiquesAVendre") != 0)) {
            // line 259
            echo "        ";
            $context["nombreBoutiques"] = $this->getContext($context, "nombreBoutiquesAVendre");
            // line 260
            echo "        -
            <strong>
                <a href=\"";
            // line 262
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_BOUTIQUE", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("boutique"))), "html", null, true);
            echo "\">
                    ";
            // line 263
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 boutique| %nombreBoutiques% boutiques", $this->getContext($context, "nombreBoutiques"), array("%nombreBoutiques%" => $this->getContext($context, "nombreBoutiques")), "messages");
            // line 266
            echo "                </a>
            </strong>
        ";
        }
        // line 269
        echo "         
        ";
        // line 270
        if (($this->getContext($context, "nombreMagasinsAVendre") != 0)) {
            // line 271
            echo "        ";
            $context["nombreMagasins"] = $this->getContext($context, "nombreMagasinsAVendre");
            // line 272
            echo "        -
            <strong>
                <a href=\"";
            // line 274
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_MAGASIN", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("magasin"))), "html", null, true);
            echo "\">
                    ";
            // line 275
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 magasin| %nombreMagasins% magasins", $this->getContext($context, "nombreMagasins"), array("%nombreMagasins%" => $this->getContext($context, "nombreMagasins")), "messages");
            // line 278
            echo "                </a>
            </strong>
        ";
        }
        // line 281
        echo "         
        ";
        // line 282
        if (($this->getContext($context, "nombreEntrepotsAVendre") != 0)) {
            // line 283
            echo "        ";
            $context["nombreEntrepots"] = $this->getContext($context, "nombreEntrepotsAVendre");
            // line 284
            echo "        -
            <strong>
                <a href=\"";
            // line 286
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_ENTREPOT", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("entrepôt"))), "html", null, true);
            echo "\">
                    ";
            // line 287
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 entrepôt| %nombreEntrepots% entrepôts", $this->getContext($context, "nombreEntrepots"), array("%nombreEntrepots%" => $this->getContext($context, "nombreEntrepots")), "messages");
            // line 290
            echo "                </a>
            </strong>
        ";
        }
        // line 293
        echo "
        ";
        // line 294
        if (($this->getContext($context, "nombreBureauxAVendre") != 0)) {
            // line 295
            echo "        ";
            $context["nombreBureaux"] = $this->getContext($context, "nombreBureauxAVendre");
            // line 296
            echo "        -
            <strong>
                <a href=\"";
            // line 298
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getContext($context, "routeBiensAVendre"), array("typeBien" => twig_constant("TYPE_BIEN_BUREAU", $this->getContext($context, "ReferenceData")), "libelle_type_bien" => $this->env->getExtension('translator')->trans("bureau"))), "html", null, true);
            echo "\">
                    ";
            // line 299
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 bureau| %nombreBureaux% bureaux", $this->getContext($context, "nombreBureaux"), array("%nombreBureaux%" => $this->getContext($context, "nombreBureaux")), "messages");
            // line 302
            echo "                </a>
            </strong>
        ";
        }
        // line 305
        echo "
    </h1>
</div>

<div id=\"content_news_home\">
    <p class=\"titre\">Koutchoumi news:</p>
    > <a href=\"http://blog.koutchoumi.com/koutchoumi-com-devoile-son-widget-pour-les-webmasters/2011/03/\" target=\"_blank\">";
        // line 311
        echo $this->env->getExtension('translator')->getTranslator()->trans("koutchoumi.com dévoile son widget pour les webmasters", array(), "messages");
        echo "</a>
</div>
    <div class=\"RAS\"></div>
    <hr>
    <div style=\"background-color: #f5f5f5;padding-top: 5px\">
        <div style=\"float: left; width: 240px\">
            <div>
                ";
        // line 318
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "4e4cb77_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4e4cb77_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/4e4cb77_newsletter_icon_1.png");
            // line 319
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("newsletter"), "html", null, true);
            echo "\" title=\"";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
            echo "\" aligh=\"left\" />
                ";
        } else {
            // asset "4e4cb77"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4e4cb77") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/4e4cb77.png");
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("newsletter"), "html", null, true);
            echo "\" title=\"";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
            echo "\" aligh=\"left\" />
                ";
        }
        unset($context["asset_url"]);
        // line 321
        echo "                <a href=\"http://eepurl.com/caVOn\" style=\"font-size: 14px; font-weight: bold;margin-left: 5px\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Rejoignez notre newsletter"), "html", null, true);
        echo "</a>
            </div>
            <div style=\"color: #665;margin-left: 33px\">";
        // line 323
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("...et recevez nos bons plans 2 fois par mois !"), "html", null, true);
        echo "</div>
        </div>
        <div style=\"float: left; width: 215px; margin-left: 5px\">
            <div>
                <a href=\"http://twitter.com/koutchoumi\" class=\"twitter-follow-button\" data-show-count=\"false\" data-lang=\"";
        // line 327
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale"), "html", null, true);
        echo "\">Follow @koutchoumi</a>
            </div>
            <div style=\"color: #665;margin-left: 26px\">";
        // line 329
        echo $this->env->getExtension('translator')->trans("Pour l'actu immobilière au Cameroun en temps réel!");
        echo " </div>
        </div>
        <div style=\"float: left; width: 115px; margin-left: 5px\">
            <div>
                ";
        // line 333
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "ab6e7da_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ab6e7da_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/ab6e7da_facebook_logo_1.png");
            // line 334
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi sur facebook"), "html", null, true);
            echo "\" title=\"";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Koutchoumi.com sur facebook", array(), "messages");
            echo "\" aligh=\"left\" />
                ";
        } else {
            // asset "ab6e7da"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ab6e7da") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/ab6e7da.png");
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi sur facebook"), "html", null, true);
            echo "\" title=\"";
            echo $this->env->getExtension('translator')->getTranslator()->trans("Koutchoumi.com sur facebook", array(), "messages");
            echo "\" aligh=\"left\" />
                ";
        }
        unset($context["asset_url"]);
        // line 336
        echo "            </div>
            
        </div>
        <div class=\"RAS\"></div>
    </div>
    
</div>
";
        // line 343
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "11f0b70_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_11f0b70_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/11f0b70_part_1.js");
            // line 344
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\"></script>
";
            // asset "11f0b70_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_11f0b70_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/11f0b70_part_2_createWidget_1.js");
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\"></script>
";
            // asset "11f0b70_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_11f0b70_2") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/11f0b70_part_2_frontend_index_2.js");
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\"></script>
";
        } else {
            // asset "11f0b70"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_11f0b70") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/11f0b70.js");
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\"></script>
";
        }
        unset($context["asset_url"]);
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  735 => 344,  731 => 343,  722 => 336,  700 => 334,  696 => 333,  689 => 329,  684 => 327,  677 => 323,  671 => 321,  649 => 319,  645 => 318,  635 => 311,  627 => 305,  622 => 302,  620 => 299,  616 => 298,  612 => 296,  609 => 295,  607 => 294,  604 => 293,  599 => 290,  597 => 287,  593 => 286,  589 => 284,  586 => 283,  584 => 282,  581 => 281,  576 => 278,  574 => 275,  570 => 274,  566 => 272,  563 => 271,  561 => 270,  558 => 269,  553 => 266,  551 => 263,  547 => 262,  543 => 260,  540 => 259,  538 => 258,  535 => 257,  530 => 254,  528 => 251,  524 => 250,  520 => 248,  517 => 247,  515 => 246,  512 => 245,  507 => 242,  505 => 239,  501 => 238,  498 => 237,  495 => 236,  493 => 235,  490 => 234,  487 => 233,  484 => 232,  481 => 231,  478 => 230,  476 => 229,  472 => 228,  466 => 224,  461 => 222,  459 => 219,  455 => 218,  451 => 216,  448 => 215,  446 => 214,  443 => 213,  438 => 210,  436 => 207,  432 => 206,  428 => 204,  425 => 203,  423 => 202,  420 => 201,  415 => 198,  413 => 195,  409 => 194,  405 => 192,  402 => 191,  400 => 190,  397 => 189,  392 => 186,  390 => 183,  386 => 182,  382 => 180,  379 => 179,  377 => 178,  374 => 177,  369 => 174,  367 => 171,  363 => 170,  359 => 168,  356 => 167,  354 => 166,  351 => 165,  346 => 162,  344 => 159,  340 => 158,  336 => 156,  333 => 155,  331 => 154,  328 => 153,  323 => 150,  321 => 147,  317 => 146,  314 => 145,  310 => 144,  307 => 143,  305 => 142,  301 => 141,  296 => 139,  291 => 136,  285 => 134,  279 => 132,  276 => 131,  274 => 130,  271 => 129,  262 => 123,  257 => 121,  251 => 117,  247 => 115,  245 => 114,  240 => 112,  236 => 111,  232 => 110,  228 => 109,  224 => 108,  218 => 105,  214 => 104,  210 => 103,  206 => 102,  202 => 101,  198 => 100,  193 => 98,  189 => 97,  185 => 96,  180 => 94,  176 => 93,  170 => 90,  166 => 89,  160 => 86,  156 => 85,  151 => 83,  146 => 80,  142 => 77,  136 => 75,  133 => 74,  130 => 72,  128 => 71,  125 => 70,  122 => 69,  116 => 66,  114 => 65,  112 => 64,  109 => 61,  107 => 60,  105 => 59,  102 => 56,  100 => 55,  98 => 54,  95 => 51,  93 => 50,  91 => 49,  88 => 46,  86 => 45,  84 => 44,  81 => 41,  79 => 40,  77 => 39,  74 => 36,  72 => 35,  70 => 34,  67 => 31,  65 => 30,  63 => 29,  60 => 26,  58 => 25,  56 => 24,  53 => 21,  51 => 20,  49 => 17,  47 => 16,  45 => 15,  43 => 14,  41 => 13,  39 => 12,  37 => 9,  35 => 8,  33 => 7,  31 => 6,  29 => 5,  27 => 4,  25 => 3,);
    }
}
