<?php

/* KoutchoumiFrontendBundle::detailsBien.html.twig */
class __TwigTemplate_da486e0093bc0ca4a702be9b3d23bc1db2ca748bb89e9c45be6a8a5185980ca8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("KoutchoumiFrontendBundle::layout.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "KoutchoumiFrontendBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "<script type=\"text/javascript\">
\t\$(function() {
\t\t\$( \"#tabs\" ).tabs();
\t});
</script>

<div id=\"vue\">
    <div id=\"vue_top\">
        <span style=\"float: left;\">R&eacute;f. : ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "reference"), "html", null, true);
        echo "</span>
        <span style=\"float: right;\"><a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("homepage_i18n");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Trouvez d'autres biens immobiliers", array(), "messages");
        echo "</a></span>
        <span style=\"clear:both\"></span>
    </div>
    ";
        // line 17
        if (call_user_func_array($this->env->getTest('Appartement')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 18
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienAppartement.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo"), "ReferenceData" => $this->getContext($context, "ReferenceData")));
            echo "
    ";
        }
        // line 20
        echo "    ";
        if (call_user_func_array($this->env->getTest('Terrain')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 21
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienTerrain.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 23
        echo "    ";
        if (call_user_func_array($this->env->getTest('Maison')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 24
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienMaison.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 26
        echo "    ";
        if (call_user_func_array($this->env->getTest('BlocTerrain')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 27
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienBlocTerrain.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 29
        echo "    ";
        if (call_user_func_array($this->env->getTest('Studio')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 30
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienStudio.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 32
        echo "    ";
        if (call_user_func_array($this->env->getTest('Magasin')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 33
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienMagasin.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 35
        echo "    ";
        if (call_user_func_array($this->env->getTest('Entrepot')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 36
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienEntrepot.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 38
        echo "    ";
        if (call_user_func_array($this->env->getTest('Boutique')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 39
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienBoutique.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 41
        echo "    ";
        if (call_user_func_array($this->env->getTest('Bureau')->getCallable(), array($this->getContext($context, "bienImmo")))) {
            // line 42
            echo "        ";
            echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_detailsBienBureau.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
            echo "
    ";
        }
        // line 44
        echo "
    <div id=\"vue_right\">
        <div class=\"vue_right_element\">
            <span class=\"span\">";
        // line 47
        echo $this->env->getExtension('translator')->getTranslator()->trans("Contactez l'annonceur", array(), "messages");
        echo "</span>
            ";
        // line 48
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_bloc_contact_annonceur.html.twig", array("bienImmo" => $this->getContext($context, "bienImmo")));
        echo "
        </div>
        <div class=\"vue_right_element\">
            <span class=\"span\">";
        // line 51
        echo twig_escape_filter($this->env, strtr($this->env->getExtension('translator')->trans("Services disponibles à %1%"), array("%1%" => $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "nom"))), "html", null, true);
        echo "</span>
            ";
        // line 52
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_showServicesAndFacilities.html.twig", array("quartier" => $this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "servicesByType" => $this->getContext($context, "servicesByType"), "typesServicesInShortView" => $this->getContext($context, "typesServicesInShortView")));
        echo "
        </div>
        <div class=\"vue_right_element\">
            <span class=\"span\">";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Partagez cette annonce"), "html", null, true);
        echo "</span>
            ";
        // line 56
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_virality.html.twig", array("showText" => 0));
        echo "
        </div>
        <div class=\"vue_right_element\">
            <span class=\"span\">";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Vous apprécierez peut-être aussi..."), "html", null, true);
        echo "</span>
            ";
        // line 60
        $context["biensSimilaires"] = $this->env->getExtension('usermanager_extension')->getBiensSimilaires($this->getContext($context, "bienImmo"), $this->getContext($context, "nombreBiensSimilairesAAfficher"));
        // line 61
        echo "            ";
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_showBiensSimilaires.html.twig", array("ReferenceData" => $this->getContext($context, "ReferenceData"), "biensSimilaires" => $this->getContext($context, "biensSimilaires"), "messageIfNothing" => $this->env->getExtension('translator')->trans("Désolé, mais nous n'avons pas d'autres biens immobiliers similaires à celui-ci.")));
        echo "
        </div>
    </div>
</div>
<div class=\"RAS\"></div>

<script language=\"javascript\" type=\"text/javascript\">
    function setMainPhoto(src)
    {
        document.getElementById('mainPhoto').src = src;
    }
    var addthis_config = {
        services_expanded : 'digg, myspace, stumbleupon, reddit, favorites, buzz, pdfonline, yahoomail, gmail, linkedin, live, print',
        ui_language: \"";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale"), "html", null, true);
        echo "\",
        data_track_clickback: true
    }
</script>
";
        // line 79
        echo "<script type=\"text/javascript\" src=\"http://s7.addthis.com/js/250/addthis_widget.js#username=pattchen\"></script>
";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::detailsBien.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 79,  191 => 74,  174 => 61,  172 => 60,  168 => 59,  162 => 56,  158 => 55,  152 => 52,  148 => 51,  142 => 48,  138 => 47,  133 => 44,  127 => 42,  124 => 41,  118 => 39,  115 => 38,  109 => 36,  106 => 35,  100 => 33,  97 => 32,  91 => 30,  88 => 29,  82 => 27,  79 => 26,  73 => 24,  70 => 23,  64 => 21,  61 => 20,  55 => 18,  53 => 17,  45 => 14,  41 => 13,  31 => 5,  28 => 2,);
    }
}
