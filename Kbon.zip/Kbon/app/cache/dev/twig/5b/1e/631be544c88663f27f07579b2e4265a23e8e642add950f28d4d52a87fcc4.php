<?php

/* KoutchoumiFrontendBundle::trouverBien.html.twig */
class __TwigTemplate_5b1e631be544c88663f27f07579b2e4265a23e8e642add950f28d4d52a87fcc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("KoutchoumiFrontendBundle::layout.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "KoutchoumiFrontendBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"content_result_page\">
    <div class=\"RAS\"></div>
    
    ";
        // line 6
        echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::panelNewRefineSearchResults.html.twig", array("typeBien" => $this->getContext($context, "typeBien"), "form" => $this->getContext($context, "trouverBienAvanceForm")));
        echo "
    <div id=\"right\">
        <div id=\"alert_box\" style=\"margin-bottom: 4px\">
            <p>";
        // line 9
        echo $this->env->getExtension('translator')->trans("<strong><a href=\"#\" id=\"enregistrer-recherche\">Alertez-moi par email</a> des nouveaux résultats</strong> de cette recherche");
        echo ".</p>
        </div>
        
        <div class=\"head2\">
        
                ";
        // line 15
        echo "                ";
        // line 16
        echo "        
            <p class=\"margin2\">
                ";
        // line 18
        echo " ";
        // line 19
        echo "            </p>
        </div>
        ";
        // line 21
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "listebiens"));
        foreach ($context['_seq'] as $context["_key"] => $context["unbienimmo"]) {
            // line 22
            echo "            ";
            if (call_user_func_array($this->env->getTest('Appartement')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 23
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewAppartement.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 24
            echo " 
            ";
            // line 25
            if (call_user_func_array($this->env->getTest('BlocTerrain')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 26
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewBlocTerrain.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 27
            echo " 
            ";
            // line 28
            if (call_user_func_array($this->env->getTest('Boutique')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 29
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewBoutique.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 30
            echo " 
            ";
            // line 31
            if (call_user_func_array($this->env->getTest('Bureau')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 32
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewBureau.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 33
            echo " 
            ";
            // line 34
            if (call_user_func_array($this->env->getTest('Entrepot')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 35
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewEntrepot.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 36
            echo " 
            ";
            // line 37
            if (call_user_func_array($this->env->getTest('Magasin')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 38
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewMagasin.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 39
            echo " 
            ";
            // line 40
            if (call_user_func_array($this->env->getTest('Maison')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 41
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewMaison.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 43
            echo "            ";
            if (call_user_func_array($this->env->getTest('Studio')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 44
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewStudio.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 46
            echo "            ";
            if (call_user_func_array($this->env->getTest('Terrain')->getCallable(), array($this->getContext($context, "unbienimmo")))) {
                // line 47
                echo "                ";
                echo twig_include($this->env, $context, "KoutchoumiFrontendBundle::_shortViewTerrain.html.twig", array("bienImmo" => $this->getContext($context, "unbienimmo")));
                echo "
            ";
            }
            // line 49
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unbienimmo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "
";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::trouverBien.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 50,  159 => 49,  153 => 47,  150 => 46,  144 => 44,  141 => 43,  135 => 41,  133 => 40,  130 => 39,  124 => 38,  122 => 37,  119 => 36,  113 => 35,  111 => 34,  108 => 33,  102 => 32,  100 => 31,  97 => 30,  91 => 29,  89 => 28,  86 => 27,  80 => 26,  78 => 25,  75 => 24,  69 => 23,  66 => 22,  62 => 21,  58 => 19,  56 => 18,  52 => 16,  50 => 15,  42 => 9,  36 => 6,  31 => 3,  28 => 2,);
    }
}
