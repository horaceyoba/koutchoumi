<?php

/* KoutchoumiFrontendBundle::_shortViewTerrain.html.twig */
class __TwigTemplate_2bbecf030b0c3a88bba15d185987437d066460775f6d00f9145d2edeb448365c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["url"] = $this->env->getExtension('usermanager_extension')->generateURLForBienImmobilierI18n($this->getContext($context, "bienImmo"), $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale"));
        // line 2
        echo "<div class=\"content_result\">
    <h1 class=\"title_blue\">
        <a href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">
            ";
        // line 5
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "blocBienId") == null)) {
            // line 6
            echo "                ";
            echo twig_escape_filter($this->env, ((strtr($this->env->getExtension('translator')->trans("Terrain %1% m2"), array("%1%" => twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surface"), 0, ".", " "))) . " ") . $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method")), "html", null, true);
            echo "
            ";
        } else {
            // line 8
            echo "                ";
            echo twig_escape_filter($this->env, ((strtr($this->env->getExtension('translator')->trans("Lot de terrain %1% m2"), array("%1%" => twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surface"), 0, ".", " "))) . " ") . $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method")), "html", null, true);
            echo "                
            ";
        }
        // line 10
        echo "            ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "ville"), "nom"), "html", null, true);
        echo "/";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "nom"), "html", null, true);
        echo "
        </a>
    </h1>
    <em class=\"margin6\">
        ";
        // line 14
        $context["dateDiff"] = $this->env->getExtension('usermanager_extension')->dateDiffInPlainText(twig_date_format_filter($this->env, "now", "Y-m-d"), twig_date_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "datePublication"), "Y-m-d"));
        // line 15
        echo "        ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("publié"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "dateDiff"), "html", null, true);
        echo " - ";
        echo strtr($this->env->getExtension('translator')->trans("vu <strong>%1%</strong> fois"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreHits")));
        echo "
    </em>
      <table width=\"440\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
          <tr>
            <td width=\"126\" rowspan=\"2\" align=\"center\" valign=\"middle\">
                ";
        // line 20
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale") != null)) {
            // line 21
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale"), "chemin")), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "title"), "html", null, true);
            echo "\" width=\"120\" height=\"120\" />
                ";
        } else {
            // line 23
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/koutchoumifrontend/images/default_photo.png"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi Immobilier"), "html", null, true);
            echo "\" />
                ";
        }
        // line 25
        echo "            </td>
            <td width=\"162\" height=\"98\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">
                    <li>";
        // line 28
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "prix"), 0, ".", " "), "html", null, true);
        echo " FCFA</li>
                    <li>";
        // line 29
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "surface"), 0, ".", " "), "html", null, true);
        echo " m<sup>2</sup></li>
                </ul>
            </td>
            <td width=\"162\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">
                     ";
        // line 34
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "blocBienId") == null)) {
            // line 35
            echo "                        <li> ";
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getContext($context, "bienImmo"), "titre")) ? (("> " . $this->env->getExtension('translator')->trans("Titré"))) : (("> " . $this->env->getExtension('translator')->trans("Non titré")))), "html", null, true);
            echo " </li>
                        <li> ";
            // line 36
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getContext($context, "bienImmo"), "bati")) ? (("> " . $this->env->getExtension('translator')->trans("Bâti"))) : ("")), "html", null, true);
            echo " </li>
                    ";
        } else {
            // line 38
            echo "                        <li> ";
            echo ">";
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Bloc"), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "getBienImmobilierRelatedByBlocBienId", array(), "method"), "getReferenceMetier", array(), "method"), "html", null, true);
            echo " </li>
                    ";
        }
        // line 40
        echo "                </ul>
            </td>
          </tr>
          <tr>
            <td colspan=\"2\" align=\"left\" valign=\"middle\">
                <p class=\"p_result\">
                    <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Voir plus de détails"), "html", null, true);
        echo "</a>
                </p>
            </td>
          </tr>
          <tr>
            <td align=\"center\" valign=\"middle\"><span>";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "nombrePhotos"), "html", null, true);
        echo " photo(s)</span></td>
            <td colspan=\"2\" align=\"left\" valign=\"top\">&nbsp;</td> 
          </tr>
    </table>
</div>";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_shortViewTerrain.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 51,  137 => 46,  129 => 40,  119 => 38,  114 => 36,  109 => 35,  107 => 34,  97 => 29,  91 => 28,  86 => 25,  78 => 23,  70 => 21,  68 => 20,  55 => 15,  53 => 14,  43 => 10,  37 => 8,  31 => 6,  29 => 5,  25 => 4,  21 => 2,  19 => 1,);
    }
}
