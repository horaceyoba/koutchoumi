<?php

/* KoutchoumiFrontendBundle::layout.html.twig */
class __TwigTemplate_97de76824aabaca6572912bd14c630afe0d2f4cdc967e82609f54f9d80d3c3e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["userlocale"] = $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale");
        // line 2
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"";
        // line 3
        echo twig_escape_filter($this->env, twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2), "html", null, true);
        echo "\">
  <head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
    <meta name=\"title\" content=\"Studios, appartements, maisons, terrains et locaux commerciaux à louer ou à vendre à Douala et Yaoundé – koutchoumi.com\" />
    <meta name=\"description\" content=\"Trouvez des studios, appartements, maisons, terrains, boutiques, magasins et entrepots à louer ou à vendre à Douala et Yaoundé au Cameroun – koutchoumi.com\" />
    <meta name=\"keywords\" content=\"immobilier au Cameroun, maison à louer, maison à vendre, studio à louer, appartement à louer à yaoundé, appartement à louer à douala, chambre à louer, terrain à vendre, villa à louer, villa à vendre, duplex à vendre, duplex à louer, magasin à louer, magasin à vendre, entrepot à louer, entrepot à vendre, boutique à louer, boutique à vendre, immobilier à douala, immobilier à yaoundé, koutchoumi\" />

    <title> ";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Studios, appartements, maisons, terrains et locaux commerciaux à louer ou à vendre à Douala et Yaoundé – koutchoumi.com"), "html", null, true);
        echo " </title>
    
    <link rel=\"shortcut icon\" href=\"/favicon.ico\" />
    <link rel=\"alternate\" type=\"application/rss+xml\" title=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Dernières annonces immobilières au Cameroun sur koutchoumi.com"), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('routing')->getPath("rss_feed_latest_ads");
        echo "\" /> ";
        // line 14
        echo "    ";
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "attributes"), "get", array(0 => "_template"), "method") != "index")) {
            echo " ";
            // line 15
            echo "    ";
            // line 16
            echo "    <style type=\"text/css\">
            .k_dialog, .k_dialogSuccess, .ui-dialog-titlebar, .ui-dialog-buttonpane { font-size: 62.5%; }
            .k_dialog label, #dialog input { display:block; }
            .k_dialog input.text { margin-bottom:12px; width:95%; padding: .4em; }
            .k_dialog fieldset { padding:0; border:0; margin-top:25px; }
            .ui-dialog .ui-state-highlight, .ui-dialog .ui-state-error { padding: .3em;  }
    </style>
    ";
        }
        // line 24
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "f27ced3_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_contact_1.css");
            // line 25
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_enregistrer_bien_2.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_2") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_gerer_photo_3.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_3") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_global_4.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_4") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_jquery.wysiwyg_5.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_5"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_5") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_login_6.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_6"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_6") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_result_7.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
            // asset "f27ced3_7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3_7") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3_part_1_styles-min_8.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "f27ced3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f27ced3") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/f27ced3.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 27
        echo "  </head>
    
  <body>
      <div id=\"main\">
          <div id=\"header\">
              <div id=\"header_content\">
                  <div id=\"header_top\">
                      <span class=\"left\">
                          ";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('usermanager_extension')->compterBien(), "html", null, true);
        echo " ";
        echo $this->env->getExtension('translator')->getTranslator()->trans("annonces", array(), "messages");
        // line 36
        echo "                          ";
        if (($this->env->getExtension('usermanager_extension')->getActionName() != "index")) {
            // line 37
            echo "                          | <a href=\"";
            echo $this->env->getExtension('routing')->getPath("homepage_i18n");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Accueil"), "html", null, true);
            echo "</a>
                          ";
        }
        // line 39
        echo "                           |
                            ";
        // line 40
        if ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "fr")) {
            // line 41
            echo "                                ";
            // line 42
            echo "                                <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
            echo "\">English</a>
                            ";
        } else {
            // line 44
            echo "                                ";
            // line 45
            echo "                                <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
            echo "\">Français</a>
                            ";
        }
        // line 47
        echo "                      </span>
                      <span class=\"right\"><a href=\"";
        // line 48
        echo $this->env->getExtension('routing')->getPath("annonceur");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Publiez une annonce", array(), "messages");
        echo "</a></span>
                  </div>
                  <div id=\"header_ban\">
                      <a href=\"";
        // line 51
        echo $this->env->getExtension('routing')->getPath("homepage_i18n");
        echo "\">
                      ";
        // line 52
        if ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "fr")) {
            // line 53
            echo "                        ";
            if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
                // asset "99403f3_0"
                $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_99403f3_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/99403f3_logo_ban_1.png");
                // line 54
                echo "                            <img src=\"";
                echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Louer et acheter des appartements, maisons, terrains, magasins, entrepôts et boutiques à Douala ou Yaoundé"), "html", null, true);
                echo "\" title=\"";
                echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
                echo "\" aligh=\"left\" />
                        ";
            } else {
                // asset "99403f3"
                $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_99403f3") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/99403f3.png");
                echo "                            <img src=\"";
                echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Louer et acheter des appartements, maisons, terrains, magasins, entrepôts et boutiques à Douala ou Yaoundé"), "html", null, true);
                echo "\" title=\"";
                echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
                echo "\" aligh=\"left\" />
                        ";
            }
            unset($context["asset_url"]);
            // line 56
            echo "                      ";
        } elseif ((twig_slice($this->env, $this->getContext($context, "userlocale"), 0, 2) == "en")) {
            // line 57
            echo "                        ";
            if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
                // asset "99403f3_0"
                $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_99403f3_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/99403f3_logo_ban_1.png");
                // line 58
                echo "                                <img src=\"";
                echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Louer et acheter des appartements, maisons, terrains, magasins, entrepôts et boutiques à Douala ou Yaoundé"), "html", null, true);
                echo "\" title=\"";
                echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
                echo "\" aligh=\"left\" />
                        ";
            } else {
                // asset "99403f3"
                $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_99403f3") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/99403f3.png");
                echo "                                <img src=\"";
                echo twig_escape_filter($this->env, $this->getContext($context, "asset_url"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Louer et acheter des appartements, maisons, terrains, magasins, entrepôts et boutiques à Douala ou Yaoundé"), "html", null, true);
                echo "\" title=\"";
                echo $this->env->getExtension('translator')->getTranslator()->trans("Page d'accueil", array(), "messages");
                echo "\" aligh=\"left\" />
                        ";
            }
            unset($context["asset_url"]);
            // line 60
            echo "                       ";
        }
        // line 61
        echo "                      </a>
                  </div>
              </div>
          </div>
          <div id=\"content\">
              ";
        // line 66
        $this->displayBlock('body', $context, $blocks);
        // line 68
        echo "          </div>
          <br/>
          <div id=\"footer\">
              ";
        // line 71
        if (($this->env->getExtension('usermanager_extension')->getActionName() != "index")) {
            // line 72
            echo "              <div>
                  <ul>
                      <li>";
            // line 74
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Restez connecté"), "html", null, true);
            echo " :</li>
                      <li>
                          <a href=\"http://eepurl.com/caVOn\" style=\"margin-left: 5px\">";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("newsletter"), "html", null, true);
            echo "</a>
                      </li>
                      <li>
                          <a href=\"http://www.twitter.com/koutchoumi\" style=\"margin-left: 5px\">twitter</a>
                      </li>
                      <li>
                          <a href=\"http://www.facebook.com/koutchoumi\" style=\"margin-left: 5px\">facebook</a>
                      </li>
                  </ul>
              </div>
              ";
        }
        // line 87
        echo "              <div id=\"footer_menu\">
                  <ul>
                      <li><a href=\"http://blog.koutchoumi.com\">";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Actu de koutchoumi.com et de l'immobilier"), "html", null, true);
        echo "</a> </li> |
                      <li><a href=\"";
        // line 90
        echo $this->env->getExtension('routing')->getPath("why_koutchoumi");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Pourquoi koutchoumi.com", array(), "messages");
        echo "</a> </li> |
                      <li><a href=\"";
        // line 91
        echo $this->env->getExtension('routing')->getPath("contact_koutchoumi");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Contactez-nous", array(), "messages");
        echo "</a> </li> |
                      <li><a href=\"";
        // line 92
        echo $this->env->getExtension('routing')->getPath("conditions_utilisations_koutchoumi");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Conditions d'utilisations", array(), "messages");
        echo "</a> </li> </ul>
                  <ul style=\"margin-top: 10px\">
                      <li><a href=\"";
        // line 94
        echo $this->env->getExtension('routing')->getPath("invite_i18n");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Parlez de nous à vos amis", array(), "messages");
        echo "</a> </li>
                      <li><a href=\"";
        // line 95
        echo $this->env->getExtension('routing')->getPath("rss_feed_latest_ads");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Fil RSS", array(), "messages");
        echo "</a> </li>
                      <li><a href=\"";
        // line 96
        echo $this->env->getExtension('routing')->getPath("create_widget");
        echo "\">";
        echo $this->env->getExtension('translator')->getTranslator()->trans("Widget Koutchoumi", array(), "messages");
        echo "</a> </li>
                  </ul>
                  <br />
                  <p class=\"copyright\">Copyright © 2009 - 2012 ";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi Immobilier"), "html", null, true);
        echo ".</p>
              </div>
          </div>
           ";
        // line 102
        if (($this->env->getExtension('usermanager_extension')->getActionName() == "index")) {
            // line 103
            echo "            <div id=\"footer-seo\">

            <div id=\"footer-seo-1\">
            <h2>";
            // line 106
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("A louer à Douala"), "html", null, true);
            echo "</h2>
            <ul>
            <li><a href=\"";
            // line 108
            echo $this->env->getExtension('routing')->getPath(("studios_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Chambres à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 109
            echo $this->env->getExtension('routing')->getPath(("appartements_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Appartements à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 110
            echo $this->env->getExtension('routing')->getPath(("maisons_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Maisons à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 111
            echo $this->env->getExtension('routing')->getPath(("bureaux_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Bureaux à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 112
            echo $this->env->getExtension('routing')->getPath(("boutiques_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Boutiques à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 113
            echo $this->env->getExtension('routing')->getPath(("magasins_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Magasins à louer à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 114
            echo $this->env->getExtension('routing')->getPath(("entrepots_a_louer_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Entrepots à louer à Douala"), "html", null, true);
            echo "</a></li>
            </ul>
            </div>

            <div id=\"footer-seo-2\">
            <h2>";
            // line 119
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("A vendre à Douala"), "html", null, true);
            echo "</h2>
            <ul>
            <li><a href=\"";
            // line 121
            echo $this->env->getExtension('routing')->getPath(("maisons_a_vendre_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Maisons à vendre à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 122
            echo $this->env->getExtension('routing')->getPath(("terrains_a_vendre_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Terrains à vendre à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 123
            echo $this->env->getExtension('routing')->getPath(("boutiques_a_vendre_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Boutiques à vendre à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 124
            echo $this->env->getExtension('routing')->getPath(("magasins_a_vendre_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Magasins à vendre à Douala"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 125
            echo $this->env->getExtension('routing')->getPath(("entrepots_a_vendre_a_douala_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Entrepots à vendre à Douala"), "html", null, true);
            echo "</a></li>
            </ul>
            </div>

            <div id=\"footer-seo-3\">
            <h2>";
            // line 130
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("A louer à Yaoundé"), "html", null, true);
            echo "</h2>
            <ul>
            <li><a href=\"";
            // line 132
            echo $this->env->getExtension('routing')->getPath(("studios_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Chambres à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 133
            echo $this->env->getExtension('routing')->getPath(("appartements_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Appartements à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 134
            echo $this->env->getExtension('routing')->getPath(("maisons_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Maisons à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 135
            echo $this->env->getExtension('routing')->getPath(("bureaux_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Bureaux à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 136
            echo $this->env->getExtension('routing')->getPath(("boutiques_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Boutiques à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 137
            echo $this->env->getExtension('routing')->getPath(("magasins_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Magasins à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 138
            echo $this->env->getExtension('routing')->getPath(("entrepots_a_louer_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Entrepots à louer à Yaoundé"), "html", null, true);
            echo "</a></li>
            </ul>
            </div>

            <div id=\"footer-seo-4\">
            <h2>";
            // line 143
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("A vendre à Yaoundé"), "html", null, true);
            echo "</h2>
            <ul>
            <li><a href=\"";
            // line 145
            echo $this->env->getExtension('routing')->getPath(("maisons_a_vendre_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Maisons à vendre à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 146
            echo $this->env->getExtension('routing')->getPath(("terrains_a_vendre_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Terrains à vendre à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 147
            echo $this->env->getExtension('routing')->getPath(("boutiques_a_vendre_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Boutiques à vendre à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 148
            echo $this->env->getExtension('routing')->getPath(("magasins_a_vendre_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Magasins à vendre à Yaoundé"), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 149
            echo $this->env->getExtension('routing')->getPath(("entrepots_a_vendre_a_yaounde_" . $this->getContext($context, "userlocale")));
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Entrepots à vendre à Yaoundé"), "html", null, true);
            echo "</a></li>
            </ul>
            </div>

            <span class=\"RAS\" style=\"display: block\"></span>

            </div>
          ";
        }
        // line 157
        echo "      </div>
";
        // line 159
        echo "<script type=\"text/javascript\">
var gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");
document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));
</script>
<script type=\"text/javascript\">try {var pageTracker = _gat._getTracker(\"UA-11910432-1\");pageTracker._trackPageview();} catch(err) {}</script>
  </body>
</html>";
    }

    // line 66
    public function block_body($context, array $blocks = array())
    {
        // line 67
        echo "              ";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  546 => 67,  543 => 66,  533 => 159,  530 => 157,  517 => 149,  511 => 148,  505 => 147,  499 => 146,  493 => 145,  488 => 143,  478 => 138,  472 => 137,  466 => 136,  460 => 135,  454 => 134,  448 => 133,  442 => 132,  437 => 130,  427 => 125,  421 => 124,  415 => 123,  409 => 122,  403 => 121,  398 => 119,  388 => 114,  382 => 113,  376 => 112,  370 => 111,  364 => 110,  358 => 109,  352 => 108,  347 => 106,  342 => 103,  340 => 102,  334 => 99,  326 => 96,  320 => 95,  314 => 94,  307 => 92,  301 => 91,  295 => 90,  291 => 89,  287 => 87,  273 => 76,  268 => 74,  264 => 72,  262 => 71,  257 => 68,  255 => 66,  248 => 61,  245 => 60,  223 => 58,  218 => 57,  215 => 56,  193 => 54,  188 => 53,  186 => 52,  182 => 51,  174 => 48,  171 => 47,  163 => 44,  157 => 42,  155 => 41,  142 => 37,  139 => 36,  125 => 27,  64 => 24,  54 => 16,  48 => 14,  43 => 13,  37 => 10,  25 => 3,  22 => 2,  20 => 1,  165 => 45,  159 => 49,  153 => 40,  150 => 39,  144 => 44,  141 => 43,  135 => 35,  133 => 40,  130 => 39,  124 => 38,  122 => 37,  119 => 36,  113 => 35,  111 => 34,  108 => 33,  102 => 32,  100 => 31,  97 => 30,  91 => 29,  89 => 28,  86 => 27,  80 => 26,  78 => 25,  75 => 24,  69 => 25,  66 => 22,  62 => 21,  58 => 19,  56 => 18,  52 => 15,  50 => 15,  42 => 9,  36 => 6,  31 => 3,  28 => 2,);
    }
}
