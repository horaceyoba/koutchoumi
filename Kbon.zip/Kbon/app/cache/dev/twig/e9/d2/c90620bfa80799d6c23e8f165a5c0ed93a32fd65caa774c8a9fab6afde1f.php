<?php

/* KoutchoumiFrontendBundle::_shortViewAppartement.html.twig */
class __TwigTemplate_e9d2c90620bfa80799d6c23e8f165a5c0ed93a32fd65caa774c8a9fab6afde1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["ville"] = $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "ville"), "nom");
        // line 2
        $context["quartier"] = $this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "quartier"), "nom");
        // line 3
        if ((null === $this->getAttribute($this->getContext($context, "bienImmo"), "nombreChambres"))) {
            // line 4
            echo "    ";
            $context["nombreChambres"] = "";
        } else {
            // line 6
            echo "    ";
            $context["nombreChambres"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreChambres");
        }
        // line 8
        echo "    ";
        $context["url"] = $this->env->getExtension('usermanager_extension')->generateURLForBienImmobilierI18n($this->getContext($context, "bienImmo"), $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "locale"));
        // line 9
        echo "
<div class=\"content_result\">
    <h1 class=\"title_blue\">
        <a  href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">
            ";
        // line 13
        if ((!(null === $this->getAttribute($this->getContext($context, "bienImmo"), "isMeuble")))) {
            // line 14
            echo "                ";
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("{1} Appartement meublé 1 chambre|]1,+Inf] Appartement meublé %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
            // line 17
            echo "                ";
            echo twig_escape_filter($this->env, (" " . $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method")), "html", null, true);
            echo "
            ";
        } else {
            // line 19
            echo "                ";
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("{1} Appartement 1 chambre|]1,+Inf] Appartement %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
            // line 22
            echo "                ";
            echo twig_escape_filter($this->env, (" " . $this->getAttribute($this->getContext($context, "ReferenceData"), "getTypeLibelleTransaction", array(0 => $this->getAttribute($this->getContext($context, "bienImmo"), "typeTransaction")), "method")), "html", null, true);
            echo "
            ";
        }
        // line 24
        echo "            - ";
        echo twig_escape_filter($this->env, $this->getContext($context, "ville"), "html", null, true);
        echo "/";
        echo twig_escape_filter($this->env, $this->getContext($context, "quartier"), "html", null, true);
        echo "
        </a>
    </h1>
    <em class=\"margin6\">
        ";
        // line 28
        $context["dateDiff"] = $this->env->getExtension('usermanager_extension')->dateDiffInPlainText(twig_date_format_filter($this->env, "now", "Y-m-d"), twig_date_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "datePublication"), "Y-m-d"));
        // line 29
        echo "        ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("publié"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "dateDiff"), "html", null, true);
        echo " - ";
        echo strtr($this->env->getExtension('translator')->trans("vu <strong>%1%</strong> fois"), array("%1%" => $this->getAttribute($this->getContext($context, "bienImmo"), "nombreHits")));
        echo "
    </em>
      <table width=\"440\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
          <tr>
            <td width=\"126\" rowspan=\"2\" align=\"center\" valign=\"middle\">
                ";
        // line 34
        if (($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale") != null)) {
            // line 35
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute($this->getContext($context, "bienImmo"), "photoPrincipale"), "chemin")), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "title"), "html", null, true);
            echo "\" width=\"120\" height=\"120\" />
                ";
        } else {
            // line 37
            echo "                    <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/default_photo.jpg"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Koutchoumi Immobilier"), "html", null, true);
            echo "\" />
                ";
        }
        // line 39
        echo "            </td>
            <td width=\"162\" height=\"98\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">
                    <li>";
        // line 42
        echo ">";
        echo " ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "prix"), 0, ".", " "), "html", null, true);
        echo " FCFA</li>
                    <li>";
        // line 43
        echo ">";
        echo "
                        ";
        // line 44
        $context["nombreSalons"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSalons");
        // line 45
        echo "                        ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salon| %nombreSalons% salons", $this->getContext($context, "nombreSalons"), array("%nombreSalons%" => $this->getContext($context, "nombreSalons")), "messages");
        // line 48
        echo "                    </li>
                </ul>
            </td>
            <td width=\"162\" align=\"left\" valign=\"middle\">
                <ul class=\"result_ul\">
                    <li>";
        // line 53
        echo ">";
        echo "
                    ";
        // line 54
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 chambre| %nombreChambres% chambres", $this->getContext($context, "nombreChambres"), array("%nombreChambres%" => $this->getContext($context, "nombreChambres")), "messages");
        // line 57
        echo "                    </li>
                    <li>";
        // line 58
        echo ">";
        echo "
                    ";
        // line 59
        $context["nombreSallesBains"] = $this->getAttribute($this->getContext($context, "bienImmo"), "nombreSallesDeBains");
        // line 60
        echo "                    ";
        echo $this->env->getExtension('translator')->getTranslator()->transChoice("1 salle de bains| %nombreSallesBains% salles de bains", $this->getContext($context, "nombreSallesBains"), array("%nombreSallesBains%" => $this->getContext($context, "nombreSallesBains")), "messages");
        // line 63
        echo "                    </li>
                </ul>
            </td>
          </tr>
          <tr>
            <td colspan=\"2\" align=\"left\" valign=\"middle\">
                <p class=\"p_result\">
                    <a href=\"";
        // line 70
        echo twig_escape_filter($this->env, $this->getContext($context, "url"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Voir plus de détails"), "html", null, true);
        echo "</a>
                </p>
            </td>
          </tr>
          <tr>
            <td align=\"center\" valign=\"middle\"><span>";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "bienImmo"), "nombrePhotos"), "html", null, true);
        echo " photo(s)</span></td>
            <td colspan=\"2\" align=\"left\" valign=\"top\">&nbsp;</td> 
          </tr>
    </table>
</div>";
    }

    public function getTemplateName()
    {
        return "KoutchoumiFrontendBundle::_shortViewAppartement.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 75,  148 => 59,  128 => 48,  92 => 35,  77 => 29,  65 => 24,  59 => 22,  47 => 14,  41 => 12,  29 => 6,  23 => 3,  21 => 2,  1361 => 391,  1352 => 390,  1350 => 389,  1347 => 388,  1331 => 384,  1324 => 383,  1322 => 382,  1319 => 381,  1296 => 377,  1271 => 376,  1269 => 375,  1266 => 374,  1254 => 369,  1249 => 368,  1247 => 367,  1244 => 366,  1235 => 360,  1229 => 358,  1226 => 357,  1221 => 356,  1219 => 355,  1216 => 354,  1209 => 349,  1200 => 347,  1196 => 346,  1193 => 345,  1190 => 344,  1188 => 343,  1185 => 342,  1177 => 338,  1175 => 337,  1172 => 336,  1166 => 332,  1160 => 330,  1157 => 329,  1155 => 328,  1152 => 327,  1143 => 322,  1141 => 321,  1118 => 320,  1115 => 319,  1112 => 318,  1109 => 317,  1106 => 316,  1103 => 315,  1100 => 314,  1098 => 313,  1095 => 312,  1088 => 308,  1084 => 307,  1079 => 306,  1077 => 305,  1074 => 304,  1067 => 299,  1064 => 298,  1056 => 293,  1053 => 292,  1051 => 291,  1048 => 290,  1040 => 285,  1036 => 284,  1032 => 283,  1029 => 282,  1027 => 281,  1024 => 280,  1016 => 276,  1014 => 272,  1012 => 271,  1009 => 270,  1004 => 266,  982 => 261,  979 => 260,  976 => 259,  973 => 258,  970 => 257,  967 => 256,  964 => 255,  961 => 254,  958 => 253,  955 => 252,  952 => 251,  950 => 250,  947 => 249,  939 => 243,  936 => 242,  934 => 241,  931 => 240,  923 => 236,  920 => 235,  918 => 234,  915 => 233,  903 => 229,  900 => 228,  897 => 227,  894 => 226,  892 => 225,  889 => 224,  881 => 220,  878 => 219,  876 => 218,  873 => 217,  865 => 213,  862 => 212,  860 => 211,  857 => 210,  849 => 206,  846 => 205,  844 => 204,  841 => 203,  833 => 199,  830 => 198,  828 => 197,  825 => 196,  817 => 192,  814 => 191,  812 => 190,  809 => 189,  801 => 185,  798 => 184,  796 => 183,  793 => 182,  785 => 178,  783 => 177,  780 => 176,  772 => 172,  769 => 171,  767 => 170,  764 => 169,  756 => 165,  753 => 164,  751 => 163,  749 => 162,  746 => 161,  739 => 156,  729 => 155,  724 => 154,  721 => 153,  715 => 151,  712 => 150,  710 => 149,  707 => 148,  699 => 142,  697 => 141,  696 => 140,  695 => 139,  694 => 138,  689 => 137,  683 => 135,  680 => 134,  678 => 133,  675 => 132,  666 => 126,  662 => 125,  658 => 124,  654 => 123,  649 => 122,  643 => 120,  638 => 118,  619 => 113,  617 => 112,  598 => 107,  593 => 105,  576 => 101,  564 => 99,  555 => 95,  550 => 94,  547 => 93,  529 => 92,  527 => 91,  524 => 90,  512 => 84,  509 => 83,  501 => 80,  496 => 79,  490 => 77,  470 => 73,  467 => 72,  461 => 70,  459 => 69,  456 => 68,  450 => 64,  433 => 60,  428 => 59,  426 => 58,  414 => 52,  408 => 50,  405 => 49,  400 => 47,  385 => 41,  377 => 37,  374 => 36,  371 => 35,  368 => 34,  355 => 27,  350 => 26,  344 => 24,  337 => 22,  335 => 21,  332 => 20,  316 => 16,  313 => 15,  311 => 14,  308 => 13,  299 => 8,  293 => 6,  290 => 5,  281 => 388,  278 => 387,  271 => 374,  266 => 366,  263 => 365,  260 => 363,  253 => 342,  250 => 341,  238 => 312,  235 => 311,  233 => 304,  230 => 303,  227 => 301,  220 => 290,  217 => 289,  212 => 279,  202 => 266,  199 => 265,  197 => 249,  194 => 248,  191 => 246,  184 => 233,  181 => 232,  179 => 224,  176 => 223,  169 => 210,  166 => 209,  164 => 203,  161 => 202,  154 => 189,  151 => 188,  149 => 182,  146 => 181,  136 => 168,  134 => 161,  131 => 160,  121 => 131,  116 => 116,  109 => 105,  106 => 104,  104 => 90,  101 => 89,  94 => 57,  79 => 32,  76 => 31,  74 => 20,  71 => 19,  61 => 2,  660 => 226,  655 => 224,  648 => 220,  644 => 219,  640 => 119,  635 => 117,  631 => 215,  627 => 214,  622 => 212,  618 => 211,  614 => 111,  609 => 208,  604 => 206,  600 => 205,  596 => 106,  591 => 202,  587 => 201,  583 => 200,  578 => 198,  574 => 197,  570 => 196,  565 => 194,  561 => 193,  557 => 96,  552 => 190,  548 => 189,  544 => 188,  539 => 186,  534 => 184,  526 => 182,  520 => 179,  515 => 85,  510 => 175,  503 => 81,  495 => 169,  484 => 162,  480 => 75,  473 => 157,  468 => 155,  464 => 71,  458 => 151,  453 => 149,  449 => 148,  445 => 147,  440 => 145,  436 => 144,  432 => 143,  423 => 57,  417 => 137,  413 => 136,  407 => 133,  394 => 129,  390 => 43,  384 => 124,  381 => 123,  378 => 122,  375 => 121,  372 => 120,  369 => 119,  366 => 33,  363 => 32,  360 => 116,  357 => 115,  354 => 114,  351 => 113,  348 => 112,  345 => 111,  339 => 109,  336 => 108,  333 => 107,  330 => 106,  327 => 105,  324 => 104,  321 => 103,  318 => 102,  315 => 101,  312 => 100,  309 => 99,  306 => 98,  303 => 97,  300 => 96,  297 => 95,  294 => 94,  288 => 4,  285 => 3,  282 => 90,  279 => 89,  276 => 381,  270 => 86,  267 => 85,  261 => 83,  258 => 354,  252 => 80,  249 => 79,  246 => 78,  243 => 327,  240 => 326,  237 => 75,  234 => 74,  231 => 73,  228 => 72,  225 => 298,  222 => 297,  219 => 69,  216 => 68,  213 => 67,  210 => 270,  207 => 269,  204 => 267,  201 => 63,  198 => 62,  195 => 61,  192 => 60,  189 => 240,  183 => 57,  180 => 56,  177 => 55,  168 => 52,  162 => 70,  156 => 195,  147 => 45,  138 => 42,  132 => 40,  129 => 148,  126 => 147,  123 => 44,  120 => 36,  117 => 35,  114 => 111,  105 => 31,  99 => 68,  96 => 67,  93 => 27,  90 => 34,  87 => 25,  84 => 41,  81 => 40,  72 => 20,  63 => 17,  60 => 16,  57 => 15,  51 => 13,  45 => 13,  39 => 9,  33 => 8,  30 => 6,  19 => 1,  546 => 67,  543 => 66,  533 => 159,  530 => 183,  517 => 149,  511 => 148,  505 => 147,  499 => 170,  493 => 78,  488 => 164,  478 => 74,  472 => 137,  466 => 136,  460 => 135,  454 => 134,  448 => 133,  442 => 62,  437 => 61,  427 => 141,  421 => 124,  415 => 123,  409 => 122,  403 => 48,  398 => 130,  388 => 42,  382 => 113,  376 => 112,  370 => 111,  364 => 110,  358 => 109,  352 => 108,  347 => 106,  342 => 23,  340 => 102,  334 => 99,  326 => 96,  320 => 95,  314 => 94,  307 => 92,  301 => 91,  295 => 90,  291 => 93,  287 => 87,  273 => 380,  268 => 373,  264 => 84,  262 => 71,  257 => 68,  255 => 353,  248 => 336,  245 => 335,  223 => 58,  218 => 57,  215 => 280,  193 => 54,  188 => 53,  186 => 239,  182 => 51,  174 => 217,  171 => 216,  163 => 44,  157 => 42,  155 => 41,  142 => 37,  139 => 54,  125 => 45,  64 => 3,  54 => 14,  48 => 12,  43 => 13,  37 => 10,  25 => 4,  22 => 3,  20 => 1,  165 => 51,  159 => 196,  153 => 63,  150 => 60,  144 => 58,  141 => 57,  135 => 53,  133 => 40,  130 => 39,  124 => 132,  122 => 37,  119 => 43,  113 => 42,  111 => 110,  108 => 39,  102 => 30,  100 => 37,  97 => 30,  91 => 56,  89 => 47,  86 => 46,  80 => 26,  78 => 22,  75 => 28,  69 => 13,  66 => 12,  62 => 21,  58 => 19,  56 => 19,  52 => 15,  50 => 17,  42 => 10,  36 => 9,  31 => 3,  28 => 5,);
    }
}
