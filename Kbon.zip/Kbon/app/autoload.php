<?php

use Doctrine\Common\Annotations\AnnotationRegistry;
use Composer\Autoload\ClassLoader;

/**
 * @var ClassLoader $loader
 */
$loader = require __DIR__.'/../vendor/autoload.php';
$loader->add('PhpFlickr', __DIR__.'/../vendor/phpflickr/lib');
set_include_path(__DIR__.'/../vendor/Zend/Gdata'.PATH_SEPARATOR.get_include_path());
AnnotationRegistry::registerLoader(array($loader, 'loadClass'));

return $loader;
