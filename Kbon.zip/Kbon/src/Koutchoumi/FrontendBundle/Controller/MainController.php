<?php

/**
 * main actions.
 *
 * @package    koutchoumiimmo
 * @subpackage main
 * @author     pattchen, J
 * @version    SVN: $Id: actions.class.php 12479 2008-10-31 10:54:40Z fabien $
 */
// src/Koutchoumi/FrontendBundle/Controller/main/MainController.php

namespace Koutchoumi\FrontendBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Httpfoundation\Response;
use Symfony\Component\Httpfoundation\Request;
use Doctrine\Common\Collections\Criteria;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Koutchoumi\FrontendBundle\Form\TrouverBienForm;
use Koutchoumi\FrontendBundle\Form\TrouverBienAvanceForm;
use Koutchoumi\FrontendBundle\Form\ContactKoutchoumiForm2;
use Koutchoumi\FrontendBundle\Entity\ReferenceData;
use Koutchoumi\FrontendBundle\Entity\BienImmobilier;
use Koutchoumi\FrontendBundle\Entity\BienManager;
use Koutchoumi\FrontendBundle\Utils\ServiceManager;
use Symfony\Component\Form\AbstractType;
use PhpFlickr;

class MainController extends Controller {

    /**
     * Returns the preferred culture for a given request.
     *
     * @param array $languages
     *
     * @param  array  $cultures  An array of ordered cultures available
     *
     * @return string The preferred culture
     */
    private function getPreferredLanguageImproved(array $languages = null) {
        $request = $this->getRequest();
        $locale = $request->getLocale();
        $preferredLanguages = $request->getLanguages();

        if (is_null($languages)) {
            return isset($preferredLanguages[0]) ? $preferredLanguages[0] : null;
        }

        if (!$preferredLanguages) {
            return $languages[0];
        }

        /** Improvement : we get only the first 2 letters of the languages provided by the browser to match against our supportted languages
         *
         */
        for ($i = 0; $i < count($preferredLanguages); $i++) {
            $preferredLanguages[$i] = substr($preferredLanguages[$i], 0, 2);
        }
        /** Improvement end * */
        $preferredLanguages = array_values(array_intersect($preferredLanguages, $languages));

        return isset($preferredLanguages[0]) ? $preferredLanguages[0] : $languages[0];
    }

    public function goToAnnonceurAction() {
        return $this->redirect($this->generateUrl('homepage_annonceur'));
    }

    public function indexAction(Request $request) {
        $locale = $request->getLocale();
        if (!$request->query->get('locale')) {
            if ($request->hasPreviousSession()) {
                $locale = $this->getPreferredLanguageImproved(array('fr', 'en'));
                $request->setLocale($locale);
                $request->hasPreviousSession(false);
            } else {
                $locale = $request->getLocale();
            }
            $this->redirect('@homepage_i18n');
        }

        $form = $this->createForm(new TrouverBienForm());
        $form->handleRequest($request);
        if ($form->isValid()) {
            $formFieldsValues = array(
                "typeBien" => $form->get('typeBien')->getData(),
                "typeTransaction" => $form->get('typeTransaction')->getData(),
                "villeId" => $form->get('villeId')->getData(),
                "prixMin" => $form->get('prixMin')->getData(),
                "prixMax" => $form->get('prixMax')->getData(),
                "surfaceMin" => $form->get('surfaceMin')->getData(),
                "surfaceMax" => $form->get('surfaceMax')->getData(),
                "nombreChambres" => $form->get('nombreChambres')->getData(),
            );
            return $this->processTrouverBienForm($formFieldsValues, 1);
        } else {
            return $this->render('KoutchoumiFrontendBundle::index.html.twig', array('form' => $form->createView(), 'ReferenceData' => new ReferenceData($this->container->get('translator')), 'bienmanager' => $this->container->get('koutchoumi_frontend.router')));
        }
//          var_dump($form["typeTransaction"]->get("id"));
//          echo($form->get('typeBien'));
//          die();
        //$this->trouverBienForm = new TrouverBienForm();
    }

    public function changeLanguageAction(Request $request) {
//        $referer = $request->getReferer();
        $referer = $request->headers->get('referer');
        $currentCulture = $request->getLocale();
        $goTo = NULL;
//      $form = new sfFormLanguage($this->getUser(), array('languages' => array('en', 'fr')));
//      $form->process($request);

        if ($currentCulture == 'fr') {
            if (substr_count($referer, '/fr') == 0) { // Old fashionned url without culture
                if (substr_count($referer, 'app_dev.php') == 0) { // prod env.
                    $goTo = str_replace('koutchoumi.com', 'koutchoumi.com/en', $referer);
                } else { // dev env.
                    $goTo = str_replace('app_dev.php', 'app_dev.php/en', $referer);
                    die(var_dump($goTo));
                }
            }
            $goTo = str_replace('/fr', '/en', $referer);
            $goTo = str_replace('/appartement/', '/apartment/', $goTo);
            $goTo = str_replace('/maison/', '/house/', $goTo);
            $goTo = str_replace('/chambre/', '/studio/', $goTo);
            $goTo = str_replace('/boutique/', '/shop/', $goTo);
            $goTo = str_replace('/magasin/', '/store/', $goTo);
            $goTo = str_replace('/entrepot/', '/warehouse/', $goTo);
            $goTo = str_replace('/terrain/', '/land/', $goTo);
            $goTo = str_replace('/a-vendre/', '/for-sale/', $goTo);
            $goTo = str_replace('/a-louer/', '/to-rent/', $goTo);
            $goTo = str_replace('chambres/', 'bedrooms/', $goTo);
        } else { //currentculture = en
            $goTo = str_replace('/en', '/fr', $referer);
            $goTo = str_replace('/apartment/', '/appartement/', $goTo);
            $goTo = str_replace('/house/', '/maison/', $goTo);
            $goTo = str_replace('/studio/', '/chambre/', $goTo);
            $goTo = str_replace('/land/', '/terrain/', $goTo);
            $goTo = str_replace('/shop/', '/boutique/', $goTo);
            $goTo = str_replace('/store/', '/magasin/', $goTo);
            $goTo = str_replace('/warehouse/', '/entrepot/', $goTo);
            $goTo = str_replace('/for-sale/', '/a-vendre/', $goTo);
            $goTo = str_replace('/to-rent/', '/a-louer/', $goTo);
            $goTo = str_replace('bedrooms/', 'chambres/', $goTo);
        }

//        die(var_dump($goTo));
        return $this->redirect($goTo);
    }

    public function generateLatestAdsAction() {
//        $this->latestAds = BienManager::getLatestAds(10);
        return new Response('Not implemented');
    }

    public function detailsBienAction() {
        $request = $this->getRequest();
        $idBien = $request->get('idBien');
        $qb = $this->getDoctrine()->getManager()->createQueryBuilder();
        $qb->select('bi')
                ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                ->where('bi.id=:idBien')
                ->setParameter('idBien', $idBien);
        $query = $qb->getQuery();
        $results = $query->getResult();
        if ($results != NULL) { // Le bien existe et est disponible
//            var_dump($results);
            $bienImmo = $results[0];
//              try{
            BienManager::incrementerHitsBien($idBien);
            //On fixe le titre de la page, ainsi que les meta description et keywords
//                $this->getResponse()->setTitle($this->bienImmo->getTitle() . " - Koutchoumi.com");
//                $this->getResponse()->addMeta('description', $this->bienImmo->getShortDescription());
//                
//                $keywords = ReferenceData::getLibelleTypeBien($this->bienImmo->getClassKey());
//                $keywords .= " " . ReferenceData::getTypeLibelleTransaction($this->bienImmo->getTypeTransaction());
//                $keywords .= " " . sfContext::getInstance()->getI18N()->__("à %CITY%", array("%CITY%"=> ReferenceData::getVille($this->bienImmo->getVilleId())->getNom()));
//                $keywords .= " " . ReferenceData::getQuartier($this->bienImmo->getQuartierId())->getNom();
//                $this->getResponse()->addMeta('keywords', $keywords);
//              } catch (KoutchoumiException $e){
//                  $log = $e->__toString();
//                  $this->logMessage($message, 'err');
//                  throw $e;
//              }
            $nombreBiensSimilairesAAfficher = 3;
            $maxTypeServicesByDomaine = $this->container->getParameter('max_typesservices_bydomaine');
            $maxTypeServicesInCompleteView = $this->container->getParameter('max_typesservices_completeview');
            $typesServicesInShortView = $this->container->getParameter('max_typesservices_shortview');
            $serviceByType = ServiceManager::getServicesByType($bienImmo->getQuartier(), $maxTypeServicesByDomaine, $maxTypeServicesInCompleteView);
            return $this->render('KoutchoumiFrontendBundle::detailsBien.html.twig', array('bienImmo' => $bienImmo, 'ReferenceData' => new ReferenceData($this->container->get('translator')), 'servicesByType' => $serviceByType, 'typesServicesInShortView' => $typesServicesInShortView, 'nombreBiensSimilairesAAfficher' => $nombreBiensSimilairesAAfficher));
        } else {// le bien n'existe plus ou alors n'est plus disponible
//              $this->getResponse()->setTitle("Koutchoumi.com - Bien non disponible");
            return $this->render('KoutchoumiFrontendBundle::bienNonDisponible.html.twig');
        }
    }

    public function showQuartierAction(Request $request) { {
            $quartierId = $request->get('id');

            // 1. On récupère les infos sur le quartier
            $quartier = ReferenceData::getQuartier($quartierId);

            // 2. On construit un tableau des services de ce quartier regroupé par types de service, et les types regroupés par domaine
            $domaines = array();
            $domaines_icones = array();
            $typesServices = ServiceManager::getTypeServicesOfQuartier($quartierId);
            foreach ($typesServices as $typeService) {
                $domaines[$typeService->getDomaine()->getNom()] = array();
                if (!array_key_exists($typeService->getDomaine()->getNom(), $domaines_icones)) {
                    $domaines_icones[$typeService->getDomaine()->getNom()] = $typeService->getIconeUrl();
                }
            }

            $services = ServiceManager::getServicesOfQuartier($quartierId);
            foreach ($services as $service) {
                $domaines[$service->getTypeService()->getDomaine()->getNom()][$service->getTypeService()->getNom()][] = $service;
            }

            // 3. Liste de 2 apparts et de 2 terrains dans ce quartier
            $qb = $this->getDoctrine()->getManager()->createQueryBuilder();
            $qb->select('bi')
                    ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                    ->where('1=1');
            $qb->andWhere('bi.quartier=:quartierId')->setParameter('quartierId', $quartierId);
            $qb->andWhere('bi.classKey=:ck')->setParameter('ck', BienImmobilier::CLASSKEY_APPARTEMENT);
            $qb->orderBy('bi.updatedAt', 'ASC');
            $qb->setMaxResults(2);
//        $this->bienImmos = BienManager::trouverBien($criteria);
            $bienImmos = $qb->getQuery()->getResult();

            $qbd = $this->getDoctrine()->getManager()->createQueryBuilder();
            $qbd->select('bi')
                    ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                    ->where('1=1');
            $qbd->andWhere('bi.quartier=:quartierId')->setParameter('quartierId', $quartierId);
            $qbd->andWhere('bi.classKey=:ck')->setParameter('ck', BienImmobilier::CLASSKEY_TERRAIN);
            $qbd->orderBy('bi.updatedAt', 'ASC');
            $qbd->setMaxResults(2);
//        $this->bienImmos = array_merge($this->bienImmos, BienManager::trouverBien($criteria));
            $bienImmos = array_merge($bienImmos, $qbd->getQuery()->getResult());

            //4. Et enfin, on fixe le titre de la page
//        $this->getResponse()->setTitle($this->quartier->getNom() . ", quartier de " . $this->quartier->getVille()->getNom() . " - Présentation sur koutchoumi.com");
//        $this->getResponse()->addMeta('description', $this->quartier->getNom() . ", quartier de " . $this->quartier->getVille()->getNom() . " - Présentation sur koutchoumi.com");
//        $this->getResponse()->addMeta('keywords', $this->quartier->getNom() . "," . $this->quartier->getVille()->getNom() . ",commodités,services,koutchoumi");
        }

        return $this->render('KoutchoumiFrontendBundle::showQuartier.html.twig', array('quartier' => $quartier, 'domaines' => $domaines, 'domaines_icones' => $domaines_icones, 'bienImmos' => $bienImmos, 'ReferenceData' => new ReferenceData($this->container->get('translator'))));
    }

    public function showContactsServicesAction(Request $request) {
        $servicesCodes = $this->container->getParameter('supportedservices');
        $contactsServices = array();
        foreach ($servicesCodes as $serviceCode) {
            $contactsServices[$serviceCode] = $this->container->getParameter($serviceCode);
        }
        return $this->render('KoutchoumiFrontendBundle::showContactsServices.html.twig', array('contactsServices' => $contactsServices));
    }

    public function getContactsAction(Request $request) {
        $response = new Response('Not implemented');
        $serviceCode = $request->get('contactservice');
        switch ($serviceCode) {
            case 'yahoo':
                $response = $this->forward('KoutchoumiFrontendBundle::getContactsYahoo');
                break;
            case 'gmail':
                $response = $this->forward('KoutchoumiFrontendBundle::getContactsGmail');
                break;
        }
        return $response;
    }

    public function getContactsYahooAction(Request $request) {
//      $culture = $this->getUser()->getCulture();
//      $callbackUrl = 'http://www.koutchoumi.com/'.$culture.'/main/getContactsYahoo';
//      $contactService = sfConfig::get('app_contactsservices_yahoo');
//      $consumerKey = $contactService['consumer_key'];
//      $consumerSecret = $contactService['consumer_secret'];
//      // Load zend
//      ProjectConfiguration::registerZend();
//      $contactService = new YahooContactsService($consumerKey, $consumerSecret, $callbackUrl);
//      try{
//	      $this->contacts = $contactService->fetchContacts(1000);
//	      sort($this->contacts);
//	      $this->setTemplate('getContacts');
//      } catch (Exception $e){
//          $this->logMessage($e->getMessage(), 'err');
//          $this->logMessage($e->getTraceAsString(), 'err');
//          throw $e;
//      }
        return new Response('Not implemented');
    }

    public function getContactsGmailAction(Request $request) {
//      $culture = $this->getUser()->getCulture();
//      $callbackUrl = 'http://www.koutchoumi.com/'.$culture.'/main/getContactsGmail';
//      $contactService = sfConfig::get('app_contactsservices_gmail');
//      $consumerKey = $contactService['consumer_key'];
//      $consumerSecret = $contactService['consumer_secret'];
//      // Load zend
//      ProjectConfiguration::registerZend();
//      $contactService = new GoogleContactsService($consumerKey, $consumerSecret, $callbackUrl);
//      try{
//          $this->contacts = $contactService->fetchContacts(1000);
//          sort($this->contacts);
//          $this->setTemplate('getContacts');
//      } catch (Exception $e){
//          $this->logMessage($e->getMessage(), 'err');
//          $this->logMessage($e->getTraceAsString(), 'err');
//          throw $e;
//      }
        return new Response('Not implemented');
    }

    public function listingBiensALouerAction() {
        $request = $this->getRequest();
        $routeDefaults = $this->get('router')->getRouteCollection()->get($request->get('_route'))->getDefaults();
        $trouverBienAvanceForm = $this->createForm(new TrouverBienAvanceForm());
        $param = array(
            'typeBien' => $request->get('typeBien'),
            'villeId' => $routeDefaults['villeId'],
            'nombreChambres' => -1,
            'typeTransaction' => ReferenceData::TYPE_TRANSACTION_LOCATION
        );
        return $this->processTrouverBienForm($param, $trouverBienAvanceForm, 1);
    }

    public function listingBiensAVendreAction() {
        $request = $this->getRequest();
        $routeDefaults = $this->get('router')->getRouteCollection()->get($request->get('_route'))->getDefaults();
        $trouverBienAvanceForm = $this->createForm(new TrouverBienAvanceForm());
        $param = array(
            'typeBien' => $request->get('typeBien'),
            'villeId' => $routeDefaults['villeId'],
            'nombreChambres' => -1,
            'typeTransaction' => ReferenceData::TYPE_TRANSACTION_VENTE
        );
        return $this->processTrouverBienForm($param, $trouverBienAvanceForm, 1);
    }

    public function showResultsAction(Request $request) {
        $form = $this->createForm(new TrouverBienAvanceForm());
        $form->handleRequest($request);
        $formFieldsValues = array(
            "typeBien" => $form->get('typeBien')->getData(),
            "typeTransaction" => $form->get('typeTransaction')->getData(),
            "villeId" => $form->get('villeId')->getData(),
            "prixMin" => $form->get('prixMin')->getData(),
            "prixMax" => $form->get('prixMax')->getData(),
            "surfaceMin" => $form->get('surfaceMin')->getData(),
            "surfaceMax" => $form->get('surfaceMax')->getData(),
            "nombreChambres" => $form->get('nombreChambres')->getData(),
            "quartierId" => $form->get('quartierId')->getData(),
            "distanceRouteMin" => $form->get('distanceRouteMin')->getData(),
            "distanceRouteMax" => $form->get('distanceRouteMax')->getData(),
            "nombrePiecesMin" => $form->get('nombrePiecesMin')->getData(),
            "nombrePiecesMax" => $form->get('nombrePiecesMax')->getData(),
            "minSDB" => $form->get('minSDB')->getData(),
            "maxSDB" => $form->get('maxSDB')->getData(),
            "avecParking" => $form->get('avecParking')->getData(),
            "avecDouche" => $form->get('avecDouche')->getData(),
            "avecBarriere" => $form->get('avecBarriere')->getData(),
            "typeMaisonId" => $form->get('typeMaisonId')->getData(),
            "situationSalleDeBains" => $form->get('situationSalleDeBains')->getData(),
            "situationToilettes" => $form->get('situationToilettes')->getData(),
            "titre" => $form->get('titre')->getData(),
        );
        $trouverBienAvanceForm = $this->createForm(new TrouverBienAvanceForm());
        return $this->processTrouverBienForm($formFieldsValues, $trouverBienAvanceForm, 1);
    }

    public function whyKoutchoumiAction() {
        return $this->render('KoutchoumiFrontendBundle::whyKoutchoumi.html.twig');
    }

    public function contactKoutchoumiAction(Request $request) {
        $form = $this->createForm(new ContactKoutchoumiForm2());
        $form->handleRequest($request);
        if ($form->isValid()) {
            $email = $form->get('email')->getData();
            $nom = $form->get('nom')->getData();
            $message = $form->get('message')->getData();

            $this->sendMessageToKoutchoumi($email, $nom, $message);

            //redirect vers  la page d'accueil des annonceurs
            return $this->render('KoutchoumiFrontendBundle::thankyou.html.twig');
        } else {
            return $this->render('KoutchoumiFrontendBundle::contactKoutchoumi.html.twig', array('form' => $form->createView()));
        }
//        if (!$request->isMethod('post')) {
//            return $this->processContactKoutchoumiForm($request, $form);
//        }
//        else{
//            return new Response('Not post');
//        }
    }

    public function conditionsUtilisationsKoutchoumiAction() {
        return $this->render('KoutchoumiFrontendBundle::conditionsUtilisationsKoutchoumi.html.twig');
    }

    public function sendInvitesAction(Request $request) {
        $form = $this->createForm(new ContactKoutchoumiForm2());
        $form->handleRequest($request);
        if ($form->isValid()) {
            $name = $request->get('name');
            $userMessage = $request->get('message');
            $contacts = $request->get('contacts');

            $this->sendMessageToKoutchoumi($email, $nom, $message);

            //redirect vers  la page d'accueil des annonceurs
            return $this->render('KoutchoumiFrontendBundle::thankyou.html.twig');
        } else {
            return $this->render('KoutchoumiFrontendBundle::contactKoutchoumi.html.twig', array('form' => $form->createView()));
        }
        $name = $request->get('name');
        $userMessage = $request->get('message');
        $contacts = $request->get('contacts');
        $subject = $name . ' vous invite à découvrir koutchoumi.com';
        $message = $name . " vous invite à découvrir <strong><a href='http://www.koutchoumi.com'>koutchoumi.com</a>, site d'annonces immobilières (chambres, appartements, maisons et terrains) au Cameroun</strong>, notamment à Yaoundé et à Douala.";
        if ($userMessage != '') {
            $message.= "<br/>Son message:<br/>--------<br/>" . $userMessage . "<br/>--------";
        }
        $message .= "<br/><br/>C'est <strong>la 1ère fois</strong> que vous entendez parler de koutchoumi.com? Découvrez-le en suivant ce lien :
        <strong><a href='http://www.koutchoumi.com'>http://www.koutchoumi.com</a></strong><br/>Sinon, faites vous aussi passer le message à vos contacts en suivant le lien suivant: <a href='http://www.koutchoumi.com/invite'>http://www.koutchoumi.com/invite</a>.
        <br/><br/>---<br/>> <a href='http://www.facebook.com/pages/Koutchoumi/210339761326'>Devenez fan de koutchoumi sur facebook</a><br/>
        > koutchoumi.com dans les médias : <a href='http://atelier.rfi.fr/profiles/blogs/interview-parlons-de'>koutchoumi.com sur Ateliers des médias RFI par DJIAThink</a> | <a href='http://www.ingenieris.net/content.php?Interview-de-M.-Patrick-NDJIENTCHEU-de-KOUTCHOUMI.com&id=544&t=article'>koutchoumi.com interviewé par Ingeneris.net</a>
        <br/><br/>L'équipe koutchoumi.com";
        foreach ($contacts as $email) {
            NewletterManager::addSubscriber($email, 'invite');
            EmailService::putEmail($email, NULL, $subject, $message, EmailService::PRIORITY_NORMAL, 'koutchoumi-invite');
        }
    }

    protected function processTrouverBienForm2($form, $formAvance, $page = 1) {
//      $k = $form->getName();
        $request = $this->getRequest();
//      $formsParam = $request->getParameter($k);
//      $form->bind($request);

        $typeBien = $form->get('typeBien')->getData();
        $typeTransaction = $form->get('typeTransaction')->getData();
        $villeId = $form->get('villeId')->getData();
        $prixMin = $form->get('prixMin')->getData();
        $prixMax = $form->get('prixMax')->getData();
        $surfaceMin = $form->get('surfaceMin')->getData();
        $surfaceMax = $form->get('surfaceMax')->getData();
        $nombreChambres = $form->get('nombreChambres')->getData();

        //Champs présents dans la recherche avancée
//          $quartierId = $form->get('quartierId')->getData();
//          $minSDB = $form->get('minSDB')->getData();
//          $maxSDB = $form->get('maxSDB')->getData();
//          $distanceRouteMin = $form->get('distanceRouteMin')->getData();
//          $distanceRouteMax = $form->get('distanceRouteMax')->getData();
//          $avecParking = $form->get('avecParking')->getData();
//          $avecDouche = $form->get('avecDouche')->getData();
//          $avecBarriere = $form->get('avecBarriere')->getData();
//          $typeMaisonId = $form->get('typeMaisonId')->getData();
//          $situationSalleDeBains = $form->get('situationSalleDeBains')->getData();
//          $situationToilettes = $form->get('situationToilettes')->getData();
//          $titre = $form->get('titre')->getData();
//          $nombrePiecesMin = $form->get('nombrePiecesMin')->getData();
//          $nombrePiecesMax = $form->get('nombrePiecesMax')->getData();
//          var_dump($typeBien);
//          die();
        // On fixe les headers de la page : titre, balise metas (keywords, title, description)
//          if($villeId == -1){
//              $ville = 'Douala, Yaoundé';
//          }
//          else{
//              $ville = ReferenceData::getVille($villeId)->getNom();
//          }
//          $searchResultsPageMeta = $this->getSearchResultsPageMeta($typeBien, $typeTransaction, $ville);
//          $title = $searchResultsPageMeta['title'];
//          $keywords = $searchResultsPageMeta['keywords'];
//          $description = $searchResultsPageMeta['description'];
//
//          $this->getResponse()->setTitle($title);
//          $this->getResponse()->addMeta('title', $title);
//          $this->getResponse()->addMeta('keywords', $keywords);
//          $this->getResponse()->addMeta('description', $description);
//      }
//      else{
//          $this->setTemplate('index');
//          return;
//      }
//
//      //On construit la partie de l'url contenant les paramètres. Veiller à prendre en compte tous les paramètres.
//      $this->urlParams = $k.'[typeBien]='.$typeBien.'&'.$k.'[typeTransaction]='.$typeTransaction.'&'.$k.'[villeId]='.$villeId.'&'.$k.'[prixMin]='.$prixMin.'&'.$k.'[prixMax]='.$prixMax;
//      $this->urlParams .= '&'.$k.'[surfaceMin]='.$surfaceMin.'&'.$k.'[surfaceMax]='.$surfaceMax.'&'.$k.'[nombreChambres]='.$nombreChambres.'&'.$k.'[quartierId]='.$quartierId;
//      $this->urlParams .= '&'.$k.'[minSDB]='.$minSDB.'&'.$k.'[maxSDB]='.$maxSDB.'&'.$k.'[avecParking]='.$avecParking.'&'.$k.'[avecBarriere]='.$avecBarriere.'&'.$k.'[typeMaisonId]='.$typeMaisonId;
//      $this->urlParams .= '&'.$k.'[situationSalleDeBains]='.$situationSalleDeBains.'&'.$k.'[situationToilettes]='.$situationToilettes.'&'.$k.'[titre]='.$titre;
//      $this->urlParams .= '&'.$k.'[distanceRouteMin]='.$distanceRouteMin.'&'.$k.'[distanceRouteMax]='.$distanceRouteMax.'&'.$k.'[avecDouche]='.$avecDouche;
//      $this->urlParams .= '&'.$k.'[nombrePiecesMin]='.$nombrePiecesMin.'&'.$k.'[nombrePiecesMax]='.$nombrePiecesMax;
        //Le querybuilder intervient à partir d'ici
        $criteria = Criteria::create();
        // Critères présents pour tous les types de biens
        $criteria->where(Criteria::expr()->eq(BienImmobilier::TYPE_TRANSACTION, $typeTransaction == 0 ? FALSE : TRUE));
        if ($villeId != -1) {
            ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::VILLE_ID, $villeId));
        }
//      if($quartierId != -1 && $quartierId != NULL){
//        $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::QUARTIER_ID, $quartierId));
//      }
        if ($prixMin != NULL) {
            if ($typeBien == ReferenceData::TYPE_BIEN_BLOC_TERRAIN) { // le prix est donné en F/m2
//              $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::PRIX, BienImmobilier::PRIX.'/'.BienImmobilier::SURFACE.'>='.$prixMin, Criteria::CUSTOM));
            } else {
                ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::PRIX, $prixMin));
            }
        }
        if ($prixMax != NULL) {
            if ($typeBien == ReferenceData::TYPE_BIEN_BLOC_TERRAIN) {// le prix est donné en F/m2
//              $criteria->addAnd(BienImmobilier::PRIX, BienImmobilier::PRIX.'/'.BienImmobilier::SURFACE.'<='.$prixMax, Criteria::CUSTOM);
            } else {
                ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::PRIX, $prixMax));
            }
        }

        // Critères dépendant du type de bien
        switch ($typeBien) {
            case ReferenceData::TYPE_BIEN_APPARTEMENT:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_APPARTEMENT));
                if ($nombreChambres != -1) {
                    ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::NOMBRE_CHAMBRES, $nombreChambres));
                }
//              if($minSDB != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::NOMBRE_SALLES_DE_BAINS, $minSDB));
//              }
//              if($maxSDB != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::NOMBRE_SALLES_DE_BAINS, $maxSDB));
//              }
//              if($avecParking != -1 && $avecParking != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_PARKINGS, $avecParking));
//              }
//              if($avecBarriere != -1 && $avecBarriere != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_BARRIERE, $avecBarriere));
//              }
                break;
            case ReferenceData::TYPE_BIEN_STUDIO:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_STUDIO));
//              if($avecParking != -1 && $avecParking != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_PARKINGS, $avecParking));
//              }
//              if($avecBarriere != -1 && $avecBarriere != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_BARRIERE, $avecBarriere));
//              }
//              if($situationSalleDeBains != -1 && $situationSalleDeBains != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::SITUATION_SALLE_DE_BAINS, $situationSalleDeBains));
//              }
//              if($situationToilettes != -1 && $situationToilettes != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::SITUATION_TOILETTES, $situationToilettes));
//              }
                break;
            case ReferenceData::TYPE_BIEN_MAISON:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_MAISON));
                if ($nombreChambres != -1) {
                    ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::NOMBRE_CHAMBRES, $nombreChambres));
                }
//              if($avecParking != -1 && $avecParking != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_PARKINGS, $avecParking));
//              }
//              if($avecBarriere != -1 && $avecBarriere != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_BARRIERE, $avecBarriere));
//              }
//              if($typeMaisonId != -1 && $typeMaisonId != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::TYPE_MAISON_ID, $typeMaisonId));
//              }
//              if($minSDB != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::NOMBRE_SALLES_DE_BAINS, $minSDB));
//              }
//              if($maxSDB != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::NOMBRE_SALLES_DE_BAINS, $maxSDB));
//              }
                break;
            case ReferenceData::TYPE_BIEN_TERRAIN:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_TERRAIN));
                if ($surfaceMin != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::SURFACE, $surfaceMin));
                }
                if ($surfaceMax != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::SURFACE, $surfaceMax));
                }
//              if($titre != -1 && $titre != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::TITRE, $titre));
//              }
                break;
            case ReferenceData::TYPE_BIEN_BLOC_TERRAIN:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_BLOCTERRAIN));
                break;
            case ReferenceData::TYPE_BIEN_ENTREPOT:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_ENTREPOT));
                if ($surfaceMin != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::SURFACE, $surfaceMin));
                }
                if ($surfaceMax != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::SURFACE, $surfaceMax));
                }

//              if($avecParking != -1 && $avecParking != NULL){
//                $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::AVEC_PARKINGS, $avecParking));
//              }
//              if($avecDouche != -1 && $avecDouche != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_DOUCHE, $avecDouche));
//              }
//              if($avecBarriere != -1 && $avecBarriere != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_BARRIERE, $avecBarriere));
//              }
//              if($distanceRouteMin != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMin));
//              }
//              if($distanceRouteMax != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMax));
//              }
                break;
            case ReferenceData::TYPE_BIEN_MAGASIN:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_MAGASIN));
                if ($surfaceMin != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::SURFACE, $surfaceMin));
                }
                if ($surfaceMax != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::SURFACE, $surfaceMax));
                }

//              if($avecParking != -1 && $avecParking != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_PARKINGS, $avecParking));
//              }
//              if($avecDouche != -1 && $avecDouche != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_DOUCHE, $avecDouche));
//              }
//              if($avecBarriere != -1 && $avecBarriere != NULL){
//                $criteria->andWhere(Criteria::expr()->eq(BienImmobilier::AVEC_BARRIERE, $avecBarriere));
//              }
//              if($distanceRouteMin != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMin));
//              }
//              if($distanceRouteMax != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMax));
//              }
                break;
            case ReferenceData::TYPE_BIEN_BOUTIQUE:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_BOUTIQUE));
                if ($surfaceMin != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::SURFACE, $surfaceMin, Criteria::GREATER_EQUAL));
                }
                if ($surfaceMax != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::SURFACE, $surfaceMax));
                }
//              if($distanceRouteMin != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMin));
//              }
//              if($distanceRouteMax != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMax));
//              }
                break;
            case ReferenceData::TYPE_BIEN_BUREAU:
                ////$criteria->andWhere(Criteria::expr()->eq(BienImmobilier::CLASS_KEY, BienImmobilier::CLASSKEY_BUREAU));
                if ($surfaceMin != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->gte(BienImmobilier::SURFACE, $surfaceMin));
                }
                if ($surfaceMax != NULL) {
                    ////$criteria->andWhere(Criteria::expr()->lte(BienImmobilier::SURFACE, $surfaceMax));
                }
//              if($distanceRouteMin != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMin));
//              }
//              if($distanceRouteMax != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::DISTANCE_DE_LA_ROUTE, $distanceRouteMax));
//              }
//              if($nombrePiecesMin != NULL){
//                  $criteria->andWhere(Criteria::expr()->gte(BienImmobilier::NOMBRE_PIECES, $nombrePiecesMin));
//              }
//              if($nombrePiecesMax != NULL){
//                  $criteria->andWhere(Criteria::expr()->lte(BienImmobilier::NOMBRE_PIECES, $nombrePiecesMax));
//              }
                break;
        }

        //On classe par ordre de publication du plus récent au plus ancien, puis par nombre de hits décroissant, puis par prix croissant
        ////$criteria->orderBy(array(BienImmobilier::DATE_PUBLICATION=>Criteria::DESC));
        ////$criteria->orderBy(array(BienImmobilier::NOMBRE_HITS=>Criteria::DESC));
        ////$criteria->orderBy(array(BienImmobilier::PRIX=>Criteria::ASC));
//      var_dump($criteria);
//      die();
//      $this->stringCriteria = CriteriaHelper::buildStringFromCriteria($criteria);
//
//      try{
//          //On initialise le pager
//          $this->pager = new sfPropelPager('BienImmobilier', sfConfig::get('app_general_max_biens_par_page'));
//          $this->pager->setCriteria(BienManager::getActiveBiensCriteria($criteria));
//          $this->pager->setPage($request->getParameter('page', 1));
//          $this->pager->init();
//
//          $this->results = $this->pager->getResults();
//          $this->nbResultsCurrentPage = count($this->results);
//          $this->nbResults = $this->pager->getNbResults();
//

        $nb_bienimmos = BienManager::compterBien($criteria);
        $nb_parpage = 10;
        $nb_pages = ceil($nb_bienimmos / $nb_parpage);
        $offset = ($page - 1) * $nb_parpage;
        ////$criteria->setFirstResult($offset);
//          var_dump($nb_bienimmos);
//          var_dump($nb_parpage);
//          var_dump($nb_pages);
//          var_dump($page);
        if ($page < 1 OR $page > $nb_pages) {
            throw $this->createNotFoundException('Page inexistante (page = ' . $page . ')');
        }
        $arrayresult = ReferenceData::getBiensImmobiliers();
        $result = new ArrayCollection($arrayresult);
//           var_dump($result);
//           echo('nombre:');
//           var_dump(count($result));
        $listebiens = $result->matching($criteria);
//           var_dump($listebiens);
        if ($nb_bienimmos == 0) {
//            var_dump('noResults');
            return $this->render('KoutchoumiFrontendBundle::noResults.html.twig', array('trouverBienAvanceForm' => $formAvance->createView(), 'ReferenceData' => new ReferenceData($this->container->get('translator')), 'bienmanager' => $this->container->get('koutchoumi_frontend.router')));
        } else {
//            var_dump($nb_bienimmos);
            return $this->render('KoutchoumiFrontendBundle::trouverBie.html.twig', array('trouverBienAvanceForm' => $formAvance->createView(), 'listebiens' => $listebiens, 'ReferenceData' => new ReferenceData($this->container->get('translator'))));
        }
//      }
//      catch (Exception $e){
//          $log = $e->__toString();
//          $this->logMessage($log);
//          throw $e;
//      }
    }

    protected function processTrouverBienForm($formFieldsValues, $page = 1) {
//      $k = $form->getName();
        $request = $this->getRequest();
//      $formsParam = $request->getParameter($k);

        $qb = $this->getDoctrine()->getManager()->createQueryBuilder();
        $qb->select('bi')
                ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                ->where('1=1');
        // Critères présents pour tous les types de biens
        if (array_key_exists("typeTransaction", $formFieldsValues)) {
            $qb->andWhere('bi.typeTransaction=:typeTransaction')
                    ->setParameter('typeTransaction', $formFieldsValues["typeTransaction"] == 0 ? FALSE : TRUE);
        }
        if (array_key_exists("villeId", $formFieldsValues)) {
            if ($formFieldsValues['villeId'] != -1) {
                $qb->andWhere('bi.ville=:villeId')
                        ->setParameter('villeId', $formFieldsValues['villeId']);
            }
        }
        if (array_key_exists("quartierId", $formFieldsValues)) {
            if ($formFieldsValues['quartierId'] != -1) {
                $qb->andWhere('bi.quartierId=:quartierId')
                        ->setParameter('quartierId', $formFieldsValues['quartierId']);
            }
        }
        if (array_key_exists("prixMin", $formFieldsValues)) {
            if ($formFieldsValues['prixMin'] != NULL) {
                if ($formFieldsValues['typeBien'] == ReferenceData::TYPE_BIEN_BLOC_TERRAIN) { // le prix est donné en F/m2
                    $qb->andWhere('bi.prix/bi.surface >= :prixMin')
                            ->setParameter('prixMin', $formFieldsValues['prixMin']);
                } else {
                    $qb->andWhere('bi.prix >= :prixMin')
                            ->setParameter('prixMin', $formFieldsValues['prixMin']);
                }
            }
        }
        if (array_key_exists("prixMax", $formFieldsValues)) {
            if ($formFieldsValues['prixMax'] != NULL) {
                if ($formFieldsValues['typeBien'] == ReferenceData::TYPE_BIEN_BLOC_TERRAIN) { // le prix est donné en F/m2
                    $qb->andWhere('bi.prix/bi.surface <= :prixMax')
                            ->setParameter('prixMax', $formFieldsValues['prixMax']);
                } else {
                    $qb->andWhere('bi.prix <= :prixMax')
                            ->setParameter('prixMax', $formFieldsValues['prixMax']);
                }
            }
        }

        // Critères dépendant du type de bien
        if (array_key_exists("typeBien", $formFieldsValues)) {
            switch ($formFieldsValues['typeBien']) {
                case ReferenceData::TYPE_BIEN_APPARTEMENT:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_APPARTEMENT);
                    if (array_key_exists("nombreChambres", $formFieldsValues) && $formFieldsValues['nombreChambres'] != -1) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_CHAMBRES . '=:nombreChambres')
                                ->setParameter('nombreChambres', $formFieldsValues['nombreChambres']);
                    }
                    if (array_key_exists("minSDB", $formFieldsValues) && $formFieldsValues['minSDB'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_SALLES_DE_BAINS . '>=:minSDB')
                                ->setParameter('minSDB', $formFieldsValues['minSDB']);
                    }
                    if (array_key_exists("maxSDB", $formFieldsValues) && $formFieldsValues['maxSDB'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_SALLES_DE_BAINS . '<=:maxSDB')
                                ->setParameter('maxSDB', $formFieldsValues['maxSDB']);
                    }
                    if (array_key_exists("avecParking", $formFieldsValues) && $formFieldsValues['avecParking'] != -1 && $formFieldsValues['avecParking'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avecParking')
                                ->setParameter('avecParking', $formFieldsValues['avecParking']);
                    }
                    if (array_key_exists("avecBarriere", $formFieldsValues) && $formFieldsValues['avecBarriere'] != -1 && $formFieldsValues['avecBarriere'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_BARRIERE . '=:avecBarriere')
                                ->setParameter('avecBarriere', $formFieldsValues['avecBarriere']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_STUDIO:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_STUDIO);
                    if (array_key_exists("avecParking", $formFieldsValues) && $formFieldsValues['avecParking'] != -1 && $formFieldsValues['avecParking'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avecParking')
                                ->setParameter('avecParking', $formFieldsValues['avecParking']);
                    }
                    if (array_key_exists("avecBarriere", $formFieldsValues) && $formFieldsValues['avecBarriere'] != -1 && $formFieldsValues['avecBarriere'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_BARRIERE . '=:avecBarriere')
                                ->setParameter('avecBarriere', $formFieldsValues['avecBarriere']);
                    }
                    if (array_key_exists("situationSalleDeBains", $formFieldsValues) && $formFieldsValues['situationSalleDeBains'] != -1 && $formFieldsValues['situationSalleDeBains'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SITUATION_SALLE_DE_BAINS . '=:situationSalleDeBains')
                                ->setParameter('situationSalleDeBains', $formFieldsValues['situationSalleDeBains']);
                    }
                    if (array_key_exists("situationToilettes", $formFieldsValues) && $formFieldsValues['situationToilettes'] != -1 && $formFieldsValues['situationToilettes'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SITUATION_TOILETTES . '=:situationToilettes')
                                ->setParameter('situationToilettes', $formFieldsValues['situationToilettes']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_MAISON:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_MAISON);
                    if (array_key_exists("nombreChambres", $formFieldsValues) && $formFieldsValues['nombreChambres'] != -1) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_CHAMBRES . '=:nombreChambres')
                                ->setParameter('nombreChambres', $formFieldsValues['nombreChambres']);
                    }
                    if (array_key_exists("avecParking", $formFieldsValues) && $formFieldsValues['avecParking'] != -1 && $formFieldsValues['avecParking'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avecParking')
                                ->setParameter('avecParking', $formFieldsValues['avecParking']);
                    }
                    if (array_key_exists("avecBarriere", $formFieldsValues) && $formFieldsValues['avecBarriere'] != -1 && $formFieldsValues['avecBarriere'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_BARRIERE . '=:avecBarriere')
                                ->setParameter('avecBarriere', $formFieldsValues['avecBarriere']);
                    }
                    if (array_key_exists("typeMaisonId", $formFieldsValues) && $formFieldsValues['typeMaisonId'] != -1 && $formFieldsValues['typeMaisonId'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::TYPE_MAISON_ID . '=:typeMaisonId')
                                ->setParameter('typeMaisonId', $formFieldsValues['typeMaisonId']);
                    }
                    if (array_key_exists("minSDB", $formFieldsValues) && $formFieldsValues['minSDB'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_SALLES_DE_BAINS . '>=:minSDB')
                                ->setParameter('minSDB', $formFieldsValues['minSDB']);
                    }
                    if (array_key_exists("maxSDB", $formFieldsValues) && $formFieldsValues['maxSDB'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_SALLES_DE_BAINS . '<=:maxSDB')
                                ->setParameter('maxSDB', $formFieldsValues['maxSDB']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_TERRAIN:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_TERRAIN);
                    if (array_key_exists("surfaceMin", $formFieldsValues) && $formFieldsValues['surfaceMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surfaceMin')
                                ->setParameter('surfaceMin', $formFieldsValues['surfaceMin']);
                    }
                    if (array_key_exists("surfaceMax", $formFieldsValues) && $formFieldsValues['surfaceMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surfaceMax')
                                ->setParameter('surfaceMax', $formFieldsValues['surfaceMax']);
                    }
                    if (array_key_exists("titre", $formFieldsValues) && $formFieldsValues['titre'] != -1 && $formFieldsValues['titre'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::TITRE . '=:titre')
                                ->setParameter('titre', $formFieldsValues['titre']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_BLOC_TERRAIN:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_BLOCTERRAIN);
                    break;
                case ReferenceData::TYPE_BIEN_ENTREPOT:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_ENTREPOT);
                    if (array_key_exists("surfaceMin", $formFieldsValues) && $formFieldsValues['surfaceMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surfaceMin')
                                ->setParameter('surfaceMin', $formFieldsValues['surfaceMin']);
                    }
                    if (array_key_exists("surfaceMax", $formFieldsValues) && $formFieldsValues['surfaceMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surfaceMax')
                                ->setParameter('surfaceMax', $formFieldsValues['surfaceMax']);
                    }

                    if (array_key_exists("avecParking", $formFieldsValues) && $formFieldsValues['avecParking'] != -1 && $formFieldsValues['avecParking'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avecParking')
                                ->setParameter('avecParking', $formFieldsValues['avecParking']);
                    }
                    if (array_key_exists("avecBarriere", $formFieldsValues) && $formFieldsValues['avecBarriere'] != -1 && $formFieldsValues['avecBarriere'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_BARRIERE . '=:avecBarriere')
                                ->setParameter('avecBarriere', $formFieldsValues['avecBarriere']);
                    }
                    if (array_key_exists("avecDouche", $formFieldsValues) && $formFieldsValues['avecDouche'] != -1 && $formFieldsValues['avecDouche'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_DOUCHE . '=:avecDouche')
                                ->setParameter('avecDouche', $formFieldsValues['avecDouche']);
                    }
                    if (array_key_exists("distanceRouteMin", $formFieldsValues) && $formFieldsValues['distanceRouteMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '>=:distanceRouteMin')
                                ->setParameter('distanceRouteMin', $formFieldsValues['distanceRouteMin']);
                    }
                    if (array_key_exists("distanceRouteMax", $formFieldsValues) && $formFieldsValues['distanceRouteMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '<=:distanceRouteMax')
                                ->setParameter('distanceRouteMax', $formFieldsValues['distanceRouteMax']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_MAGASIN:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_MAGASIN);
                    if (array_key_exists("surfaceMin", $formFieldsValues) && $formFieldsValues['surfaceMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surfaceMin')
                                ->setParameter('surfaceMin', $formFieldsValues['surfaceMin']);
                    }
                    if (array_key_exists("surfaceMax", $formFieldsValues) && $formFieldsValues['surfaceMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surfaceMax')
                                ->setParameter('surfaceMax', $formFieldsValues['surfaceMax']);
                    }

                    if (array_key_exists("avecParking", $formFieldsValues) && $formFieldsValues['avecParking'] != -1 && $formFieldsValues['avecParking'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avecParking')
                                ->setParameter('avecParking', $formFieldsValues['avecParking']);
                    }
                    if (array_key_exists("avecBarriere", $formFieldsValues) && $formFieldsValues['avecBarriere'] != -1 && $formFieldsValues['avecBarriere'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_BARRIERE . '=:avecBarriere')
                                ->setParameter('avecBarriere', $formFieldsValues['avecBarriere']);
                    }
                    if (array_key_exists("avecDouche", $formFieldsValues) && $formFieldsValues['avecDouche'] != -1 && $formFieldsValues['avecDouche'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::AVEC_DOUCHE . '=:avecDouche')
                                ->setParameter('avecDouche', $formFieldsValues['avecDouche']);
                    }
                    if (array_key_exists("distanceRouteMin", $formFieldsValues) && $formFieldsValues['distanceRouteMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '>=:distanceRouteMin')
                                ->setParameter('distanceRouteMin', $formFieldsValues['distanceRouteMin']);
                    }
                    if (array_key_exists("distanceRouteMax", $formFieldsValues) && $formFieldsValues['distanceRouteMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '<=:distanceRouteMax')
                                ->setParameter('distanceRouteMax', $formFieldsValues['distanceRouteMax']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_BOUTIQUE:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_BOUTIQUE);
                    if (array_key_exists("surfaceMin", $formFieldsValues) && $formFieldsValues['surfaceMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surfaceMin')
                                ->setParameter('surfaceMin', $formFieldsValues['surfaceMin']);
                    }
                    if (array_key_exists("surfaceMax", $formFieldsValues) && $formFieldsValues['surfaceMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surfaceMax')
                                ->setParameter('surfaceMax', $formFieldsValues['surfaceMax']);
                    }
                    if (array_key_exists("distanceRouteMin", $formFieldsValues) && $formFieldsValues['distanceRouteMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '>=:distanceRouteMin')
                                ->setParameter('distanceRouteMin', $formFieldsValues['distanceRouteMin']);
                    }
                    if (array_key_exists("distanceRouteMax", $formFieldsValues) && $formFieldsValues['distanceRouteMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '<=:distanceRouteMax')
                                ->setParameter('distanceRouteMax', $formFieldsValues['distanceRouteMax']);
                    }
                    break;
                case ReferenceData::TYPE_BIEN_BUREAU:
                    $qb->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:classKey')
                            ->setParameter('classKey', BienImmobilier::CLASSKEY_BUREAU);
                    if (array_key_exists("surfaceMin", $formFieldsValues) && $formFieldsValues['surfaceMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surfaceMin')
                                ->setParameter('surfaceMin', $formFieldsValues['surfaceMin']);
                    }
                    if (array_key_exists("surfaceMax", $formFieldsValues) && $formFieldsValues['surfaceMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surfaceMax')
                                ->setParameter('surfaceMax', $formFieldsValues['surfaceMax']);
                    }
                    if (array_key_exists("distanceRouteMin", $formFieldsValues) && $formFieldsValues['distanceRouteMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '>=:distanceRouteMin')
                                ->setParameter('distanceRouteMin', $formFieldsValues['distanceRouteMin']);
                    }
                    if (array_key_exists("distanceRouteMax", $formFieldsValues) && $formFieldsValues['distanceRouteMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::DISTANCE_DE_LA_ROUTE . '<=:distanceRouteMax')
                                ->setParameter('distanceRouteMax', $formFieldsValues['distanceRouteMax']);
                    }
                    if (array_key_exists("nombrePiecesMin", $formFieldsValues) && $formFieldsValues['nombrePiecesMin'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_PIECES . '>=:nombrePiecesMin')
                                ->setParameter('nombrePiecesMin', $formFieldsValues['nombrePiecesMin']);
                    }
                    if (array_key_exists("nombrePiecesMax", $formFieldsValues) && $formFieldsValues['nombrePiecesMax'] != NULL) {
                        $qb->andWhere('bi.' . BienImmobilier::NOMBRE_PIECES . '<=:nombrePiecesMax')
                                ->setParameter('nombrePiecesMax', $formFieldsValues['nombrePiecesMax']);
                    }
                    break;
            }
        }

//        $qb = $this->getDoctrine()->getManager()->createQueryBuilder();
//        $qb->select('bi')
//                ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi');
//        $qb->where('bi.' . BienImmobilier::TYPE_TRANSACTION . ' = :typeTransaction')
//                ->setParameter('typeTransaction', $formFieldsValues["typeTransaction"] == 0 ? FALSE : TRUE);
        $query = $qb->getQuery();
        $listebiens = $query->getResult();
//          $listebiens=$this->getDoctrine()->getManager()->getRepository('KoutchoumiFrontendBundle:BienImmobilier')
//                            ->findBy(array('typeTransaction'=>$typeTransaction==0?FALSE:TRUE), array(),5000,0);
//          foreach($listebiens as $bien ){
//              echo('type: ');
//              echo($bien->getClassKey());
//          }
        $trouverBienAvanceForm=$this->createForm(new TrouverBienAvanceForm);
        return $this->render('KoutchoumiFrontendBundle::trouverBien.html.twig', array('listebiens' => $listebiens, 'trouverBienAvanceForm'=>$trouverBienAvanceForm->createView(), 'typeBien'=>$formFieldsValues['typeBien'], 'ReferenceData' => new ReferenceData($this->container->get('translator'))));
    }

//    protected function processContactKoutchoumiForm(Request $request, $form) {
//        $form->handleRequest($request);
//        if ($form->isValid()) {
//            $email = $form->get('email')->getData();
//            $nom = $form->get('nom')->getData();
//            $message = $form->get('message')->getData();
//
//            $this->sendMessageToKoutchoumi($email, $nom, $message);
//
//            //redirect vers  la page d'accueil des annonceurs
//            return $this->render('KoutchoumiFrontendBundle::thankyou.html.twig');
//        } else {
//            return $this->render('KoutchoumiFrontendBundle::contactKoutchoumi.html.twig', array('form'=>$form->createView()));
//        }
//    }

    private function sendMessageToKoutchoumi($userEmail, $userName, $userMessage) {
        // Récupération du service.
        $mailer = $this->get('mailer');
        //On construit le corps message à envoyer
        $msg = "Message d'un utilisateur de Koutchoumi Immobilier<br/>";
        $msg .= "Email:" . $userEmail . "<br/>";
        $msg .= "Nom:" . $userName . "<br/>";
        $msg .= "Message:" . "<br/>" . $userMessage;

        $from = $userEmail;
        $to = $this->container->getParameter('customer_care_email');
        $subject = "Koutchoumi Immobilier - Message de " . $userName;

//        try {
        // Création de l'e-mail.
        $message = \Swift_Message::newInstance()
                ->setSubject($subject)
                ->setFrom($from)
                ->setTo($to)
                ->setBody($msg);
        // Envoi du $message.
        $mailer->send($message);
//        } catch (KoutchoumiException $e) {
//            $log = $e->__toString();
//            $this->logMessage($log);
//            throw $e;
//        }
    }

    public function koutchoumiEstSerieuxAction(Request $request) {
        return $this->render('KoutchoumiFrontendBundle::koutchoumiEstSerieux.html.twig');
    }

}
