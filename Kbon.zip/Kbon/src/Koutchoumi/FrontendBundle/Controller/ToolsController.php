<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ToolsController
 *
 * @author J
 */
// src/Koutchoumi/FrontendBundle/Controller/main/ToolsController.php

namespace Koutchoumi\FrontendBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Httpfoundation\Response;
use Symfony\Component\Httpfoundation\Request;
use Koutchoumi\FrontendBundle\Form\BuildKoutchoumiWidgetForm;

class ToolsController extends Controller {

    public function createWidgetAction(Request $request) {
        $session=$request->getSession();
        $buildKoutchoumiWidgetForm = $this->createForm(new BuildKoutchoumiWidgetForm($session));
        $buildKoutchoumiWidgetForm->handleRequest($request);
        
        if ($request->isMethod('post')) {
            $this->processCreateWidgetForm($request, $buildKoutchoumiWidgetForm);
        } else {
            // mode get: le widget s'affiche avec les paramètres par défaut
//            $widgetCode = '<script language="javascript" type="text/javascript" src="' . $this->container->getParameter("app_koutchoumiwidget_site") . '/' . $buildKoutchoumiWidgetForm->getDefault('langue') . '/tools/showWidget?';
            $widgetCode = '<script language="javascript" type="text/javascript" src="' . $this->container->getParameter("app_koutchoumiwidget_site") . '/' . $buildKoutchoumiWidgetForm->get('langue')->getData() . '/tools/showWidget?';
            $formName = $buildKoutchoumiWidgetForm->getName();
            foreach ($buildKoutchoumiWidgetForm as $formField) {
//                $widgetCode .= $formName . "[" . $formField->getName() . "]=" . rawurlencode($buildKoutchoumiWidgetForm->getDefault($formField->getName())) . "&";
                $widgetCode .= $formName . "[" . $formField->getName() . "]=" . rawurlencode($buildKoutchoumiWidgetForm->get($formField->getName())->getData()) . "&";
            }
            $widgetCode .= '"></script>';
        }
        return $this->render('KoutchoumiFrontendBundle:tools:createWidget.html.twig', array('buildKoutchoumiWidgetForm'=>$buildKoutchoumiWidgetForm->createView()));
    }

    public function showWidgetAction(Request $request) {
        // Pas de layout
        $this->setLayout(false);

        // Le content-type est text/javascript
        $this->getResponse()->setHttpHeader('Content-Type', 'text/javascript');

        try {
            $form = new BuildKoutchoumiWidgetForm();
            $formsParam = $request->getParameter($form->getName());
            $form->bind($formsParam);
            if ($form->isValid()) {
                // 1. On récupère les paramètres du widget à afficher
                $villeId = $form->getValue('villeId');
                $typeBien = $form->getValue('typeBien');
                $nombreAnnoncesAAfficher = $form->getValue('nombreAnnoncesAAfficher');
                $langue = $form->getValue('langue');
                $largeur = $form->getValue('largeur');
                $police = $form->getValue('police');
                $couleurDeFondEnTete = $form->getValue('couleurDeFondEnTete');
                $titre = $form->getValue('titre');
                $tailleTitre = $form->getValue('tailleTitre');
                $couleurDeFondCorps = $form->getValue('couleurDeFondCorps');
                $tailleLiensCorps = $form->getValue('tailleLiensCorps');
                $couleurLiens = $form->getValue('couleurLiens');
                $couleurLiensOnHover = $form->getValue('couleurLiensOnHover');

                $this->getUser()->setCulture($langue);
                // 2. On construit les annonces à afficher
                $criteria = new Criteria();
                if ($villeId != -1) {
                    $criteria->add(BienImmobilierPeer::VILLE_ID, $villeId);
                }
                if ($typeBien != -1) {
                    $criteria->add(BienImmobilierPeer::CLASS_KEY, $typeBien);
                }
                $criteria->setLimit($nombreAnnoncesAAfficher);
                $criteria->addDescendingOrderByColumn(BienImmobilierPeer::DATE_PUBLICATION);
                $criteria->addDescendingOrderByColumn(BienImmobilierPeer::NOMBRE_HITS);
                $criteria->addAscendingOrderByColumn(BienImmobilierPeer::PRIX);

                $biensAAfficher = BienManager::trouverBien($criteria);
                $this->widgetAds = array();
                $utm = sfConfig::get("app_koutchoumiwidget_utmparameters");
                foreach ($biensAAfficher as $bienImmo) {
                    $this->widgetAds[] = array(
                        'title' => $bienImmo->getTitle(),
                        'link' => BienManager::generateURLForBienImmobilierI18n($bienImmo, $this->getUser()->getCulture()) . "?" . $utm
                    );
                }

                // 3. On fixe les paramètres d'affichage du widget
                $this->widgetParameters = array();
                $this->widgetParameters['largeur'] = $largeur;
                $this->widgetParameters['police'] = $police;
                $this->widgetParameters['couleurDeFondEnTete'] = $couleurDeFondEnTete;
                $this->widgetParameters['titre'] = $titre;
                $this->widgetParameters['tailleTitre'] = $tailleTitre;
                $this->widgetParameters['couleurDeFondCorps'] = $couleurDeFondCorps;
                $this->widgetParameters['tailleLiensCorps'] = $tailleLiensCorps;
                $this->widgetParameters['couleurLiens'] = $couleurLiens;
                $this->widgetParameters['couleurLiensOnHover'] = $couleurLiensOnHover;

                // 4. We log this widget usage
                try {
                    $webPageSource = $request->getReferer();
                    $displayDate = time();
                    WidgetUsageManager::logWidgetUsage($webPageSource, $displayDate, $langue);
                } catch (Exception $e) {
                    // Never mind if something gets wrong here.
                    $this->logMessage($e->getMessage() . " - " . $e->getTraceAsString(), 'err');
                }
            } else {
                foreach ($form as $widget) {
                    if ($widget->hasError()) {
                        $this->logMessage($widget->renderLabel() . " - " . $widget->getError());
                    }
                }
                // On retourne la vue erreur
                return sfView::ERROR;
            }
        } catch (Exception $e) {
            // On loggue l'exception
            $this->logMessage($e->getMessage() . " - " . $e->getTraceAsString(), 'err');
            // On retourne la vue erreur
            return sfView::ERROR;
        }
    }

    public function processCreateWidgetForm(Request $request, $form) {
        $formsParam = $request->getParameter($form->getName());
        $form->bind($formsParam);
        if ($form->isValid()) {
            $this->widgetCode = '<script language="javascript" type="text/javascript" src="' . sfConfig::get("app_koutchoumiwidget_site") . '/' . $this->getUser()->getCulture() . '/tools/showWidget?';
            $formName = $form->getName();
            foreach ($formsParam as $key => $value) {
                $this->widgetCode .= $formName . "[" . $key . "]=" . rawurlencode($value) . "&";
            }
            $this->widgetCode .= '"></script>';
            $this->setTemplate('createWidget');
        } else {
            $this->widgetCode = "";
        }
    }

}

?>
