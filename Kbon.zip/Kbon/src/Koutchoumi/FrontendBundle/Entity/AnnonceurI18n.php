<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AnnonceurI18n
 *
 * @ORM\Table(name="annonceur_i18n")
 * @ORM\Entity
 */
class AnnonceurI18n {

    /**
     * @var string
     *
     * @ORM\Column(name="culture", type="string", length=7, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $culture;

    /**
     * @var string
     *
     * @ORM\Column(name="conditions", type="text", nullable=true)
     */
    private $conditions;

//    /**
//     * @var integer
//     *
//     * @ORM\Id
//     * @ORM\GeneratedValue(strategy="NONE")
//     * @ORM\OneToOne(targetEntity="Annonceur")
//     * @ORM\JoinColumns({
//     *   @ORM\JoinColumn(name="id", referencedColumnName="id")
//     * })
//     */
//    private $id;

    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     *   @ORM\Column(name="id", type="integer", nullable=false)
     */
    private $id;

    /**
     * Set culture
     *
     * @param string $culture
     * @return AnnonceurI18n
     */
    public function setCulture($culture) {
        $this->culture = $culture;

        return $this;
    }

    /**
     * Get culture
     *
     * @return string 
     */
    public function getCulture() {
        return $this->culture;
    }

    /**
     * Set conditions
     *
     * @param string $conditions
     * @return AnnonceurI18n
     */
    public function setConditions($conditions) {
        $this->conditions = $conditions;

        return $this;
    }

    /**
     * Get conditions
     *
     * @return string 
     */
    public function getConditions() {
        return $this->conditions;
    }

    /**
     * Set id
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Annonceur $id
     * @return AnnonceurI18n
     */
    public function setId(\Koutchoumi\FrontendBundle\Entity\Annonceur $id) {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Annonceur 
     */
    public function getId() {
        return $this->id;
    }

}