<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AnnonceurManager
 *
 * @author pattchen, J
 */
namespace Koutchoumi\FrontendBundle\Entity;
class AnnonceurManager {

    const PROFIL_ANNONCEUR_HOMEOWNERS_ID = 5;

    /**
     * Enregistre un annonceur et le met automatiquement à l'état "En attente de validation email"
     * @return int ID de l'annonceur enregistré
     * @param Annonceur Objet annonceur à enregistrer
     * @throws KoutchoumiException
     */
    public static function createAnnonceur($annonceur) {
        //On enregistre l'annonceur avec le statut en attente de validation email
        $annonceur->setStatut(StatutAnnonceur::EN_ATTENTE_DE_VALIDATION_EMAIL);
        //On crypte le mot de passe
        $encryptedPassword = md5($annonceur->getMotdepasse());
        $annonceur->setMotdepasse($encryptedPassword);

        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
//        try {
            $em->persist($annonceur);
            $em->flush();
            return $annonceur->getId();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    /**
     * Retrouve un annonceur à partir de son identifiant
     * @return Annonceur Objet annonceur associé à l'identifiant NULL s'il n'existe pas
     * @param int $pk
     * @throws KoutchoumiException
     */
    public static function getAnnonceurByPK($pk)
    {
        try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle::Annonceur')->findOneBy($pk);
        } catch (PropelException $e) {
            throw new KoutchoumiException($e->getMessage());
        }
    }


    /**
     * Retrouve un annonceur ayant un email donné
     * @return Annonceur Objet annonceur associé à l'adresse email ou NULL s'il n'existe pas
     * @param string $email
     * @throws KoutchoumiException
     */
//    public static function getAnnonceurByEmail($email)
//    {
//        $c = new Criteria();
//        $c->add(AnnonceurPeer::EMAIL, $email, Criteria::EQUAL);
//        try{
//            return AnnonceurPeer::doSelectOne($c);
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
//    }

    /**
     * Change le statut d'un annonceur
     * @param int $pk Identifiant de l'agent immobilier dont on veut modifier le statut
     * @param int $finalStatus Statut final (Donné par des constantes définies dans StatutAnnonceur)
     * @return int Le nombre de lignes mises à jour
     * @throws KoutchoumiException
     */
    public static function changeAnnonceurState($pk, $finalStatus) {
        //TODO: vérification de la cohérence de la transition
        $em=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $a = $em->getRepository('KoutchoumiFrontendBundle::Annonceur')->findOneBy($pk);
        $initialStatus = $a->getStatut();

        //Mise à jour du statut
        $a->setStatut($finalStatus);
        try {
            $em->persist($a);
            $em->flush();
//            return $a->save();
        } catch (PropelException $e) {
            throw new KoutchoumiException($e->getMessage());
        }
    }

    public static function retrieveActiveAnnonceurs($villeId = NULL) {
        $qb = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder();
        $qb->select('an')
                ->from('KoutchoumiFrontendBundle:Annonceur', 'an')
                ->where('an.statut=:stAnn')
                ->setParameter('stAnn', StatutAnnonceur::DIGNE_DE_CONFIANCE);
        if ($villeId != NULL) {
            $qb->andWhere('an.ville=:vlAnn')
                    ->setParameter('vlAnn', $villeId);
        }
//        try{
//            return AnnonceurPeer::doSelect($criteria);
//        } catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

//    public static function retrieveActiveAnnonceursExceptHomeOwners($villeId = NULL){
//        $criteria = new Criteria();
//        $criteria->add(AnnonceurPeer::STATUT, StatutAnnonceur::DIGNE_DE_CONFIANCE);
//        $criteria->add(AnnonceurPeer::PROFIL_ID, self::PROFIL_ANNONCEUR_HOMEOWNERS_ID, Criteria::NOT_EQUAL);
//        if($villeId != NULL){
//            $criteria->add(AnnonceurPeer::VILLE_ID, $villeId);
//        }
//        try{
//            return AnnonceurPeer::doSelect($criteria);
//        } catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
//    }

    /**
     * Cette méthode sauvegarde une question posée par un internaute concernant un bien en base et l' envoie à l'annonceur du bien
     * @param <type> $emailInternaute @email de celui qui envoie la question.
     * @param <type> $numeroTelelephoneInternaute tel de celui qui envoie la question.
     * @param <type> $nameInternaute Nom de celui qui envoie la question
     * @param <type> $questions Questions posées par l'internaute.
     * @param <type> $bienImmoId Id du bien immobilier sur lequel porte cette question.
     */
//    public static function askQuestions($emailInternaute, $numeroTelelephoneInternaute, $nameInternaute, $questions, $bienImmoId){
//        try {
//            $bienImmo = BienManager::getBien($bienImmoId);
//            $urlBien = BienManager::generateURLForBienImmobilier($bienImmo);
//            $shortDescription = $bienImmo->getShortDescription();;
//
//            // On enregistre la question en base
//            $qa = new QuestionAnnonceur();
//            $qa->setFromEmail($emailInternaute);
//            $qa->setFromNumeroTelephone($numeroTelelephoneInternaute);
//            $qa->setFromName($nameInternaute);
//            $qa->setQuestions($questions);
//            $qa->setBienImmobilierId($bienImmoId);
//            $qa->setIsRead(false);
//            $qa->save();
//
//            // On envoie la question à l'annonceur par email
//            $subject = "Koutchoumi.com - Un client souhaite en savoir plus sur votre bien immobilier ". $bienImmo->getReference();
//            // Formattage du message
//            /*
//            $messageContent = "<questionInternaute><nom>$nameInternaute</nom><email>$emailInternaute</email><numeroTelephone>$numeroTelelephoneInternaute</numeroTelephone>
//            <questions>$questions</questions><bienImmo><shortDescription>$shortDescription</shortDescription><url>$urlBien</url></bienImmo>
//            </questionInternaute>";            
//            $xslDoc = sfConfig::get('sf_apps_dir') . '/frontend/templates/questionsInternaute.xsl';
//            $xmlDataFormatter = new XMLDataFormatter($xslDoc);
//            $messageToSend = $xmlDataFormatter->formatData($messageContent);
//            */
//            $messageToSend = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
//            <html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></meta></head><body><div style="width:500px">
//              Bonjour,<br></br>
//                Un client a une <span style="font-weight: bold;text-decoration: underline;color: green">question</span> concernant un bien immobilier que vous avez publié sur <span style="font-weight: bold;color: green">koutchoumi.com</span>.<br></br>
//                ------<br></br>'.$shortDescription.'<br></br>
//                ------<br></br><span style="font-weight: bold">Nom</span>: '.$nameInternaute.'<br></br><span style="font-weight: bold">Email</span>: '.$emailInternaute.'<br></br><span style="font-weight: bold">Numéro de téléphone</span>: '.$numeroTelelephoneInternaute.'<br></br><span style="font-weight: bold">Questions</span>: <br></br>'.$questions.'<br></br>
//                ------<br></br><a href="'.$urlBien.'">
//                  Voir les détails du bien </a><br></br>
//                ------<br></br><span style="font-style: italic">koutchoumi.com vous remercie d\'avoir publié sur sa plateforme.</span><p style="border:2px;border-style:solid; border-color:#CCCCCC; padding:10px; font-size:14px;"><strong>Content de nos services ? </strong><a href="http://www.koutchoumi.com/invite">Invitez vos connaisances à découvrir koutchoumi.com</a></p></div></body></html>
//            ';
//            
//            // On récupère l'adresse email de l'annonceur
//            $emailAnnonceur = $bienImmo->getAnnonceur()->getEmail();
//
//            EmailManager::sendEmail($subject, $messageToSend, $emailInternaute, $emailInternaute, $emailAnnonceur);
//            return $messageToSend;
//        } catch (Exception $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
//    }

    /**
     * Cette méthode sauvegarde une demande de visite d'un internaute concernant un bien en base et l'envoie par email à l'annonceur du bien
     * @param <type> $emailInternaute @email de celui qui envoie la demande de visite.
     * @param <type> $numeroTelelephoneInternaute tel de celui qui envoie la demande de visite.
     * @param <type> $nameInternaute Nom de celui qui envoie la demande de visite.
     * @param <type> $dateVisite Date proposée pour la visite. Au format yyyy-mm-dd, exple: 2010-06-20.
     * @param <type> $heureVisite Heure proposée pour la visite. Au format hh:min:sec, exple: 13:40:28.
     * @param <type> $precisionsVisite Autres précisions concernant la visite
     * @param <type> $bienImmoId Id du bien immobilier sur lequel porte cette demande de visite.
     */
//    public static function askShowing($emailInternaute, $numeroTelelephoneInternaute, $nameInternaute, $dateVisite, $heureVisite, $precisionsVisite, $bienImmoId){
//        try {
//          $bienImmo = BienManager::getBien($bienImmoId);
//          $shortDescription = $bienImmo->getShortDescription();
//          $urlBien = BienManager::generateURLForBienImmobilier($bienImmo);
//          $dateHeureVisiteFormatee = substr($dateVisite, 8, 2) . '/' . substr($dateVisite, 5, 2) . '/' . substr($dateVisite, 0, 4) . ' , ' . $heureVisite;
//
//          // On enregistre la demande de visite en base
//          $dv = new DemandeVisiteBien();
//          $dv->setFromEmail($emailInternaute);
//          $dv->setFromNumeroTelephone($numeroTelelephoneInternaute);
//          $dv->setFromName($nameInternaute);
//          $dateHeureVisite = $dateVisite . " " . $heureVisite;
//          $dv->setDateHeureVisite($dateHeureVisite);
//          $dv->setPrecisionsVisite($precisionsVisite);
//          $dv->setBienImmobilierId($bienImmoId);
//          $dv->setIsRead(false);
//          $dv->save();
//
//          // On envoie la demande de visite à l'annonceur par email
//          // Formattage du message
//          /*
//          $messageContent = "<demandeVisite><nom>$nameInternaute</nom><email>$emailInternaute</email>
//          <numeroTelephone>$numeroTelelephoneInternaute</numeroTelephone><dateHeureVisite>$dateHeureVisiteFormatee</dateHeureVisite>
//        <precisionsVisite>$precisionsVisite</precisionsVisite><bienImmo><shortDescription>$shortDescription</shortDescription>
//            <url>$urlBien</url></bienImmo></demandeVisite>";          
//          $xslDoc = sfConfig::get('sf_apps_dir') . '/frontend/templates/demandeVisite.xsl';
//          $xmlDataFormatter = new XMLDataFormatter($xslDoc);
//          $messageToSend = $xmlDataFormatter->formatData($messageContent);
//           */
//          $messageToSend = '<div style="width:500px">
//Bonjour,<br></br>
//Un client souhaite <span style="font-weight: bold;text-decoration: underline;color: green">visiter</span> un bien immobilier que vous avez publié sur <span style="font-weight: bold;color: green">koutchoumi.com</span>.<br></br>
//------<br></br>'.$shortDescription.'<br></br>
//------<br></br><span style="font-weight: bold">Nom</span>: '.$nameInternaute.'<br></br><span style="font-weight: bold">Email</span>: '.$emailInternaute.'<br></br><span style="font-weight: bold">Numéro de téléphone</span>: '.$numeroTelelephoneInternaute.'<br></br><span style="font-weight: bold">Date et heure souhaitées pour la visite</span>: <span style="font-weight: bold;font-size: x-large;text-decoration: underline;color: green">'.$dateHeureVisiteFormatee.'</span><br></br><span style="font-weight: bold">Autres précisions</span>: <br></br>'.$precisionsVisite.'<br></br>
//------<br></br><a href="'.$urlBien.'">
//                        Voir les détails du bien
//                </a><br></br>
//                ------<br></br><span style="font-style: italic">koutchoumi.com vous remercie d\'avoir publié sur sa plateforme.</span><p style="border:2px;border-style:solid; border-color:#CCCCCC; padding:10px; font-size:14px;"><strong>Content de nos services ? </strong><a href="http://www.koutchoumi.com/invite">Invitez vos connaisances à découvrir koutchoumi.com</a></p></div>
//';
//          
//          // On récupère l'adresse email de l'annonceur
//          $emailAnnonceur = $bienImmo->getAnnonceur()->getEmail();
//
//          $subject = "Koutchoumi.com - Un client souhaite visiter votre bien immobilier ". $bienImmo->getReference();
//
//          EmailManager::sendEmail($subject, $messageToSend, $emailInternaute, $emailInternaute, $emailAnnonceur);
//      } catch (Exception $e) {
//          throw new KoutchoumiException($e->getMessage());
//      }
//
//    }
}

?>