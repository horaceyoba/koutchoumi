<?php
/**
 *Représente une instance d'un BienImmobilier de type studio
 */
namespace Koutchoumi\FrontendBundle\Entity; 
class Studio extends BienImmobilier {

	/**
	 * Constructs a new Studio class, setting the class_key column to BienImmobilierPeer::CLASSKEY_ST.
	 */
    private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_STUDIO);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Chambre");
        }

        /**
         * @return Description en français dans le texte de l'appart.
         * Exple: Appartement meublé 1 S, 3 CH, 2 SDB à louer(200 000 FCFA) à Douala/Deido/Derrière la mairie.
         */
        public function getDescription()
        {
            return $this->getShortDescription();
        }

        public function getShortDescription()
        {
            $shortDes = self::getLibelleTypeBien(). ' '. ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    number_format($this->getPrix(), 0, '.', ' ') . ' FCFA / '.$this->translator->trans.' - '.
                    $this->translator->trans('toilettes').':' . ReferenceData::getLibelleSituationSDBsOuToilettes($this->getSituationToilettes()). ', '.$this->translator->trans('SDB').':' .
                    ReferenceData::getLibelleSituationSDBsOuToilettes($this->getSituationSalleDeBains());
                    ;

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = self::getLibelleTypeBien(). ' '. ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('toilettes').':' . ReferenceData::getLibelleSituationSDBsOuToilettes($this->getSituationToilettes()). ', '.$this->translator->trans.':' .
                    ReferenceData::getLibelleSituationSDBsOuToilettes($this->getSituationSalleDeBains());
                    ;

            return $shortDes;            
        }

        /**
         * Chambre à louer à Douala, Akwa I - 20 000 Fcfa
         */
        public function getTitle()
        {
            $title = Studio::getLibelleTypeBien(). " ".ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " ".$this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }

} // Studio
