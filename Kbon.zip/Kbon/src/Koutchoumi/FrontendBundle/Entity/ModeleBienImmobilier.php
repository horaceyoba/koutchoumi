<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ModeleBienImmobilier
 *
 * @ORM\Table(name="modele_bien_immobilier")
 * @ORM\Entity
 */
class ModeleBienImmobilier
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var boolean
     *
     * @ORM\Column(name="type_bien", type="boolean", nullable=false)
     */
    protected $typeBien;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nombre_salons", type="boolean", nullable=true)
     */
    protected $nombreSalons;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nombre_chambres", type="boolean", nullable=true)
     */
    protected $nombreChambres;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nombre_salles_de_bains", type="boolean", nullable=true)
     */
    protected $nombreSallesDeBains;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nombre_cuisines", type="boolean", nullable=true)
     */
    protected $nombreCuisines;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var \TypeMaison
     *
     * @ORM\ManyToOne(targetEntity="TypeMaison")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="type_maison_id", referencedColumnName="id")
     * })
     */
    protected $typeMaison;

    /**
     * @var \integer
     *
     *   @ORM\Column(name="type_maison_id", type="integer")
     */
    protected $typeMaisonId;
    

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return ModeleBienImmobilier
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    
        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set typeBien
     *
     * @param boolean $typeBien
     * @return ModeleBienImmobilier
     */
    public function setTypeBien($typeBien)
    {
        $this->typeBien = $typeBien;
    
        return $this;
    }

    /**
     * Get typeBien
     *
     * @return boolean 
     */
    public function getTypeBien()
    {
        return $this->typeBien;
    }

    /**
     * Set nombreSalons
     *
     * @param boolean $nombreSalons
     * @return ModeleBienImmobilier
     */
    public function setNombreSalons($nombreSalons)
    {
        $this->nombreSalons = $nombreSalons;
    
        return $this;
    }

    /**
     * Get nombreSalons
     *
     * @return boolean 
     */
    public function getNombreSalons()
    {
        return $this->nombreSalons;
    }

    /**
     * Set nombreChambres
     *
     * @param boolean $nombreChambres
     * @return ModeleBienImmobilier
     */
    public function setNombreChambres($nombreChambres)
    {
        $this->nombreChambres = $nombreChambres;
    
        return $this;
    }

    /**
     * Get nombreChambres
     *
     * @return boolean 
     */
    public function getNombreChambres()
    {
        return $this->nombreChambres;
    }

    /**
     * Set nombreSallesDeBains
     *
     * @param boolean $nombreSallesDeBains
     * @return ModeleBienImmobilier
     */
    public function setNombreSallesDeBains($nombreSallesDeBains)
    {
        $this->nombreSallesDeBains = $nombreSallesDeBains;
    
        return $this;
    }

    /**
     * Get nombreSallesDeBains
     *
     * @return boolean 
     */
    public function getNombreSallesDeBains()
    {
        return $this->nombreSallesDeBains;
    }

    /**
     * Set nombreCuisines
     *
     * @param boolean $nombreCuisines
     * @return ModeleBienImmobilier
     */
    public function setNombreCuisines($nombreCuisines)
    {
        $this->nombreCuisines = $nombreCuisines;
    
        return $this;
    }

    /**
     * Get nombreCuisines
     *
     * @return boolean 
     */
    public function getNombreCuisines()
    {
        return $this->nombreCuisines;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return ModeleBienImmobilier
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return ModeleBienImmobilier
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set typeMaison
     *
     * @param \Koutchoumi\FrontendBundle\Entity\TypeMaison $typeMaison
     * @return ModeleBienImmobilier
     */
    public function setTypeMaison(\Koutchoumi\FrontendBundle\Entity\TypeMaison $typeMaison = null)
    {
        $this->typeMaison = $typeMaison;
    
        return $this;
    }

    /**
     * Get typeMaison
     *
     * @return \Koutchoumi\FrontendBundle\Entity\TypeMaison 
     */
    public function getTypeMaison()
    {
        return $this->typeMaison;
    }
    
    /**
     * Set typeMaisonId
     *
     * @param int $typeMaisonId
     * @return ModeleBienImmobilier
     */
    public function setTypeMaisonId($typeMaisonId = null)
    {
        $this->typeMaisonId = $typeMaisonId;
    
        return $this;
    }

    /**
     * Get typeMaisonId
     *
     * @return int 
     */
    public function getTypeMaisonId()
    {
        return $this->typeMaisonId;
    }
}