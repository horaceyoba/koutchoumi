<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Profil
 *
 * @ORM\Table(name="profil")
 * @ORM\Entity
 */
class Profil
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
    
    public function getLibelle() {

        $libelles = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                ->select('pfI18n.libelle')
                ->from('KoutchoumiFrontendBundle:ProfilI18n', 'pfI18n')
                ->where('pfI18n.id=:id')
                ->andWhere('pfI18n.culture=:locale')
                ->setParameters(array('id' => ($this->id), 'locale' => (\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('locale'))))
                ->getQuery()
                ->getResult();
        if (!empty($libelles)) {
            $lib = (string) $libelles[0]['libelle'];
        }
        else
            $lib = "";
        return $lib;
    }

    public function __toString() {
        return (string)$this->getLibelle();
    }
}