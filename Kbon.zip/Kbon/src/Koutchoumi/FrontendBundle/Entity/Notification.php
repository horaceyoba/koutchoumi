<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Notification
 *
 * @ORM\Table(name="notification")
 * @ORM\Entity
 */
class Notification
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="data", type="text", nullable=true)
     */
    private $data;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="processing_date", type="datetime", nullable=true)
     */
    private $processingDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="processing_status", type="boolean", nullable=true)
     */
    private $processingStatus;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var \Subscription
     *
     * @ORM\ManyToOne(targetEntity="Subscription")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="subscription_id", referencedColumnName="id")
     * })
     */
    private $subscription;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set data
     *
     * @param string $data
     * @return Notification
     */
    public function setData($data)
    {
        $this->data = $data;
    
        return $this;
    }

    /**
     * Get data
     *
     * @return string 
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * Set processingDate
     *
     * @param \DateTime $processingDate
     * @return Notification
     */
    public function setProcessingDate($processingDate)
    {
        $this->processingDate = $processingDate;
    
        return $this;
    }

    /**
     * Get processingDate
     *
     * @return \DateTime 
     */
    public function getProcessingDate()
    {
        return $this->processingDate;
    }

    /**
     * Set processingStatus
     *
     * @param boolean $processingStatus
     * @return Notification
     */
    public function setProcessingStatus($processingStatus)
    {
        $this->processingStatus = $processingStatus;
    
        return $this;
    }

    /**
     * Get processingStatus
     *
     * @return boolean 
     */
    public function getProcessingStatus()
    {
        return $this->processingStatus;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Notification
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return Notification
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set subscription
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Subscription $subscription
     * @return Notification
     */
    public function setSubscription(\Koutchoumi\FrontendBundle\Entity\Subscription $subscription = null)
    {
        $this->subscription = $subscription;
    
        return $this;
    }

    /**
     * Get subscription
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Subscription 
     */
    public function getSubscription()
    {
        return $this->subscription;
    }
}