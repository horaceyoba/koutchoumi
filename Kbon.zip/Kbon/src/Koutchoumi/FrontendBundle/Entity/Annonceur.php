<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\AdvancedUserInterface;

/**
 * Annonceur
 *
 * @ORM\Table(name="annonceur")
 * @ORM\Entity(repositoryClass="Koutchoumi\FrontendBundle\Entity\AnnonceurRepository")
 */
class Annonceur implements AdvancedUserInterface, \Serializable {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=100, nullable=false)
     */
    protected $email;

    /**
     * @var string
     *
     * @ORM\Column(name="mot_de_passe", type="string", length=255, nullable=false)
     */
    protected $motDePasse;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="numero_telephone", type="string", length=100, nullable=false)
     */
    protected $numeroTelephone;

    /**
     * @var smallint
     *
     * @ORM\Column(name="statut", type="smallint", nullable=false)
     */
    protected $statut;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var \Profil
     *
     * @ORM\ManyToOne(targetEntity="Profil")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="profil_id", referencedColumnName="id")
     * })
     */
    protected $profil;

    /**
     * @var \Ville
     *
     * @ORM\ManyToOne(targetEntity="Ville")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="ville_id", referencedColumnName="id")
     * })
     */
    protected $ville;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Annonceur
     */
    public function setEmail($email) {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail() {
        return $this->email;
    }

    /**
     * Set motDePasse
     *
     * @param string $motDePasse
     * @return Annonceur
     */
    public function setMotDePasse($motDePasse) {
        $this->motDePasse = $motDePasse;

        return $this;
    }

    /**
     * Get motDePasse
     *
     * @return string 
     */
    public function getMotDePasse() {
        return $this->motDePasse;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Annonceur
     */
    public function setNom($nom) {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom() {
        return $this->nom;
    }

    /**
     * Set numeroTelephone
     *
     * @param string $numeroTelephone
     * @return Annonceur
     */
    public function setNumeroTelephone($numeroTelephone) {
        $this->numeroTelephone = $numeroTelephone;

        return $this;
    }

    /**
     * Get numeroTelephone
     *
     * @return string 
     */
    public function getNumeroTelephone() {
        return $this->numeroTelephone;
    }

    /**
     * Set statut
     *
     * @param boolean $statut
     * @return Annonceur
     */
    public function setStatut($statut) {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return smallint 
     */
    public function getStatut() {
        return $this->statut;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Annonceur
     */
    public function setCreatedAt($createdAt) {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt() {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return Annonceur
     */
    public function setUpdatedAt($updatedAt) {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt() {
        return $this->updatedAt;
    }

    /**
     * Set profil
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Profil $profil
     * @return Annonceur
     */
    public function setProfil(\Koutchoumi\FrontendBundle\Entity\Profil $profil = null) {
        $this->profil = $profil;

        return $this;
    }

    /**
     * Get profil
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Profil 
     */
    public function getProfil() {
        return $this->profil;
    }

    /**
     * Set ville
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Ville $ville
     * @return Annonceur
     */
    public function setVille(\Koutchoumi\FrontendBundle\Entity\Ville $ville = null) {
        $this->ville = $ville;

        return $this;
    }

    /**
     * Get ville
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Ville 
     */
    public function getVille() {
        return $this->ville;
    }

    /**
     * Set numeroTelephone
     *
     * @param string $numeroTelephone
     * @return Annonceur
     */
    public function setProfilId($profilId) {
        $this->profil->setId($profilId);

        return $this;
    }
    
    public function eraseCredentials() {
        
    }

    public function getPassword() {
        return $this->motDePasse;
    }

    public function getRoles() {
        return array();
    }

    public function getSalt() {
        return '';
    }

    public function getUsername() {
        return $this->email;
    }

    public function serialize() {
        return serialize(array(
                    'createdAt' => $this->createdAt,
                    'email' => $this->email,
                    'id' => (string)$this->id,
                    'motDePasse' => $this->motDePasse,
                    'nom' => $this->nom,
                    'numeroTelephone' => $this->numeroTelephone,
                    'profil' => $this->profil,
                    'statut' => $this->statut,
                    'updatedAt' => $this->updatedAt,
                    'ville' => $this->ville
                        )
        );
    }

    public function unserialize($serialized) {
        $array = unserialize($serialized);

        $this->createdAt = $array['createdAt'];
        $this->email = $array['email'];
        $this->id = $array['id'];
        $this->motDePasse = $array['motDePasse'];
        $this->nom = $array['nom'];
        $this->numeroTelephone = $array['numeroTelephone'];
        $this->profil = $array['profil'];
        $this->statut = $array['statut'];
        $this->updatedAt = $array['updatedAt'];
        $this->ville = $array['ville'];
    }

    public function __toString(){
        return (string)$this->nom;
    }
    
    public function isAccountNonExpired() {
        return true;
    }

    public function isAccountNonLocked() {
        return true;
    }

    public function isCredentialsNonExpired() {
        return true;
    }

    public function isEnabled() {
//        return $this->isActive;
        return true;
    }

}