<?php
/**
 *Représente une instance d'un BienImmobilier de type terrain
 */
namespace Koutchoumi\FrontendBundle\Entity; 

class Terrain extends BienImmobilier {

	/**
	 * Constructs a new Terrain class, setting the class_key column to BienImmobilierPeer::CLASSKEY_TE.
	 */
    private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_TERRAIN);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Terrain");
        }

        /**
         * @return Description en français dans le texte du terrain.
         * exple:Terrain titré et bâti à vendre (9 000 000 FCFA) de 400 m2 à Douala/Japoma/Derrière la station TOTAL.
         */
        public function getDescription()
        {
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $etatBati = $this->getBati() ? " et bâti" : "";
            $des = Terrain::getLibelleTypeBien() . " " . $etatTitre . $etatBati . " " . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) .
                    "(" . number_format($this->getPrix(), 0, '.', ' ') . " FCFA) de " . number_format($this->getSurface(), 0, '.', ' ') .
                    " m2 à ".  $this->getVille()->getNom() . "/" .$this->getQuartier()->getNom() . "/" . $this->getSecteur();

            return $des;
        }

        public function getShortDescription()
        {
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $etatBati = $this->getBati() ? "bâti" : "";
            $shortDes = $this->translator->trans("Terrain". ' ' .$etatTitre). ', ' . $this->translator->trans($etatBati) . ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            if($this->getBlocBienId() != NULL){
                $shortDes .= " ".sfContext::getInstance()->getI18N()->__("situé dans le bloc")." ".$this->getBienImmobilierRelatedByBlocBienId()->getReferenceMetier();
            }
            $shortDes .= ' - '.$this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->getSurface().' m2 - '. number_format($this->getPrix(), 0, '.', ' ').' FCFA';
            if($this->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_LOCATION){
                $shortDes .= " / ".$this->translator->trans("mois");
            }
            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $etatBati = $this->getBati() ? "bâti" : "";
            $shortDes = $this->translator->trans("Terrain". ' ' .$etatTitre). ', ' . $this->translator->trans($etatBati) . ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            if($this->getBlocBienId() != NULL){
                $shortDes .= " ".$this->translator->trans("situé dans le bloc")." ".$this->getBienImmobilierRelatedByBlocBienId()->getReferenceMetier();
            }
            $shortDes .= ' - '.$this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '. $this->getSurface().' m2';
            return $shortDes;
        }

        /**
         * Terrain titré à vendre à Douala, Kotto - 600 m2 - 20 000 000 Fcfa
         */
        public function getTitle()
        {
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $title = $this->translator->trans("Terrain". " " .$etatTitre). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . $this->getSurface() . " m2";
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }

}
