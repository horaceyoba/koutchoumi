<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Ville
 *
 * @ORM\Table(name="ville")
 * @ORM\Entity
 */
class Ville implements \Serializable {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Ville
     */
    public function setNom($nom) {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom() {
        return $this->nom;
    }

    public static function getVilles() {
        //Mettre un try catch
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Ville')->findAll(array('nom' => 'ASC'));
    }

    public static function getVille($villeId) {
        //Mettre un try catch
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Ville')->find($villeId);
    }

    public function save() {
        $em = $this->get('doctrine')->getManager();
        $em->persist($this);
        $em->flush();
        //parent::save($con);
    }

    public function serialize() {
        return serialize(array(
                    'id' => $this->id,
                    'nom' => $this->nom
                )
        );
    }

    public function unserialize($serialized) {
        $array = unserialize($serialized);

        $this->id = $array['id'];
        $this->nom = $array['nom'];
    }

    public function __toString(){
        return (string)$this->getNom();
    }
}