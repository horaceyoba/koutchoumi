<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Contributeur
 *
 * @ORM\Table(name="contributeur")
 * @ORM\Entity
 */
class Contributeur implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="url_profil_facebook", type="string", length=255, nullable=false)
     */
    protected $urlProfilFacebook;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Contributeur
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    
        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set urlProfilFacebook
     *
     * @param string $urlProfilFacebook
     * @return Contributeur
     */
    public function setUrlProfilFacebook($urlProfilFacebook)
    {
        $this->urlProfilFacebook = $urlProfilFacebook;
    
        return $this;
    }

    /**
     * Get urlProfilFacebook
     *
     * @return string 
     */
    public function getUrlProfilFacebook()
    {
        return $this->urlProfilFacebook;
    }

    public function serialize() {
        return serialize(array(
                    'id' => $this->id,
                    'nom' => $this->nom,
                    'urlProfilFacebook' => $this->urlProfilFacebook
                )
        );
    }

    public function unserialize($serialized) {
        $array = unserialize($serialized);

        $this->id = $array['id'];
        $this->nom = $array['nom'];
        $this->urlProfilFacebook = $array['urlProfilFacebook'];
    }

    public function __toString(){
        return (string)$this->getNom();
    }
    
}