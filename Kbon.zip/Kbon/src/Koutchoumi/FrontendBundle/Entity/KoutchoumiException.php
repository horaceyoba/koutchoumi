<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of KoutchoumiException
 *
 * @author J
 */
class KoutchoumiException extends Exception{
    //put your code here
}

?>
