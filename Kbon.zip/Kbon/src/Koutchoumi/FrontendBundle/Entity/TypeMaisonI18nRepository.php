<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TypeMaisonI18nRepository
 *
 * @author J
 */

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Tools\Pagination\Paginator;

class TypeMaisonI18nRepository extends EntityRepository{
    //put your code here
}

?>
