<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ReferenceData
 *
 * @author pattchen, J
 */

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\Common\Collections\Criteria;
use \Koutchoumi\FrontendBundle;
use \Symfony\Bundle\FrameworkBundle\Translation\Translator;

class ReferenceData {

    const TYPE_BIEN_APPARTEMENT = 1;
    const TYPE_BIEN_STUDIO = 2;
    const TYPE_BIEN_MAISON = 3;
    const TYPE_BIEN_TERRAIN = 4;
    const TYPE_BIEN_BLOC_TERRAIN = 5;
    const TYPE_BIEN_ENTREPOT = 6;
    const TYPE_BIEN_MAGASIN = 7;
    const TYPE_BIEN_BOUTIQUE= 8;
    const TYPE_BIEN_BUREAU = 9;


    const TYPE_TRANSACTION_LOCATION = FALSE;
    const TYPE_TRANSACTION_VENTE = TRUE;

    const SITUE_DANS_IMMEUBLE = 1;
    const SITUE_DANS_VILLA = 2;
    const SITUE_DANS_CITE = 3;
    const SITUE_DANS_AUCUN_DES_DEUX = 4;

    const GARDIEN_PAS_DE_GARDIEN = 1;
    const GARDIEN_NUIT_UNIQUEMENT = 2;
    const GARDIEN_24_SUR_24 = 3;

    const ETAT_SOL_NOTDEFINED = -1;
    const ETAT_SOL_CARRELE = 0;
    const ETAT_SOL_ENMARBRE = 1;
    const ETAT_SOL_CIMENTE = 2;

    const ETAT_IMMEUBLE_NOTDEFINED = -1;
    const ETAT_IMMEUBLE_VETUSTE = 0;
    const ETAT_IMMEUBLE_EN_BON_ETAT = 1;
    const ETAT_IMMEUBLE_NEUF = 2;

    const ETAT_NOTDEFINED = -1;
    const ETAT_VETUSTE = 0;
    const ETAT_EN_BON_ETAT = 1;
    const ETAT_NEUF = 2;


    const MODE_PAIEMENT_FORFAIT = 1;
    const MODE_PAIEMENT_CONSOMMATIONS = 2;

    const SITUATION_SDBS_OU_TOILETTES_INTERNE = 1;
    const SITUATION_SDBS_OU_TOILETTES_EXTERNE = 2;
    var $em;
    
    private $translator ;
    public function __construct(Translator $translator){
     $this->translator=$translator;   
    }
    public function getEntManager(){
        $em=$this->getDoctrine()->getManager();
        return $em;
    }
    public static function getVilles()
    {
        return Ville::getVilles();
//        $c = new Criteria();
//        $c->addAscendingOrderByColumn(VillePeer::NOM);        
//        try{
//            return VillePeer::doSelect($c);
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }
    

    /**
     *
     * @param int $villeId
     * @return Ville
     */
    public static function getVille($villeId)
    {
        return Ville::getVille($villeId);
        //try{
            //return $this->getDoctrine()->getManager()->getRepository('KoutchoumiFrontendBundle:Ville')->find($villeId);
        //} catch (PropelException $e) {
          //  throw new KoutchoumiException($e->getMessage());
        //}
        
    }

    /**
     *
     * @param int $quartierId
     * @return Quartier
     */
    public static function getQuartier($quartierId) {
        //try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Quartier')->find($quartierId);
        //} catch (PropelException $e) {
          //  throw new KoutchoumiException($e->getMessage());
        //}
    }

    public static function getProfils()
    {
//        try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Profil')->findAll();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    public static function getTypesMaisons()
    {
//        try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:TypeMaison')->findAll();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    public static function getModeleBienImmobiliers()
    {
//        try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:ModeleBienImmobilier')->findAll();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

/*
 * @param $modeleBienImmobilierId Identifiant d'un mod�le de bien immmobilier
 * @return ModeleBienImmobilier Objet ModeleBienImmobilier correspondant � l'Id fourni
 */
    public static function getModeleBienImmobilier($modeleBienImmobilierId)
    {
        //try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:ModeleBienImmobilier')->find($modeleBienImmobilierId);
        //} catch (PropelException $e) {
          //  throw new KoutchoumiException($e->getMessage());
        //}
    }

    public static function getModeleBienImmobiliersOfBien($typeBien)
    {
//        try{
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                ->select('mbi.*')
                ->from('KoutchoumiFrontendBundle:ModeleBienImmobilier','mbi')
                ->innerJoin('KoutchoumiFrontendBundle:TypeBien','tb', 'WITH', 'mbi.typeBien=:modelebienimmo_typebien')
                ->setParameter('modelebienimmo_typebien', $typeBien)
                ->getQuery()
                ->getResult();
                
//            $criteria = new Criteria();
//            $criteria->add(ModeleBienImmobilierPeer::TYPE_BIEN, $typeBien);
//            $criteria->addAscendingOrderByColumn(ModeleBienImmobilierPeer::NOM);
//            return ModeleBienImmobilierPeer::doSelect($criteria);
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }


    public static function getQuartiersOfVille($ville_id = NULL)
    {
        if ($ville_id!= NULL)
        {
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                ->select('q')
                ->from('KoutchoumiFrontendBundle:Quartier','q')
                ->innerJoin('KoutchoumiFrontendBundle:Ville','v', 'WITH', 'q.ville=:quartier_ville')
                ->orderBy('q.nom','ASC')
                ->setParameter('quartier_ville', $ville_id)
                ->getQuery()
                ->getResult();
        }
        else {
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Quartier')->findAll(array('nom'=>'ASC'));
        }
//        try{
//            $criteria = new Criteria();
//            $criteria->add(QuartierPeer::VILLE_ID, $ville_id);
//            $criteria->addAscendingOrderByColumn(QuartierPeer::NOM);
//            return QuartierPeer::doSelect($criteria);
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

//    private $translation=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
    public static function getTypesBiens(){
        return array(
            ReferenceData::TYPE_BIEN_STUDIO=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Chambre'),
            ReferenceData::TYPE_BIEN_APPARTEMENT=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Appartement'),
            ReferenceData::TYPE_BIEN_MAISON=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Maison'),
            ReferenceData::TYPE_BIEN_TERRAIN=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Terrain'),
            ReferenceData::TYPE_BIEN_BLOC_TERRAIN=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Bloc de terrain'),
            ReferenceData::TYPE_BIEN_ENTREPOT=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Entrepôt'),
            ReferenceData::TYPE_BIEN_MAGASIN=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Magasin'),
            ReferenceData::TYPE_BIEN_BOUTIQUE=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Boutique'),
            ReferenceData::TYPE_BIEN_BUREAU=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Bureau'),
            );
    }

    public static function getTypesBiensWithClassKey(){
        $container=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer();
        return array(
            BienImmobilier::CLASSKEY_STUDIO=>$container->get('translator')->trans('Chambre'),
            BienImmobilier::CLASSKEY_APPARTEMENT=>$container->get('translator')->trans('Appartement'),
            BienImmobilier::CLASSKEY_MAISON=>$container->get('translator')->trans('Maison'),
            BienImmobilier::CLASSKEY_TERRAIN=>$container->get('translator')->trans('Terrain'),
            BienImmobilier::CLASSKEY_BLOCTERRAIN=>$container->get('translator')->trans('Bloc de terrain'),
            BienImmobilier::CLASSKEY_ENTREPOT=>$container->get('translator')->trans('Entrep�t'),
            BienImmobilier::CLASSKEY_MAGASIN=>$container->get('translator')->trans('Magasin'),
            BienImmobilier::CLASSKEY_BOUTIQUE=>$container->get('translator')->trans('Boutique'),
            BienImmobilier::CLASSKEY_BUREAU=>$container->get('translator')->trans('Bureau'),
            );
    }


    /**
     *
     * @param <type> $codeBien code du bien RefrenceData::TYPE_BIEN... ou BienImmobilierPeer::CLASSKEY_..
     * @return string libell� du type de bien
     */
    public static function getLibelleTypeBien($codeBien) {
        switch ($codeBien) {
            case ReferenceData::TYPE_BIEN_APPARTEMENT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Appartement");
            case BienImmobilier::CLASSKEY_APPARTEMENT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Appartement");
            case ReferenceData::TYPE_BIEN_STUDIO:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Chambre");
            case BienImmobilier::CLASSKEY_STUDIO:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Chambre");
            case ReferenceData::TYPE_BIEN_MAISON:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Maison");
            case BienImmobilier::CLASSKEY_MAISON:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Maison");
            case ReferenceData::TYPE_BIEN_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Terrain");
            case BienImmobilier::CLASSKEY_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Terrain");
            case ReferenceData::TYPE_BIEN_BLOC_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bloc de terrain");
            case BienImmobilier::CLASSKEY_BLOCTERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bloc de terrain");
            case ReferenceData::TYPE_BIEN_ENTREPOT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Entrepôt");
            case BienImmobilier::CLASSKEY_ENTREPOT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Entrepôt");
            case ReferenceData::TYPE_BIEN_MAGASIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Magasin");
            case BienImmobilier::CLASSKEY_MAGASIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Magasin");
            case ReferenceData::TYPE_BIEN_BOUTIQUE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Boutique");
            case BienImmobilier::CLASSKEY_BOUTIQUE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Boutique");
            case ReferenceData::TYPE_BIEN_BUREAU:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bureau");
            case BienImmobilier::CLASSKEY_BUREAU:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bureau");


            default:
                return "Are you kidding?";
        }
    }

    public static function getLibelleTypeBienFromBien(BienImmobilier $bienImmo) {
        switch ($bienImmo) {
            case ReferenceData::TYPE_BIEN_APPARTEMENT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Appartement");
            case BienImmobilier::CLASSKEY_APPARTEMENT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Appartement");
            case ReferenceData::TYPE_BIEN_STUDIO:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Chambre");
            case BienImmobilier::CLASSKEY_STUDIO:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Chambre");
            case ReferenceData::TYPE_BIEN_MAISON:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Maison");
            case BienImmobilier::CLASSKEY_MAISON:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Maison");
            case ReferenceData::TYPE_BIEN_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Terrain");
            case BienImmobilier::CLASSKEY_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Terrain");
            case ReferenceData::TYPE_BIEN_BLOC_TERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bloc de terrain");
            case BienImmobilier::CLASSKEY_BLOCTERRAIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bloc de terrain");
            case ReferenceData::TYPE_BIEN_ENTREPOT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Entrepôt");
            case BienImmobilier::CLASSKEY_ENTREPOT:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Entrepôt");
            case ReferenceData::TYPE_BIEN_MAGASIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Magasin");
            case BienImmobilier::CLASSKEY_MAGASIN:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Magasin");
            case ReferenceData::TYPE_BIEN_BOUTIQUE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Boutique");
            case BienImmobilier::CLASSKEY_BOUTIQUE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Boutique");
            case ReferenceData::TYPE_BIEN_BUREAU:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bureau");
            case BienImmobilier::CLASSKEY_BUREAU:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Bureau");


            default:
                return "Are you kidding?";
        }
    }
    
    public static function getModesPaiement() {
        return array(
        ReferenceData::MODE_PAIEMENT_CONSOMMATIONS=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Consommations'),
        ReferenceData::MODE_PAIEMENT_FORFAIT=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Forfait'),
        );
    }

    public static function getStiueDansArray() {
        return array(
        ReferenceData::SITUE_DANS_IMMEUBLE=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Immeuble'),
		ReferenceData::SITUE_DANS_VILLA=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Villa'),
        ReferenceData::SITUE_DANS_CITE=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Cité'),
        ReferenceData::SITUE_DANS_AUCUN_DES_DEUX=>\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Aucun des 3'),
        );
    }

    public static function getTypesTransactions(){
        return array(ReferenceData::TYPE_TRANSACTION_LOCATION => \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('à louer'),
                     ReferenceData::TYPE_TRANSACTION_VENTE => \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('à vendre'));
    }

    public static function getTypeLibelleTransaction($codeTransaction)
    {
        switch($codeTransaction){
            case ReferenceData::TYPE_TRANSACTION_LOCATION:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("à louer");
            case ReferenceData::TYPE_TRANSACTION_VENTE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("à vendre");
        }
    }

    public static function getLibelleSituationSDBsOuToilettes($codeSituationSDBsOuToilettes)
    {
        switch($codeSituationSDBsOuToilettes){
            case ReferenceData::SITUATION_SDBS_OU_TOILETTES_EXTERNE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("externe");
            case ReferenceData::SITUATION_SDBS_OU_TOILETTES_INTERNE:
                return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("interne");
        }
    }

    /**
     * Renvoie le token associ� � un anonnceur
     * @param int $pk Cl� primaire en base de donn�es de l'annonceur
     * @return string Token de l'annonceur. Utilis� pour valider son adresse email
     */
    public static function generateUserTokenFromPK($pk)
    {
        return $pk + 10;
    }

    /**
     * Renvoie la clé associée à un token
     * @return int $pk Clé primaire en base de donn�es de l'annonceur
     * @param string Token de l'annonceur. Utilisé pour valider son adresse email
     */
    public static function generateUserPKFromToken($token)
    {
        return $token - 10;
    }

    /**
     * G�n�re la r�f�rence Koutchpoumi d'un bien � partir de son id en base
     * @param int $idBien Id en base de donn�es du bien dont on veut avoir la r�f�rence
     * @return string R�f�rence Koutchoumi du bien
     */
    public static function generateReferenceBien($idBien)
    {
        $ref = 'K' . sprintf('%07d', $idBien+1);
        return $ref;
    }

    /**
     *
     * @param <type> $classKey a value from the constants BienImmobilierPeer::CLASSKEY_*
     * @return <type> the correspondant constant from ReferenceData::TYPE_BIEN_*
     */
    public static function getCodeTypeBien($classKey)
    {
        switch($classKey){
            case BienImmobilier::CLASSKEY_APPARTEMENT:
                return ReferenceData::TYPE_BIEN_APPARTEMENT;
            case BienImmobilier::CLASSKEY_MAISON:
                return ReferenceData::TYPE_BIEN_MAISON;
            case BienImmobilier::CLASSKEY_STUDIO:
                return ReferenceData::TYPE_BIEN_STUDIO;
            case BienImmobilier::CLASSKEY_TERRAIN:
                return ReferenceData::TYPE_BIEN_TERRAIN;
            case BienImmobilier::CLASSKEY_BLOCTERRAIN:
                return ReferenceData::TYPE_BIEN_BLOC_TERRAIN;
            case BienImmobilier::CLASSKEY_ENTREPOT:
                return ReferenceData::TYPE_BIEN_ENTREPOT;
            case BienImmobilier::CLASSKEY_MAGASIN:
                return ReferenceData::TYPE_BIEN_MAGASIN;
            case BienImmobilier::CLASSKEY_BOUTIQUE:
                return ReferenceData::TYPE_BIEN_BOUTIQUE;
            case BienImmobilier::CLASSKEY_BUREAU:
                return ReferenceData::TYPE_BIEN_BUREAU;
        }
    }

    public static function getSupportedLanguages(){
        return array(
            'fr' => \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Français'),
            'en' => \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('Anglais')
        );
        
    }
    
    public static function getBiensImmobiliers(){
//        try{
            return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:BienImmobilier')->findAll();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        } 
    }
    
//    public function getTbs(){
//        return self::TYPE_BIEN_STUDIO;
//    }
//    
//    public function getTtl(){
//        return self::TYPE_TRANSACTION_LOCATION;
//    }
}
?>
