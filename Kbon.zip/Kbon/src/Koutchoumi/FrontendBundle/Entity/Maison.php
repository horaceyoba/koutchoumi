<?php
/**
 *Représente une instance d'un BienImmobilier de type maison
 */
namespace Koutchoumi\FrontendBundle\Entity; 

class Maison extends BienImmobilier {

	/**
	 * Constructs a new Maison class, setting the class_key column to BienImmobilierPeer::CLASSKEY_MA.
	 */
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_MAISON);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Maison");
        }

        /**
         * @return Description en français dans le texte de l'appart.
         * Exple: Maison meublée 1S, 3CH, 1 CUIS, 2 SDB à vendre (42 000 000 FCFA) à Douala/Bonapriso/Près de Goodies.
         */
        public function getDescription()
        {
            $shortDes = $this->getTypeMaison()->getLibelle(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains())).
                    " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';
            if($this->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_LOCATION){
                $shortDes .= " / ". $this->translator->trans('mois');
            };

            return $shortDes;
        }

        public function getShortDescription()
        {
            $shortDes = $this->translator->trans("Maison")." (".$this->getTypeMaison()->getLibelle(). ") " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains())).
                    " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';
            if($this->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_LOCATION){
                $shortDes .= " / ". sfContext::getInstance()->getI18N()->__('mois');
            };

            /*
            $shortDes = $this->getTypeMaison()->getLibelle(). ' '. $meuble. ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()). ' - '.
                    $this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur().' - '.
                    $this->getNombreSalons().' salon(s), '.$this->getNombreChambres().' chambres(s), '.$this->getNombreSallesDeBains().' salle(s) de bains - '.
                    number_format($this->getPrix(), 0, '.', ' ').' FCFA';
            if($this->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_LOCATION){
                $shortDes .= " / mois";
            }*/

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = $this->translator->trans("Maison")." (".$this->getTypeMaison()->getLibelle(). ") " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains()));

            return $shortDes;
        }

        /**
         * Maison (Villa) à louer à Yaoundé, Ekounou - 2 chambres - 140 000 FCFA
         */
        public function getTitle()
        {
            $title = Maison::getLibelleTypeBien(). " (" .$this->getTypeMaison()->getLibelle(). ") ".ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres()));
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }

} // Maison
