<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Criteria;

/**
 * Quartier
 *
 * @ORM\Table(name="quartier")
 * @ORM\Entity
 */
class Quartier implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    protected $description;

    /**
     * @var integer
     *
     * @ORM\Column(name="contributeur_id", type="integer", nullable=false)
     */
    protected $contributeurId;

    /**
     * @var integer
     *
     * @ORM\Column(name="ville_id", type="integer", nullable=false)
     */
    protected $villeId;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Quartier
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    
        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Quartier
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set ville
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Ville $ville
     * @return Quartier
     */
//    public function setVille(\Koutchoumi\FrontendBundle\Entity\Ville $ville = null)
//    {
//        $this->ville = $ville;
//    
//        return $this;
//    }

    /**
     * Get ville
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Ville 
     */
//    public function getVille()
//    {
//        return $this->ville;
//    }

    /**
     * Set contributeur
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Contributeur $contributeur
     * @return Quartier
     */
    public function setContributeurId($contributeurId)
    {
        $this->contributeurId = $contributeurId;
    
        return $this;
    }

    /**
     * Get contributeur
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Contributeur 
     */
    public function getContributeurId()
    {
        return $this->contributeurId;
    }
    
    public function save()
    {
        $em=$this->get('doctrine')->getManager();
        $em->persist($this);
        $em->flush();
        //parent::save($con);
    }
    
    /**
     * Get villeId
     *
     * @return integer 
     */
    public function getVilleId()
    {
        return $this->villeId;
    }

    /**
     * Set villeId
     *
     * @param string $villeId
     * @return Quartier
     */
    public function setVilleId($villeId)
    {
        $this->villeId = $villeId;
    
        return $this;
    }
    
    public static function getQuartier($quartierId) {
        //Mettre un try catch
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:Quartier')->find($quartierId);
    }
    
    /**
     * Retourne le nombre de photos d'un quartier
     * @return int Le nombre de photos du quartier
     */
    public function countPhotoQuartiers(Criteria $c)
    {
        return $this->getDoctrine()->getManager()->createQueryBuilder()
                ->select('count(ph.*)')
                ->from('KoutchoumiFrontendBundle:Photo','ph')
                ->innerJoin('KoutchoumiFrontendBundle:Quartier','q', 'WITH', 'ph.quartier_id=:photo_quartier')
                ->setParameter('photo_quartier', $this->id)
                ->getQuery()
                ->getResult();
    }

    /*
     * Retourne les photos du bien immobilier courant. 
     * @Return array (Photo)
     */
    public function  getPhotosQuartier(Criteria $c){
        $result= $this->getDoctrine()->getManager()->createQueryBuilder()
                ->select('ph.*')
                ->from('KoutchoumiFrontendBundle:Photo','ph')
                ->innerJoin('KoutchoumiFrontendBundle:BienImmobilier','bi', 'WITH', 'ph.bien_immobilier_id=:photo_bien_immo')
                ->setParameter('photo_bien_immo', $this->id)
                ->getQuery()
                ->getResult();
        return new Collections\ArrayCollection($result);
    }

    public function serialize() {
        return serialize(array(
                    'id' => $this->id,
                    'nom' => $this->nom,
            'contributeurId' => $this->contributeurId,
            'description' => $this->description,
            'villeId' => $this->villeId,
                )
        );
    }

    public function unserialize($serialized) {
        $array = unserialize($serialized);

        $this->id = $array['id'];
        $this->nom = $array['nom'];
        $this->contributeurId = $array['contributeurId'];
        $this->description = $array['description'];
        $this->villeId = $array['villeId'];
    }

    public function __toString(){
        return (string)$this->nom;
    }
}