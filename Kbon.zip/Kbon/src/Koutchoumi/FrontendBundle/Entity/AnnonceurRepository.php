<?php
/**
 * Description of AnnonceurRepository
 *
 * @author J
 */
namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class AnnonceurRepository extends EntityRepository implements UserProviderInterface{
    //put your code here
    public function loadUserByUsername($username) {
        
    }
    public function refreshUser(UserInterface $user) {
        
    }
    public function supportsClass($class) {
        
    }
}

?>
