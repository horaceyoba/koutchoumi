<?php
/**
 *Représente une instance d'un BienImmobilier de type appartement
 */
namespace Koutchoumi\FrontendBundle\Entity; 

class Appartement extends BienImmobilier {

	/**
	 * Constructs a new Appartement class, setting the class_key column to BienImmobilierPeer::CLASSKEY_AP.
	 */
        private $translator;
        public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_APPARTEMENT);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Appartement");
        }

        /**
         * @return Description en français dans le texte de l'appart.
         * Exple: Appartement à louer - <VILLE>, <Quartier>, <secteur> - 1 salon(s), 2 chambres(s), 1 salle(s) de bains - 60 000 FCFA / mois
         */
        public function getDescription()
        {
            $des = Appartement::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains())).
                    " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA / ' . $this->translator->trans('mois');

            return $des;
        }

        public function getShortDescription()
        {
            $shortDes = Appartement::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains())).
                    " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA / ' . $this->translator->trans('mois');

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = Appartement::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
                    $this->getVille()->getNom(). ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->translator->trans('%1% salon(s)', array('%1%' => $this->getNombreSalons())).
                    ", " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres())).
                    ", " . $this->translator->trans('%1% salle(s) de bains', array('%1%' => $this->getNombreSallesDeBains()));

            return $shortDes;            
        }

        /**
         * Appartement à louer à Douala, Logpom - 1 chambre - 70 000 FCFA
         */
        public function getTitle()
        {
            $title = Appartement::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . $this->translator->trans('%1% chambre(s)', array('%1%' => $this->getNombreChambres()));
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }
}
