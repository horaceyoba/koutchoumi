<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BienManager
 *
 * @author pattchen, J
 */

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Common\Collections\ArrayCollection;
use \Symfony\Bundle\FrameworkBundle\Routing\Router;
use \Symfony\Bundle\FrameworkBundle\Translation\Translator;
use \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle;

class BienManager {

    private $router;
    private $translator;

    public function __construct(Router $router, Translator $translator) {
        $this->router = $router;
        $this->translator = $translator;
//        $this->router=$this->get('koutchoumi_frontend.router');
    }

//    public function __construct(){
//        
//    }
    protected static function setDefaultInfos(BienImmobilier $bien) {
        //Le bien est au statut publié
        $bien->setStatut(1);
        // Le nombre de hits est à 0
        $bien->setNombreHits(0);
        //Date de publication =  date d'enregistrement du bien
        $publicationDate = date('Y-m-d H:i:s');
        $bien->setDatePublication($publicationDate);
        $bien->setReferenceBienReferentielAnnonceur("");

        //Date expiration = date de publication + durée validité
        $expiryDate = time() + 86400 * \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days');
        $bien->setDateExpiration(date('Y-m-d', $expiryDate));

//        $date = new \DateTime("2006-12-12");
//        $date->modify("+7 day");
//        echo $date->format("Y-m-d");

        // TODO: lorsqu'on est en mode update, cette requête récupère uniquement les records reliés déjà en base et fait fi des records ajoutés
        // et non encore persistés
        // Comment récupérer uniquement les records liés transients ?
        $biensFils = $bien->getBienImmobiliersRelatedByBlocBienId();
        if ($biensFils != NULL) {
            foreach ($biensFils as $bienSimple) {
                $bienSimple->setStatut(1);
                $bienSimple->setNombreHits(0);
//                $bienSimple->setDatePublication($publicationDate);
//                $bienSimple->setDateExpiration($expiryDate);
            }
        }
        return $bien;
    }

    protected static function updateReferenceBien(BienImmobilier $bien) {
        $idBien = $bien->getId();
        //Définition de la référence, à partir de l'ID
        $ref = ReferenceData::generateReferenceBien($idBien);
        $bien->setReference($ref);
        /*
         * En tenir compte ensuite
         *
          $biensFils = $bien->getBienImmobiliersRelatedByBlocBienId();
          if ($biensFils != NULL) {
          foreach ($biensFils as $bienSimple) {
          $ref = ReferenceData::generateReferenceBien($bienSimple->getId());
          $bienSimple->setReference($ref);
          }
          }
         */
        return $bien;
    }

    /**
     *
     * @param BienImmobilier $bien Enregistre un bien dans la base et fixe sa date d'expiration
     */
    public static function enregistrerBien($bien) {
//        try {
        /*
          //Le bien est au statut publié
          $bien->setStatut(1);

          // Le nombre de hits est à 0
          $bien->setNombreHits(0);

          //Date de publication =  date d'enregistrement du bien
          $publicationDate = time();
          $bien->setDatePublication($publicationDate);

          //Date expiration = date de publication + durée validité
          $expiryDate = $publicationDate + 86400 * sfConfig::get('app_bienimmo_active_days');
          $bien->setDateExpiration($expiryDate);
         *
         */
//                die(var_dump($bien));
        $bien = self::setDefaultInfos($bien);

        //Enregistrement du bien, sans la référence Koutchoumi
//        die(var_dump($bien));
        BienImmobilier::save($bien);

        //Définition de la référence koutchoumi
        $bien = self::updateReferenceBien($bien);

        //Sauvegarde de la référence
        BienImmobilier::save($bien);

        return $bien->getId();
//        }
//        catch (Exception $exc) {
//            throw new KoutchoumiException($exc->getMessage());
//        }
    }

    /**
     *
     * @param BienImmobilier $bien Met à jour les infos d'un bien
     */
    public static function updateBien($bien) {
        try {
            BienImmobilier::save($bien);
            return $bien->getId();
        } catch (Exception $exc) {
            throw new KoutchoumiException($exc->getMessage());
        }
    }

    /**
     * Querybuilder de base à utiliser par les méthodes de récupération de biens.
     * @Param
     * @return QueryBuider le query builder en question.
     */
    public static function getBiensQueryBuilder() {
        $qb = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder();
        $qb->select('bi')
                ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                ->where('1=1');
        return $qb;
    }

    /**
     * Liste les annonces publiés par un agent immobilier triés par ordre de publication décroissant
     * @param <type> $annonceurId Id de l'annonceur dont on veut lister les biens
     * @return array Tableau contenant toutes les annonces de l'annonceur passé en paramètre
     */
    public static function listerBiensParAnnonceur($annonceurId, $querybuilder) {
        $qb = NULL;
        if ($querybuilder == NULL) {
            $qb = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                    ->select('bi')
                    ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                    ->where('1=1');
        } else {
            $qb = clone $querybuilder;
        }
        $qb->andWhere('bi.' . BienImmobilier::ANNONCEUR_ID . '=' . $annonceurId);
//        try {
        return $qb->getQuery()
                        ->getResult();
//        } catch (PropelException $e) {
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    /**
     * Retourne les biens disponibles remplissant la condition criteria ou tous les biens disponibles si aucun critère n'est fourni.
     * @param QueryBuilder $qb contenant les critères de recherche des biens
     * @return array Tableau des biens immobiliers disponibles satisfaisant la condition criteria ou tous les biens disponibles si criteria = NULL
     */
    public static function trouverBien(QueryBuilder $qb) {
        $querybuilder = self::getActiveBiensCriteria($qb);
//        try {
//            $arrayresult = ReferenceData::getBiensImmobiliers();
//            $unfilteredResults = new ArrayCollection($arrayresult) ;  
//            $results = $unfilteredResults->matching($c);
        $results = $querybuilder->getQuery()->getResult();
        return $results;
//        }
//        catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    public static function getBien($idBien) {
        //try{
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->getRepository('KoutchoumiFrontendBundle:BienImmobilier')->find($idBien);
        //} catch (PropelException $e) {
        //  throw new KoutchoumiException($e->getMessage());
        //}
    }

    /**
     * Retourne le nombre de biens remplissant la condition criteria ou tous les biens si aucun critère n'est fourni.
     * @param QueryBuilder $qb QueryBuilder contenant les critères de recherche des biens
     * @return int nombre de biens remplissant la condition criteria ou tous les biens si le paramètre criteria==NULL.
     */
    public static function compterBien(QueryBuilder $qb = NULL) {
        if ($qb == NULL) {
            $qb = self::getBiensQueryBuilder();
        }
//        try {
        $arrayresult = $qb->getQuery()->getResult();
        $result = new ArrayCollection($arrayresult);
        $rescount = count($result);
        //$result = BienImmobilierPeer::doCount($criteria);
        return $rescount;
//        }
//        catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    /**
     * Retourne le nombre de biens d'un type donné remplissant la condition criteria ou tous les biens si aucun critère n'est fourni.
     * @param QueryBuilder $qb QueryBuilder contenant les critères de recherche des biens
     * @param Integer $typeBien Type de bien (Donné par les constantes ReferenceData::TYPE_BIEN_...).
     * @param Integer $typeTransaction Type de tyransaction (location, vente). Donné par les constantes ReferenceData::TYPE_TRANSACTION...
     * @return Integer nombre de biens de type $typeBien remplissant la condition criteria ou tous les biens si les paramètres ne sont pas renseignés.
     */
    public static function compterBiensDisponibles($typeBien = NULL, $typeTransaction = NULL, QueryBuilder $qb = NULL) {
        $querybuilder = self::getActiveBiensCriteria($qb);
        if ($typeBien != NULL) {
            $querybuilder->andWhere('bi.classKey=:ck');
            switch ($typeBien) {
                case ReferenceData::TYPE_BIEN_STUDIO:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_STUDIO);
                    break;
                case ReferenceData::TYPE_BIEN_APPARTEMENT:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_APPARTEMENT);
                    break;
                case ReferenceData::TYPE_BIEN_MAISON:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_MAISON);
                    break;
                case ReferenceData::TYPE_BIEN_TERRAIN:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_TERRAIN);
                    break;
                case ReferenceData::TYPE_BIEN_BLOC_TERRAIN:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_BLOCTERRAIN);
                    break;
                case ReferenceData::TYPE_BIEN_MAGASIN:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_MAGASIN);
                    break;
                case ReferenceData::TYPE_BIEN_BOUTIQUE:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_BOUTIQUE);
                    break;
                case ReferenceData::TYPE_BIEN_ENTREPOT:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_ENTREPOT);
                    break;
                case ReferenceData::TYPE_BIEN_BUREAU:
                    $querybuilder->setParameter('ck', BienImmobilier::CLASSKEY_BUREAU);
                    break;
                default:
                    // Si une valeur non conforme est fournie, on ne renvoie rien.
                    $querybuilder->setParameter('ck', "-1");
            }
        }
        if ($typeTransaction != NULL) {
            $querybuilder->andWhere('bi.typeTransaction=:tTrans');
            switch ($typeTransaction) {
                case ReferenceData::TYPE_TRANSACTION_LOCATION:
                    $querybuilder->setParameter('tTrans', ReferenceData::TYPE_TRANSACTION_LOCATION);
                    break;
                case ReferenceData::TYPE_TRANSACTION_VENTE:
                    $querybuilder->setParameter('tTrans', ReferenceData::TYPE_TRANSACTION_VENTE);
                    break;
                default:
                    // Si une valeur non conforme est fournie, on ne renvoie rien.
                    $querybuilder->setParameter('tTrans', "-1");
            }
        }

//        try {
//            $arrayresult = ReferenceData::getBiensImmobiliers()->matching($criteria)->count();
        $arrayresult = $querybuilder->getQuery()->getResult();
        $rescount = count(new ArrayCollection($arrayresult));
//         $list = $result = ReferenceData::getBiensImmobiliers();
        // print_r($arrayresult);
//            var_dump($result->matching($criteria));
//            var_dump($rescount);
//            var_dump($querybuilder->getQuery());
//          die();
//            die('test');
        return $rescount;
//        }
//        catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    /**
     *
     * @param Criteria $criteria
     * @return Criteria
     */
    public static function getActiveBiensCriteria(QueryBuilder $qb = NULL) {
        $querybuilder = NULL;
        if ($qb == NULL) {
            $querybuilder = self::getBiensQueryBuilder();
        } else {
            $querybuilder = clone $qb;
            var_dump('Cloned criteria');
        }
        // On ne prend que les biens toujours à l'état publié...
        $querybuilder->andWhere('bi.statut=1');
        //...et n'ayant pas encore expiré
        $querybuilder->andWhere('bi.dateExpiration<=:dateExp') //Penser à mettre >
//                ->setParameter('dateExp',date('Y-m-d'));
                ->setParameter('dateExp', time());
//        $c->add(BienImmobilierPeer::DATE_EXPIRATION, time(), Criteria::GREATER_THAN);
//        echo (date('Y-m-d'));

        return $querybuilder;
    }

    /**
     * Incrémente le nombre de hits d'un bien
     * @param int $idBien  Id du bien dont on veut incrémenter le nombre de hits
     */
    public static function incrementerHitsBien($idBien) {
        //TODO gérer les accès concurrents
        /*
          $bienImmo = BienImmobilierPeer::retrieveByPK($idBien);
          $bienImmo->setNombreHits($bienImmo->getNombreHits() + 1);
          try{
          $bienImmo->save();
          } catch(PropelException $e){
          throw new KoutchoumiException($e->getMessage());
          }

         */
        //$nombreHitsCourant =
        //Update Bien_Immobilier set nombre_hits = nombre_hits+1 WHERE id=<idbien>
//        $connection = Propel::getConnection();
//        $updateQuery = 'UPDATE %s SET %s = %s+1 WHERE %s = %d';
//        $updateQuery = sprintf($updateQuery,
//                        BienImmobilierPeer::TABLE_NAME,
//                        BienImmobilierPeer::NOMBRE_HITS,
//                        BienImmobilierPeer::NOMBRE_HITS,
//                        BienImmobilierPeer::ID,
//                        $idBien
//                       );
//       $statement = $connection->prepare($updateQuery);
//       $statement->execute();

        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $bien_immo = $em->getRepository('KoutchoumiFrontendBundle:BienImmobilier')->find($idBien);
        $currentNombreHits = $bien_immo->getNombreHits();
        $bien_immo->setNombreHits($currentNombreHits + 1);
    }

    /**
     * Renvoie des biens disponibles similaires à un bien donné
     * @param BienImmobilier $bien Bien pour lequel on veut trouver des biesn similaires
     * @param <type> $nombreBiensSimilaires  Nombre de biens similaires à retourner.Si ce critère n'est pas précisé, on renvoie tous les biens.
     * @return array Tableau de biens similaires au bien passé en paramètre. Les biens sont triés par ordre croissant de prix.
     */
    public static function getBiensSimilaires(BienImmobilier $bien, $nombreBiensSimilaires) {
        // On ne s'intéresse qu'aux biens disponibles
        $qbBiensSimilaires = self::getActiveBiensCriteria();
        //On ne va pas lister le bien lui-même
        $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::ID . '!=:bid')
                ->setParameter('bid', $bien->getId());
        // Même ville
        $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::VILLE_ID . '=:bville')
                ->setParameter('bville', $bien->getVilleId());
        // Même type de transaction (à louer ou à vendre)
        $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::TYPE_TRANSACTION . '=:btTrans')
                ->setParameter('btTrans', $bien->getTypeTransaction());
        // Critères dépendant du type du bien
        $prix = $bien->getPrix();
        $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::CLASS_KEY . '=:ck');
//        $a = new BienImmobilier();
//        $b = new BienImmobilier();
//        $c = 'BienImmobilier';
//        $d = 'NotMyClass';
//        die($a instanceof $b);
        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_APPARTEMENT) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_APPARTEMENT);
            // Nombre de chambres
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::NOMBRE_CHAMBRES . '=:nch')
                    ->setParameter('nch', $bien->getNombreChambres());
            // Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000 && $prix <= 100000) {
                $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
            }
            if ($prix > 100000 && $prix <= 200000) {
                $qbBiensSimilaires->setParameter('bprix', 25000 + $prix);
            }
            if ($prix > 200000 && $prix <= 500000) {
                $qbBiensSimilaires->setParameter('bprix', 50000 + $prix);
            }
            if ($prix > 500000) {
                $qbBiensSimilaires->setParameter('bprix', 100000 + $prix);
            }
            // Parking
            if ($bien->getAvecParkings()) {
                $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::AVEC_PARKINGS . '=:avPk');
                $qbBiensSimilaires->setParameter('avPk', $bien->getAvecParkings());
            }
        }
        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_STUDIO) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_STUDIO);
            //Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 20000) {
                $qbBiensSimilaires->setParameter('bprix', 2000 + $prix);
            }
            if ($prix > 20000 && $prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000) {
                $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
            }
        }
        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_MAISON) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_MAISON);
            //Nombre de chambres
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::NOMBRE_CHAMBRES . '=:nch')
                    ->setParameter('nch', $bien->getNombreChambres());
            //Le prix est un critère de similarité pour la maison si c'est une location
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($bien->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_LOCATION) {
                if ($prix <= 50000) {
                    $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
                }
                if ($prix > 50000 && $prix <= 100000) {
                    $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
                }
                if ($prix > 100000 && $prix <= 200000) {
                    $qbBiensSimilaires->setParameter('bprix', 25000 + $prix);
                }
                if ($prix > 200000 && $prix <= 500000) {
                    $qbBiensSimilaires->setParameter('bprix', 50000 + $prix);
                }
                if ($prix > 500000) {
                    $qbBiensSimilaires->setParameter('bprix', 100000 + $prix);
                }
            }
        }
        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_TERRAIN) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_TERRAIN);
            //Surface
            $surface = $bien->getSurface();
            //Le prix du m2 est un critère si le terrain est à vendre
            if ($bien->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_VENTE) {
                $prixDuMetreCarre = $prix / $surface;
                $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '/' . 'bi.' . BienImmobilier::SURFACE . '<=:bprix');
                if ($prixDuMetreCarre <= 20000) {
                    $prixMax = 1000 + $prixDuMetreCarre;
//                    $criteriaBiensSimilaires->add(BienImmobilierPeer::PRIX, BienImmobilierPeer::PRIX.'/'.BienImmobilierPeer::SURFACE.'<='.$prixMax, Criteria::CUSTOM);
                }
                if ($prixDuMetreCarre > 20000 && $prixDuMetreCarre <= 50000) {
                    $prixMax = 2000 + $prixDuMetreCarre;
                }
                if ($prixDuMetreCarre > 50000 && $prixDuMetreCarre <= 100000) {
                    $prixMax = 5000 + $prixDuMetreCarre;
                }
                if ($prixDuMetreCarre > 100000) {
                    $prixMax = 10000 + $prixDuMetreCarre;
                }
                $qbBiensSimilaires->setParameter('bprix', $prixMax);
            }
        }

        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_BLOCTERRAIN) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_BLOCTERRAIN);
            //Surface
            $surface = $bien->getSurface();
            //Le prix du m2 est un critère si le bloc de terrain est à vendre
            if ($bien->getTypeTransaction() == ReferenceData::TYPE_TRANSACTION_VENTE) {
                $prixDuMetreCarre = $prix / $surface;
                $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '/' . 'bi.' . BienImmobilier::SURFACE . '<=:bprix');
                if ($prixDuMetreCarre <= 20000) {
                    $prixMax = 1000 + $prixDuMetreCarre;
                }
                if ($prixDuMetreCarre > 20000 && $prixDuMetreCarre <= 50000) {
                    $prixMax = 2000 + $prixDuMetreCarre;
                }
                if ($prixDuMetreCarre > 50000 && $prixDuMetreCarre <= 100000) {
                    $prixMax = 5000 + $prixDuMetreCarre;
                }
                if ($prixDuMetreCarre > 100000) {
                    $prixMax = 10000 + $prixDuMetreCarre;
                }
                $qbBiensSimilaires->setParameter('bprix', $prixMax);
            }
        }

        //Surface
        $surface = $bien->getSurface();

        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_MAGASIN) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_MAGASIN);
            // Nombre de pièces
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::NOMBRE_PIECES . '=:npi')
                    ->setParameter('npi', $bien->getNombrePieces());
            // Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000 && $prix <= 100000) {
                $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
            }
            if ($prix > 100000 && $prix <= 200000) {
                $qbBiensSimilaires->setParameter('bprix', 25000 + $prix);
            }
            if ($prix > 200000 && $prix <= 500000) {
                $qbBiensSimilaires->setParameter('bprix', 50000 + $prix);
            }
            if ($prix > 500000) {
                $qbBiensSimilaires->setParameter('bprix', 100000 + $prix);
            }
            // Surface
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surf')
                    ->setParameter('surf', 100 + $surface);
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surf')
                    ->setParameter('surf', $surface - 100);
        }

        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_ENTREPOT) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_ENTREPOT);
            // Nombre de pièces
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::NOMBRE_PIECES . '=:npi')
                    ->setParameter('npi', $bien->getNombrePieces());
            // Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000 && $prix <= 100000) {
                $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
            }
            if ($prix > 100000 && $prix <= 200000) {
                $qbBiensSimilaires->setParameter('bprix', 25000 + $prix);
            }
            if ($prix > 200000 && $prix <= 500000) {
                $qbBiensSimilaires->setParameter('bprix', 50000 + $prix);
            }
            if ($prix > 500000) {
                $qbBiensSimilaires->setParameter('bprix', 100000 + $prix);
            }
            // Surface
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surf')
                    ->setParameter('surf', 200 + $surface);
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surf')
                    ->setParameter('surf', $surface - 200);
        }

        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_BOUTIQUE) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_BOUTIQUE);
            // Nombre de pièces
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::NOMBRE_PIECES . '=:npi')
                    ->setParameter('npi', $bien->getNombrePieces());
            // Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000 && $prix <= 100000) {
                $qbBiensSimilaires->setParameter('bprix', 10000 + $prix);
            }
            if ($prix > 100000 && $prix <= 200000) {
                $qbBiensSimilaires->setParameter('bprix', 25000 + $prix);
            }
            if ($prix > 200000 && $prix <= 500000) {
                $qbBiensSimilaires->setParameter('bprix', 50000 + $prix);
            }
            if ($prix > 500000) {
                $qbBiensSimilaires->setParameter('bprix', 100000 + $prix);
            }
            // Surface
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surf')
                    ->setParameter('surf', 10 + $surface);
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surf')
                    ->setParameter('surf', $surface - 10);
        }

        if ($bien->getClassKey() == BienImmobilier::CLASSKEY_BUREAU) {
            //Type de bien
            $qbBiensSimilaires->setParameter('ck', BienImmobilier::CLASSKEY_BUREAU);

            // Prix
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::PRIX . '<=:bprix');
            if ($prix <= 50000) {
                $qbBiensSimilaires->setParameter('bprix', 5000 + $prix);
            }
            if ($prix > 50000 && $prix <= 100000) {
                $qbBiensSimilaires->setParameter('bprix', 20000 + $prix);
            }
            if ($prix > 100000 && $prix <= 200000) {
                $qbBiensSimilaires->setParameter('bprix', 40000 + $prix);
            }
            if ($prix > 200000 && $prix <= 500000) {
                $qbBiensSimilaires->setParameter('bprix', 80000 + $prix);
            }
            if ($prix > 500000) {
                $qbBiensSimilaires->setParameter('bprix', 150000 + $prix);
            }
            // Surface
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '<=:surf')
                    ->setParameter('surf', 30 + $surface);
            $qbBiensSimilaires->andWhere('bi.' . BienImmobilier::SURFACE . '>=:surf')
                    ->setParameter('surf', $surface - 30);
        }


        // On trie par ordre croissant de prix
        $qbBiensSimilaires->orderBy('bi.prix', 'ASC');
        //$criteriaBiensSimilaires->addAscendingOrderByColumn(BienImmobilierPeer::PRIX);
        // Eventuellement, on limite le nombre de résultats retournés
        if ($nombreBiensSimilaires != NULL) {
            $qbBiensSimilaires->setMaxResults($nombreBiensSimilaires);
        }

        // On sélectionne les biens similaires à partir des critères définis ci-dessus
//        try {
        $arrayresult = $qbBiensSimilaires->getQuery()->getResult();
        $result = new ArrayCollection($arrayresult);
        //           var_dump($result);
        //           echo('nombre:');
        //           var_dump(count($result));
//            $results = ReferenceData::getBiensImmobiliers()->matching($criteriaBiensSimilaires);
        return $result;
//        }
//        catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    /**
     * Génère l'URL de la vue d'ensemble d'un bien en utilisant la régle de routing "vue_ensemble_bien"
     * @param BienImmobilier $bienImmo Bien immobilier pour lequel on veut générer la vue d'ensemble
     * @return string URL de la vue d'ensemble du bien
     */
    public static function generateURLForBienImmobilier($bienImmo) {
        // Paramètres de l'URL
        $typeBien = str_replace(" ", "-", strtolower(ReferenceData::getLibelleTypeBien($bienImmo->getClassKey())));
        $typeTransaction = str_replace("à", "a", ReferenceData::getTypeLibelleTransaction($bienImmo->getTypeTransaction()));
        $typeTransaction = str_replace(" ", "-", $typeTransaction);
        $ville = str_replace("é", "e", $bienImmo->getVille()->getNom());
        $ville = strtolower($ville);
        $quartier = str_replace("é", "e", $bienImmo->getQuartier()->getNom());
        $quartier = str_replace("è", "e", $quartier);
        $quartier = str_replace("ê", "e", $quartier);
        $quartier = str_replace("à", "a", $quartier);
        $quartier = str_replace(" ", "-", $quartier);
        $quartier = str_replace("'", "-", $quartier);
        $quartier = strtolower($quartier);
        $surface = ($bienImmo->getSurface() == NULL ? "" : $bienImmo->getSurface()) . "-m2";
        $nombreChambres = ($bienImmo->getNombreChambres() == NULL ? "" : $bienImmo->getNombreChambres()) . "-chambres";
        $urlParams = array(
            'typeBien' => $typeBien,
            'typeTransaction' => $typeTransaction,
            'ville' => $ville,
            'quartier' => $quartier,
            'prix' => number_format($bienImmo->getPrix(), 0, '.', '') . "-fcfa",
            'surface' => $surface,
            'nombreChambres' => $nombreChambres,
            'idBien' => $bienImmo->getId()
        );
        // Génération de l'URL
//        $frontendRouting = new sfPatternRouting(new sfEventDispatcher());
//        $config = new sfRoutingConfigHandler();
//        $routes = $config->evaluate(array(sfConfig::get('sf_apps_dir').'/frontend/config/routing.yml'));
//        $frontendRouting->setRoutes($routes);
//        $urlBien = "http://www.koutchoumi.com". $frontendRouting->generate('vue_ensemble_bien', $urlParams, true);
        //Faire que cette classe hérite de Controller ou créer une petite classe qui héritera de Controller et fera le même travail. 
        //Voir aussi comment cette classe est utilisée ensuite dans le Controller. Le travail peut être délégué.
        //$router=$this->get('router'); 
        //Désormais BienManager est un service. 
        $urlBien = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('router')->generate('vue_ensemble_bien', $urlParams, true);

        //Autre option si la classe devient un Controller
        //$urlBien="http://www.koutchoumi.com".$this->generateUrl('vue_ensemble_bien', $urlParams);

        return $urlBien;
    }

    public static function generateURLForBienImmobilierI18n($bienImmo, $locale) {
        // Paramètres de l'URL
        $typeBien = ReferenceData::getLibelleTypeBien($bienImmo->getClassKey());
        if ($bienImmo->getClassKey() == BienImmobilier::CLASSKEY_ENTREPOT) {
//            $typeBien = sfContext::getInstance()->getI18N()->__("Entrepot");
            $typeBien = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("Entrepôt");
        }
        $typeBien = strtolower(str_replace(" ", "-", $typeBien));
        $typeTransaction = str_replace("à", "a", ReferenceData::getTypeLibelleTransaction($bienImmo->getTypeTransaction()));
        $typeTransaction = str_replace(" ", "-", $typeTransaction);
        $ville = str_replace("é", "e", $bienImmo->getVille()->getNom());
        $ville = strtolower($ville);
        $quartier = str_replace("é", "e", $bienImmo->getQuartier()->getNom());
        $quartier = str_replace("è", "e", $quartier);
        $quartier = str_replace("ê", "e", $quartier);
        $quartier = str_replace("à", "a", $quartier);
        $quartier = preg_replace('/\W+/', '-', $quartier);
        $quartier = strtolower($quartier);
        $prix = number_format($bienImmo->getPrix(), 0, '.', '') . "-fcfa";

        $route = "vue_ensemble_bien_i18n";
        $urlParams = array(
            'typeBien' => $typeBien,
            'typeTransaction' => $typeTransaction,
            'ville' => $ville,
            'quartier' => $quartier,
            'prix' => $prix,
            'idBien' => $bienImmo->getId()//,
//            'sf_culture' => $locale
        );

        switch ($bienImmo->getClassKey()) {
            case BienImmobilier::CLASSKEY_STUDIO:
                $route = "vue_ensemble_chambre";
                break;
            case BienImmobilier::CLASSKEY_APPARTEMENT:
                $urlParams['nombreChambres'] = $bienImmo->getNombreChambres() . "-" . \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('chambres');
                $route = "vue_ensemble_appartement";
                break;
            case BienImmobilier::CLASSKEY_MAISON:
                $urlParams['nombreChambres'] = $bienImmo->getNombreChambres() . "-" . \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans('chambres');
                $typeMaison = $bienImmo->getTypeMaison()->getLibelle();
                $typeMaison = str_replace("é", "e", $typeMaison);
                $typeMaison = str_replace("è", "e", $typeMaison);
                $typeMaison = str_replace("ê", "e", $typeMaison);
                $typeMaison = str_replace("à", "a", $typeMaison);
                $typeMaison = preg_replace('/\W+/', '-', $typeMaison);
                $typeMaison = strtolower($typeMaison);
                $urlParams['typeMaison'] = $typeMaison;
                $route = "vue_ensemble_maison";
                break;
            case BienImmobilier::CLASSKEY_TERRAIN:
                $urlParams['surface'] = $bienImmo->getSurface() . "-m2";
                $route = "vue_ensemble_terrain";
                break;
            case BienImmobilier::CLASSKEY_BLOCTERRAIN:
                $urlParams['surface'] = $bienImmo->getSurface() . "-m2";
                $prixDuMetreCarre = number_format($bienImmo->getPrix() / $bienImmo->getSurface(), 0, '.', ' ');
                $urlParams['prix'] = $prixDuMetreCarre . "-fcfa-le-m2";
                $route = "vue_ensemble_bloc_terrain";
                break;
            case BienImmobilier::CLASSKEY_BOUTIQUE:
                $urlParams['surface'] = $bienImmo->getSurface() . "-m2";
                $route = "vue_ensemble_boutique";
                break;
            case BienImmobilier::CLASSKEY_MAGASIN:
                $urlParams['surface'] = $bienImmo->getSurface() . "-m2";
                $route = "vue_ensemble_magasin";
                break;
            case BienImmobilier::CLASSKEY_ENTREPOT:
                $urlParams['surface'] = $bienImmo->getSurface() . "-m2";
                $route = "vue_ensemble_entrepot";
                break;
            case BienImmobilier::CLASSKEY_BUREAU:
                $urlParams['nombrePieces'] = $bienImmo->getNombrePieces() . "-" . \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator')->trans("pieces");
                $route = "vue_ensemble_bureau";
                break;
            default:
                $route = "vue_ensemble_bien_i18n";
                break;
        }

        // Génération de l'URL
//        $frontendRouting = new sfPatternRouting(new sfEventDispatcher());
//        $config = new sfRoutingConfigHandler();
//        $routes = $config->evaluate(array(sfConfig::get('sf_apps_dir').'/frontend/config/routing.yml'));
//        $frontendRouting->setRoutes($routes);
        $urlBien = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('router')->generate($route, $urlParams, true);

        return $urlBien;
    }

    /**
     * Retourne la description d'un colonne de la table Bien_Immobilier
     * @param string $completeColumnName nom de colonne préfixé par Bien_Immobilier. Exemple: Bien_Immobilier.PRIX
     * @return string Description de la colonne
     */
    public static function getColumnDescription($completeColumnName) {
        /*
          typeBien
          typeTransaction
          villeId
          prixMin
          prixMax
          surfaceMin
          surfaceMax
          nombreChambres
          quartierId
          minSDB
          maxSDB
          avecParing
          avecBarriere
          typeMaisonId;
          situationSalleDeBains
          situationToilettes
          titre;
          etat
          avec douche
         */
        switch ($completeColumnName) {
            case BienImmobilier::CLASS_KEY: return "Type de bien";
            case BienImmobilier::TYPE_TRANSACTION: return "Type de transaction";
            case BienImmobilier::VILLE_ID: return "Ville";
            case BienImmobilier::PRIX: return "Prix";
            case BienImmobilier::SURFACE: return "Surface";
            case BienImmobilier::NOMBRE_CHAMBRES: return "Nombre de chambres";
            case BienImmobilier::QUARTIER_ID: return "Quartier";
            case BienImmobilier::NOMBRE_SALLES_DE_BAINS: return "Nombre de salles de bains";
            case BienImmobilier::AVEC_PARKINGS: return "Parking";
            case BienImmobilier::AVEC_BARRIERE: return "Barrière";
            case BienImmobilier::TYPE_MAISON_ID: return "Style de maison";
            case BienImmobilier::SITUATION_SALLE_DE_BAINS: return "Situation salle de bains";
            case BienImmobilier::SITUATION_TOILETTES: return "Situation toilettes";
            case BienImmobilier::TITRE: return "Titré";
            case BienImmobilier::ETAT: return "Etat";
            case BienImmobilier::AVEC_DOUCHE: return "Avec douche";
        }
    }

    public static function prolongerValiditeBien($idBien) {
        //Date expiration = now + durée validité
        $newExpiryDate = time() + 86400 * \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('app_bienimmo_active_days');
//        try{
        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $bien = $em->getRepository('KoutchoumiFrontendBundle:BienImmobilier')->find($idBien);
        $bien->setDateExpiration($newExpiryDate);
        $em->flush();
        return $bien->getDateExpiration();
//        } catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    public static function retirerBien($idBien) {
//        try{
        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $bien = $em->getRepository('KoutchoumiFrontendBundle:BienImmobilier')->find($idBien);
        $bien->setStatut(0);
        $em->flush();
//        } catch(PropelException $e){
//            throw new KoutchoumiException($e->getMessage());
//        }
    }

    public static function definirDureeValiditeBien($bien) {
        $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days');
        switch ($bien->getTypeTransaction()) {
            case ReferenceData::TYPE_TRANSACTION_LOCATION:
                if ($bien instanceof Maison) {
                    $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days_maison_alouer');
                }
                if ($bien instanceof Appartement) {
                    $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days_appart_alouer');
                }
                if ($bien instanceof Terrain || $bien instanceof BlocTerrain) {
                    $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days');
                }
                break;
            case ReferenceData::TYPE_TRANSACTION_VENTE:
                if ($bien instanceof Terrain || $bien instanceof BlocTerrain) {
                    $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days_terrain');
                }
                else
                    $bienimmoActiveDays = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('active_days_bien_avendre');
                break;

            default:
        }
        return $bienimmoActiveDays;
    }

    /**
     * Return the $count latest ads pulished
     * @param int $count
     */
    public static function getLatestAds($count = 15) {

        $querybuilder = self::getBiensQueryBuilder();
        $querybuilder->setMaxResults($count);
        $querybuilder->orderBy('bi.' . BienImmobilier::DATE_PUBLICATION, 'DESC');
        $latestAds = self::trouverBien($querybuilder);
//        $c = new Criteria();
//        $c->setLimit($count);
//        $c->addDescendingOrderByColumn(BienImmobilierPeer::DATE_PUBLICATION);
//        $latestAds = self::trouverBien($c);        
        return $latestAds;
    }

}

?>
