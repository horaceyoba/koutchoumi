<?php


/**
 *Représente une instance d'un BienImmobilier de type bloc de terrain
 */
namespace Koutchoumi\FrontendBundle\Entity; 
class BlocTerrain extends BienImmobilier {

	/**
	 * Constructs a new BlocTerrain class, setting the class_key column to BienImmobilierPeer::CLASSKEY_BT.
	 */
    private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_BLOCTERRAIN);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Bloc de terrain");
        }

        /**
         * @return Description en français dans le texte du terrain.
         * exple:Terrain titré et bâti à vendre (9 000 000 FCFA) de 400 m2 à Douala/Japoma/Derrière la station TOTAL.
         */
        public function getDescription()
        {
            return $this->getShortDescription();
        }

        public function getShortDescription()
        {
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $shortDes = $this->translator->trans("Bloc de terrain". ' ' .$etatTitre) . ' ' . ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $shortDes .= ' - '.$this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->getSurface().' m2 - '. number_format($this->getPrix()/$this->getSurface(), 0, '.', ' ').' FCFA / m2';
            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $shortDes = $this->translator->trans("Bloc de terrain". ' ' .$etatTitre) . ' ' . ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $shortDes .= ' - '.$this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur(). ' - '.
                    $this->getSurface().' m2';
            return $shortDes;            
        }

        /**
         * Bloc de terrain titré à vendre à Douala, Youpwe - 2 073 m2 - 7 000 Fcfa/m2
         */
        public function getTitle()
        {
            $etatTitre = $this->getTitre() ? "titré" : "non titré";
            $title = $this->translator->trans("Bloc de terrain". " " .$etatTitre). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . $this->getSurface() . " m2";
            $title .= " - " . number_format($this->getPrix()/$this->getSurface(), 0, '.', ' ').' FCFA/m2';

            return $title;
        }

} // BlocTerrain
