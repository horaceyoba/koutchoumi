<?php

/**
 *Représente une instance d'un BienImmobilier de type bureau
 */
namespace Koutchoumi\FrontendBundle\Entity; 

class Bureau extends BienImmobilier {

	/**
	 * Constructs a new Bureau class, setting the class_key column to BienImmobilierPeer::CLASSKEY_BU.
	 */private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_BUREAU);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}
        public static function getLibelleTypeBien() {
            return $this->translator->trans("Bureau");
        }

        /**
         * @return Description en français dans le texte de l'entrepot.
         * Exple: Bureau à louer(200 000 FCFA) - Douala, Bali,Nouvelle route Bonadibong - 3000 m2
         */
        public function getDescription()
        {
            return $this->getShortDescription();
        }

        public function getShortDescription()
        {
            $shortDes = Bureau::getLibelleTypeBien() . " " . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) ." - ". $this->getVille()->getNom() . ","
                    .$this->getQuartier()->getNom() . "," . $this->getSecteur()." - ". number_format($this->getPrix(), 0, '.', ' ') . " FCFA - " .
                    $this->getSurface()." m2";

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = Bureau::getLibelleTypeBien() . " " . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) ." - ". $this->getVille()->getNom() . ","
                    .$this->getQuartier()->getNom() . "," . $this->getSecteur()." - ". $this->getSurface()." m2";

            return $shortDes;            
        }

        /**
         * Bureau à louer à Douala, Akwa I - 20 000 Fcfa
         */
        public function getTitle()
        {
            $title = Bureau::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }

} // Bureau
