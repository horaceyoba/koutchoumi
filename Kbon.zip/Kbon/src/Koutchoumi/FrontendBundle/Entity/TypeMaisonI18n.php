<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TypeMaisonI18n
 *
 * @ORM\Table(name="type_maison_i18n")
 * @ORM\Entity(repositoryClass="Koutchoumi\FrontendBundle\Entity\TypeMaisonI18nRepository")
 */
class TypeMaisonI18n
{
    /**
     * @var string
     *
     * @ORM\Column(name="culture", type="string", length=7, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $culture;

    /**
     * @var string
     *
     * @ORM\Column(name="libelle", type="string", length=255, nullable=false)
     */
    protected $libelle;

//    /**
//     * @var \TypeMaison
//     *
//     * @ORM\Id
//     * @ORM\GeneratedValue(strategy="NONE")
//     * @ORM\OneToOne(targetEntity="TypeMaison")
//     * @ORM\JoinColumns({
//     *   @ORM\JoinColumn(name="id", referencedColumnName="id")
//     * })
//     */
//    protected $id;

/**
     * @var integer
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\Column(name="id", type="integer", nullable=false)
     */
    protected $id;

    /**
     * Set culture
     *
     * @param string $culture
     * @return TypeMaisonI18n
     */
    public function setCulture($culture)
    {
        $this->culture = $culture;
    
        return $this;
    }

    /**
     * Get culture
     *
     * @return string 
     */
    public function getCulture()
    {
        return $this->culture;
    }

    /**
     * Set libelle
     *
     * @param string $libelle
     * @return TypeMaisonI18n
     */
    public function setLibelle($libelle)
    {
        $this->libelle = $libelle;
    
        return $this;
    }

    /**
     * Get libelle
     *
     * @return string 
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * Set id
     *
     * @param \Koutchoumi\FrontendBundle\Entity\TypeMaison $id
     * @return TypeMaisonI18n
     */
    public function setId(\Koutchoumi\FrontendBundle\Entity\TypeMaison $id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return \Koutchoumi\FrontendBundle\Entity\TypeMaison 
     */
    public function getId()
    {
        return $this->id;
    }
}