<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Service
 *
 * @ORM\Table(name="service")
 * @ORM\Entity
 */
class Service
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="localisation", type="string", length=255, nullable=false)
     */
    protected $localisation;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var \Quartier
     *
     * @ORM\ManyToOne(targetEntity="Quartier")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="quartier_id", referencedColumnName="id")
     * })
     */
    protected $quartier;

    /**
     * @var \TypeService
     *
     * @ORM\ManyToOne(targetEntity="TypeService")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="type_service_id", referencedColumnName="id")
     * })
     */
    protected $typeService;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Service
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    
        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set localisation
     *
     * @param string $localisation
     * @return Service
     */
    public function setLocalisation($localisation)
    {
        $this->localisation = $localisation;
    
        return $this;
    }

    /**
     * Get localisation
     *
     * @return string 
     */
    public function getLocalisation()
    {
        return $this->localisation;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Service
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return Service
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set quartier
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Quartier $quartier
     * @return Service
     */
    public function setQuartier(\Koutchoumi\FrontendBundle\Entity\Quartier $quartier = null)
    {
        $this->quartier = $quartier;
    
        return $this;
    }

    /**
     * Get quartier
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Quartier 
     */
    public function getQuartier()
    {
        return $this->quartier;
    }

    /**
     * Set typeService
     *
     * @param \Koutchoumi\FrontendBundle\Entity\TypeService $typeService
     * @return Service
     */
    public function setTypeService(\Koutchoumi\FrontendBundle\Entity\TypeService $typeService = null)
    {
        $this->typeService = $typeService;
    
        return $this;
    }

    /**
     * Get typeService
     *
     * @return \Koutchoumi\FrontendBundle\Entity\TypeService 
     */
    public function getTypeService()
    {
        return $this->typeService;
    }
}