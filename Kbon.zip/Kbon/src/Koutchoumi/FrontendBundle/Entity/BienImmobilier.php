<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\Common\Collections;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\QueryBuilder;
use \Koutchoumi\FrontendBundle;

/**
 * BienImmobilier
 *
 * @ORM\Table(name="bien_immobilier")
 * @ORM\Entity
 */
class BienImmobilier implements \Serializable {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="reference", type="string", length=20, nullable=true)
     */
    protected $reference;

    /**
     * @var string
     *
     * @ORM\Column(name="reference_metier", type="string", length=10, nullable=true)
     */
    protected $referenceMetier;

    /**
     * @var string
     *
     * @ORM\Column(name="reference_bien_referentiel_annonceur", type="string", length=255, nullable=false)
     */
    protected $referenceBienReferentielAnnonceur;

    /**
     * @var boolean
     *
     * @ORM\Column(name="statut", type="boolean", nullable=false)
     */
    protected $statut;

    /**
     * @var string
     *
     * @ORM\Column(name="date_publication", type="string", nullable=true)
     */
    protected $datePublication;

    /**
     * @var string
     *
     * @ORM\Column(name="date_expiration", type="string", nullable=true)
     */
    protected $dateExpiration;

    /**
     * @var string
     *
     * @ORM\Column(name="secteur", type="string", length=255, nullable=false)
     */
    protected $secteur;

    /**
     * @var smallint
     *
     * @ORM\Column(name="type_transaction", type="smallint", nullable=false)
     */
    protected $typeTransaction;

    /**
     * @var float
     *
     * @ORM\Column(name="prix", type="float", nullable=false)
     */
    protected $prix;

    /**
     * @var float
     *
     * @ORM\Column(name="caution", type="float", nullable=true)
     */
    protected $caution;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_mois_aavancer", type="smallint", nullable=true)
     */
    protected $nombreMoisAavancer;

    /**
     * @var float
     *
     * @ORM\Column(name="surface", type="float", nullable=true)
     */
    protected $surface;

    /**
     * @var float
     *
     * @ORM\Column(name="distance_de_la_route", type="float", nullable=true)
     */
    protected $distanceDeLaRoute;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_accessible_en_voiture", type="boolean", nullable=true)
     */
    protected $isAccessibleEnVoiture;

    /**
     * @var boolean
     *
     * @ORM\Column(name="titre", type="boolean", nullable=true)
     */
    protected $titre;

    /**
     * @var boolean
     *
     * @ORM\Column(name="bati", type="boolean", nullable=true)
     */
    protected $bati;

    /**
     * @var float
     *
     * @ORM\Column(name="surface_habitable", type="float", nullable=true)
     */
    protected $surfaceHabitable;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_pieces", type="smallint", nullable=true)
     */
    protected $nombrePieces;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_chambres", type="smallint", nullable=true)
     */
    protected $nombreChambres;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_salons", type="smallint", nullable=true)
     */
    protected $nombreSalons;

    /**
     * @var string
     *
     * @ORM\Column(name="autres_infos_sur_chambres", type="text", nullable=true)
     */
    protected $autresInfosSurChambres;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_meuble", type="boolean", nullable=true)
     */
    protected $isMeuble;

    /**
     * @var string
     *
     * @ORM\Column(name="mobilier_disponible", type="text", nullable=true)
     */
    protected $mobilierDisponible;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_salles_de_bains", type="smallint", nullable=true)
     */
    protected $nombreSallesDeBains;

    /**
     * @var string
     *
     * @ORM\Column(name="autres_infos_salles_de_bains", type="text", nullable=true)
     */
    protected $autresInfosSallesDeBains;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_cuisines", type="smallint", nullable=true)
     */
    protected $nombreCuisines;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_balcon", type="boolean", nullable=true)
     */
    protected $avecBalcon;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_parkings", type="boolean", nullable=true)
     */
    protected $avecParkings;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_places_parking", type="smallint", nullable=true)
     */
    protected $nombrePlacesParking;

    /**
     * @var smallint
     *
     * @ORM\Column(name="situe_dans", type="smallint", nullable=true)
     */
    protected $situeDans;

    /**
     * @var smallint
     *
     * @ORM\Column(name="niveau_dans_immeuble", type="smallint", nullable=true)
     */
    protected $niveauDansImmeuble;

    /**
     * @var smallint
     *
     * @ORM\Column(name="nombre_niveaux_immeuble", type="smallint", nullable=true)
     */
    protected $nombreNiveauxImmeuble;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_barriere", type="boolean", nullable=true)
     */
    protected $avecBarriere;

    /**
     * @var smallint
     *
     * @ORM\Column(name="gardien", type="smallint", nullable=true)
     */
    protected $gardien;

    /**
     * @var string
     *
     * @ORM\Column(name="autres_dispositifs_securite", type="text", nullable=true)
     */
    protected $autresDispositifsSecurite;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_alimente_par_snec", type="boolean", nullable=true)
     */
    protected $isAlimenteParSnec;

    /**
     * @var smallint
     *
     * @ORM\Column(name="mode_paiement_eau", type="smallint", nullable=true)
     */
    protected $modePaiementEau;

    /**
     * @var float
     *
     * @ORM\Column(name="montant_forfait_eau", type="float", nullable=true)
     */
    protected $montantForfaitEau;

    /**
     * @var smallint
     *
     * @ORM\Column(name="mode_paiement_electricite", type="smallint", nullable=true)
     */
    protected $modePaiementElectricite;

    /**
     * @var float
     *
     * @ORM\Column(name="montant_forfait_electricite", type="float", nullable=true)
     */
    protected $montantForfaitElectricite;

    /**
     * @var smallint
     *
     * @ORM\Column(name="etat_sol", type="smallint", nullable=true)
     */
    protected $etatSol;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_climatiseur", type="boolean", nullable=true)
     */
    protected $avecClimatiseur;

    /**
     * @var smallint
     *
     * @ORM\Column(name="etat_immeuble", type="smallint", nullable=true)
     */
    protected $etatImmeuble;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_ascenseur", type="boolean", nullable=true)
     */
    protected $avecAscenseur;

    /**
     * @var string
     *
     * @ORM\Column(name="autres_infos", type="text", nullable=true)
     */
    protected $autresInfos;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_placards", type="boolean", nullable=true)
     */
    protected $avecPlacards;

    /**
     * @var smallint
     *
     * @ORM\Column(name="situation_salle_de_bains", type="smallint", nullable=true)
     */
    protected $situationSalleDeBains;

    /**
     * @var smallint
     *
     * @ORM\Column(name="situation_toilettes", type="smallint", nullable=true)
     */
    protected $situationToilettes;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_terrain_titre", type="boolean", nullable=true)
     */
    protected $isTerrainTitre;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var string
     *
     * @ORM\Column(name="class_key", type="string", length=2, nullable=true)
     */
    protected $classKey;

    /**
     * @var integer
     *
     * @ORM\Column(name="nombre_hits", type="integer", nullable=true)
     */
    protected $nombreHits;

    /**
     * @var smallint
     *
     * @ORM\Column(name="etat", type="smallint", nullable=true)
     */
    protected $etat;

    /**
     * @var boolean
     *
     * @ORM\Column(name="avec_douche", type="boolean", nullable=true)
     */
    protected $avecDouche;

//    /**
//     * @var \Annonceur
//     *
//     * @ORM\ManyToOne(targetEntity="Annonceur")
//     * @ORM\JoinColumns({
//     *   @ORM\JoinColumn(name="annonceur_id", referencedColumnName="id")
//     * })
//     */
//    protected $annonceur;

    /**
     * @var \integer
     * 
     * @ORM\Column(name="annonceur_id", type="integer")
     */
    protected $annonceurId;

    /**
     * @var \integer
     * 
     * @ORM\Column(name="ville_id", type="integer")
     */
    protected $villeId;

    /**
     * @var integer
     * 
     * @ORM\Column(name="quartier_id", type="integer")
     */
    protected $quartierId;

    /**
     * @var \integer
     *
     * @ORM\Column(name="type_maison_id", type="integer")
     */
    protected $typeMaisonId;

//    /**
//     * @var \BienImmobilier
//     *
//     * @ORM\ManyToOne(targetEntity="BienImmobilier")
//     * @ORM\JoinColumns({
//     *   @ORM\JoinColumn(name="bloc_bien_id", referencedColumnName="id")
//     * })
//     */
//    protected $blocBien;

    /**
     * @var \integer
     *
     * @ORM\Column(name="bloc_bien_id", type="integer")
     */
    protected $blocBienId;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set reference
     *
     * @param string $reference
     * @return BienImmobilier
     */
    public function setReference($reference) {
        $this->reference = $reference;

        return $this;
    }

    /**
     * Get reference
     *
     * @return string 
     */
    public function getReference() {
        return $this->reference;
    }

    /**
     * Set referenceMetier
     *
     * @param string $referenceMetier
     * @return BienImmobilier
     */
    public function setReferenceMetier($referenceMetier) {
        $this->referenceMetier = $referenceMetier;

        return $this;
    }

    /**
     * Get referenceMetier
     *
     * @return string 
     */
    public function getReferenceMetier() {
        return $this->referenceMetier;
    }

    /**
     * Set referenceBienReferentielAnnonceur
     *
     * @param string $referenceBienReferentielAnnonceur
     * @return BienImmobilier
     */
    public function setReferenceBienReferentielAnnonceur($referenceBienReferentielAnnonceur) {
        $this->referenceBienReferentielAnnonceur = $referenceBienReferentielAnnonceur;
        return $this;
    }

    /**
     * Get referenceBienReferentielAnnonceur
     *
     * @return string 
     */
    public function getReferenceBienReferentielAnnonceur() {
        return $this->referenceBienReferentielAnnonceur;
    }

    /**
     * Set statut
     *
     * @param boolean $statut
     * @return BienImmobilier
     */
    public function setStatut($statut) {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return boolean 
     */
    public function getStatut() {
        return $this->statut;
    }

    /**
     * Set datePublication
     *
     * @param \DateTime $datePublication
     * @return BienImmobilier
     */
    public function setDatePublication($datePublication) {
        $this->datePublication = $datePublication;

        return $this;
    }

    /**
     * Get datePublication
     *
     * @return \DateTime 
     */
    public function getDatePublication() {
        return $this->datePublication;
    }

    /**
     * Set dateExpiration
     *
     * @param \DateTime $dateExpiration
     * @return BienImmobilier
     */
    public function setDateExpiration($dateExpiration) {
        $this->dateExpiration = $dateExpiration;

        return $this;
    }

    /**
     * Get dateExpiration
     *
     * @return \DateTime 
     */
    public function getDateExpiration() {
        return $this->dateExpiration;
    }

    /**
     * Set secteur
     *
     * @param string $secteur
     * @return BienImmobilier
     */
    public function setSecteur($secteur) {
        $this->secteur = $secteur;

        return $this;
    }

    /**
     * Get secteur
     *
     * @return string 
     */
    public function getSecteur() {
        return $this->secteur;
    }

    /**
     * Set typeTransaction
     *
     * @param smallint $typeTransaction
     * @return BienImmobilier
     */
    public function setTypeTransaction($typeTransaction) {
        $this->typeTransaction = $typeTransaction;

        return $this;
    }

    /**
     * Get typeTransaction
     *
     * @return smallint 
     */
    public function getTypeTransaction() {
        return $this->typeTransaction;
    }

    /**
     * Set prix
     *
     * @param float $prix
     * @return BienImmobilier
     */
    public function setPrix($prix) {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     *
     * @return float 
     */
    public function getPrix() {
        return $this->prix;
    }

    /**
     * Set caution
     *
     * @param float $caution
     * @return BienImmobilier
     */
    public function setCaution($caution) {
        $this->caution = $caution;

        return $this;
    }

    /**
     * Get caution
     *
     * @return float 
     */
    public function getCaution() {
        return $this->caution;
    }

    /**
     * Set nombreMoisAavancer
     *
     * @param smallint $nombreMoisAavancer
     * @return BienImmobilier
     */
    public function setNombreMoisAavancer($nombreMoisAavancer) {
        $this->nombreMoisAavancer = $nombreMoisAavancer;

        return $this;
    }

    /**
     * Get nombreMoisAavancer
     *
     * @return smallint 
     */
    public function getNombreMoisAavancer() {
        return $this->nombreMoisAavancer;
    }

    /**
     * Set surface
     *
     * @param float $surface
     * @return BienImmobilier
     */
    public function setSurface($surface) {
        $this->surface = $surface;

        return $this;
    }

    /**
     * Get surface
     *
     * @return float 
     */
    public function getSurface() {
        return $this->surface;
    }

    /**
     * Set distanceDeLaRoute
     *
     * @param float $distanceDeLaRoute
     * @return BienImmobilier
     */
    public function setDistanceDeLaRoute($distanceDeLaRoute) {
        $this->distanceDeLaRoute = $distanceDeLaRoute;

        return $this;
    }

    /**
     * Get distanceDeLaRoute
     *
     * @return float 
     */
    public function getDistanceDeLaRoute() {
        return $this->distanceDeLaRoute;
    }

    /**
     * Set isAccessibleEnVoiture
     *
     * @param boolean $isAccessibleEnVoiture
     * @return BienImmobilier
     */
    public function setIsAccessibleEnVoiture($isAccessibleEnVoiture) {
        $this->isAccessibleEnVoiture = $isAccessibleEnVoiture;

        return $this;
    }

    /**
     * Get isAccessibleEnVoiture
     *
     * @return boolean 
     */
    public function getIsAccessibleEnVoiture() {
        return $this->isAccessibleEnVoiture;
    }

    /**
     * Set titre
     *
     * @param boolean $titre
     * @return BienImmobilier
     */
    public function setTitre($titre) {
        $this->titre = $titre;

        return $this;
    }

    /**
     * Get titre
     *
     * @return boolean 
     */
    public function getTitre() {
        return $this->titre;
    }

    /**
     * Set bati
     *
     * @param boolean $bati
     * @return BienImmobilier
     */
    public function setBati($bati) {
        $this->bati = $bati;

        return $this;
    }

    /**
     * Get bati
     *
     * @return boolean 
     */
    public function getBati() {
        return $this->bati;
    }

    /**
     * Set surfaceHabitable
     *
     * @param float $surfaceHabitable
     * @return BienImmobilier
     */
    public function setSurfaceHabitable($surfaceHabitable) {
        $this->surfaceHabitable = $surfaceHabitable;

        return $this;
    }

    /**
     * Get surfaceHabitable
     *
     * @return float 
     */
    public function getSurfaceHabitable() {
        return $this->surfaceHabitable;
    }

    /**
     * Set nombrePieces
     *
     * @param smallint $nombrePieces
     * @return BienImmobilier
     */
    public function setNombrePieces($nombrePieces) {
        $this->nombrePieces = $nombrePieces;

        return $this;
    }

    /**
     * Get nombrePieces
     *
     * @return smallint 
     */
    public function getNombrePieces() {
        return $this->nombrePieces;
    }

    /**
     * Set nombreChambres
     *
     * @param smallint $nombreChambres
     * @return BienImmobilier
     */
    public function setNombreChambres($nombreChambres) {
        $this->nombreChambres = $nombreChambres;

        return $this;
    }

    /**
     * Get nombreChambres
     *
     * @return smallint 
     */
    public function getNombreChambres() {
        return $this->nombreChambres;
    }

    /**
     * Set nombreSalons
     *
     * @param smallint $nombreSalons
     * @return BienImmobilier
     */
    public function setNombreSalons($nombreSalons) {
        $this->nombreSalons = $nombreSalons;

        return $this;
    }

    /**
     * Get nombreSalons
     *
     * @return smallint 
     */
    public function getNombreSalons() {
        return $this->nombreSalons;
    }

    /**
     * Set autresInfosSurChambres
     *
     * @param string $autresInfosSurChambres
     * @return BienImmobilier
     */
    public function setAutresInfosSurChambres($autresInfosSurChambres) {
        $this->autresInfosSurChambres = $autresInfosSurChambres;

        return $this;
    }

    /**
     * Get autresInfosSurChambres
     *
     * @return string 
     */
    public function getAutresInfosSurChambres() {
        return $this->autresInfosSurChambres;
    }

    /**
     * Set isMeuble
     *
     * @param boolean $isMeuble
     * @return BienImmobilier
     */
    public function setIsMeuble($isMeuble) {
        $this->isMeuble = $isMeuble;

        return $this;
    }

    /**
     * Get isMeuble
     *
     * @return boolean 
     */
    public function getIsMeuble() {
        return $this->isMeuble;
    }

    /**
     * Set mobilierDisponible
     *
     * @param string $mobilierDisponible
     * @return BienImmobilier
     */
    public function setMobilierDisponible($mobilierDisponible) {
        $this->mobilierDisponible = $mobilierDisponible;

        return $this;
    }

    /**
     * Get mobilierDisponible
     *
     * @return string 
     */
    public function getMobilierDisponible() {
        return $this->mobilierDisponible;
    }

    /**
     * Set nombreSallesDeBains
     *
     * @param smallint $nombreSallesDeBains
     * @return BienImmobilier
     */
    public function setNombreSallesDeBains($nombreSallesDeBains) {
        $this->nombreSallesDeBains = $nombreSallesDeBains;

        return $this;
    }

    /**
     * Get nombreSallesDeBains
     *
     * @return smallint 
     */
    public function getNombreSallesDeBains() {
        return $this->nombreSallesDeBains;
    }

    /**
     * Set autresInfosSallesDeBains
     *
     * @param string $autresInfosSallesDeBains
     * @return BienImmobilier
     */
    public function setAutresInfosSallesDeBains($autresInfosSallesDeBains) {
        $this->autresInfosSallesDeBains = $autresInfosSallesDeBains;

        return $this;
    }

    /**
     * Get autresInfosSallesDeBains
     *
     * @return string 
     */
    public function getAutresInfosSallesDeBains() {
        return $this->autresInfosSallesDeBains;
    }

    /**
     * Set nombreCuisines
     *
     * @param smallint $nombreCuisines
     * @return BienImmobilier
     */
    public function setNombreCuisines($nombreCuisines) {
        $this->nombreCuisines = $nombreCuisines;

        return $this;
    }

    /**
     * Get nombreCuisines
     *
     * @return smallint 
     */
    public function getNombreCuisines() {
        return $this->nombreCuisines;
    }

    /**
     * Set avecBalcon
     *
     * @param boolean $avecBalcon
     * @return BienImmobilier
     */
    public function setAvecBalcon($avecBalcon) {
        $this->avecBalcon = $avecBalcon;

        return $this;
    }

    /**
     * Get avecBalcon
     *
     * @return boolean 
     */
    public function getAvecBalcon() {
        return $this->avecBalcon;
    }

    /**
     * Set avecParkings
     *
     * @param boolean $avecParkings
     * @return BienImmobilier
     */
    public function setAvecParkings($avecParkings) {
        $this->avecParkings = $avecParkings;

        return $this;
    }

    /**
     * Get avecParkings
     *
     * @return boolean 
     */
    public function getAvecParkings() {
        return $this->avecParkings;
    }

    /**
     * Set nombrePlacesParking
     *
     * @param smallint $nombrePlacesParking
     * @return BienImmobilier
     */
    public function setNombrePlacesParking($nombrePlacesParking) {
        $this->nombrePlacesParking = $nombrePlacesParking;

        return $this;
    }

    /**
     * Get nombrePlacesParking
     *
     * @return smallint 
     */
    public function getNombrePlacesParking() {
        return $this->nombrePlacesParking;
    }

    /**
     * Set situeDans
     *
     * @param smallint $situeDans
     * @return BienImmobilier
     */
    public function setSitueDans($situeDans) {
        $this->situeDans = $situeDans;

        return $this;
    }

    /**
     * Get situeDans
     *
     * @return smallint 
     */
    public function getSitueDans() {
        return $this->situeDans;
    }

    /**
     * Set niveauDansImmeuble
     *
     * @param smallint $niveauDansImmeuble
     * @return BienImmobilier
     */
    public function setNiveauDansImmeuble($niveauDansImmeuble) {
        $this->niveauDansImmeuble = $niveauDansImmeuble;

        return $this;
    }

    /**
     * Get niveauDansImmeuble
     *
     * @return smallint 
     */
    public function getNiveauDansImmeuble() {
        return $this->niveauDansImmeuble;
    }

    /**
     * Set nombreNiveauxImmeuble
     *
     * @param smallint $nombreNiveauxImmeuble
     * @return BienImmobilier
     */
    public function setNombreNiveauxImmeuble($nombreNiveauxImmeuble) {
        $this->nombreNiveauxImmeuble = $nombreNiveauxImmeuble;

        return $this;
    }

    /**
     * Get nombreNiveauxImmeuble
     *
     * @return smallint 
     */
    public function getNombreNiveauxImmeuble() {
        return $this->nombreNiveauxImmeuble;
    }

    /**
     * Set avecBarriere
     *
     * @param boolean $avecBarriere
     * @return BienImmobilier
     */
    public function setAvecBarriere($avecBarriere) {
        $this->avecBarriere = $avecBarriere;

        return $this;
    }

    /**
     * Get avecBarriere
     *
     * @return boolean 
     */
    public function getAvecBarriere() {
        return $this->avecBarriere;
    }

    /**
     * Set gardien
     *
     * @param smallint $gardien
     * @return BienImmobilier
     */
    public function setGardien($gardien) {
        $this->gardien = $gardien;

        return $this;
    }

    /**
     * Get gardien
     *
     * @return smallint 
     */
    public function getGardien() {
        return $this->gardien;
    }

    /**
     * Set autresDispositifsSecurite
     *
     * @param string $autresDispositifsSecurite
     * @return BienImmobilier
     */
    public function setAutresDispositifsSecurite($autresDispositifsSecurite) {
        $this->autresDispositifsSecurite = $autresDispositifsSecurite;

        return $this;
    }

    /**
     * Get autresDispositifsSecurite
     *
     * @return string 
     */
    public function getAutresDispositifsSecurite() {
        return $this->autresDispositifsSecurite;
    }

    /**
     * Set isAlimenteParSnec
     *
     * @param boolean $isAlimenteParSnec
     * @return BienImmobilier
     */
    public function setIsAlimenteParSnec($isAlimenteParSnec) {
        $this->isAlimenteParSnec = $isAlimenteParSnec;

        return $this;
    }

    /**
     * Get isAlimenteParSnec
     *
     * @return boolean 
     */
    public function getIsAlimenteParSnec() {
        return $this->isAlimenteParSnec;
    }

    /**
     * Set modePaiementEau
     *
     * @param smallint $modePaiementEau
     * @return BienImmobilier
     */
    public function setModePaiementEau($modePaiementEau) {
        $this->modePaiementEau = $modePaiementEau;

        return $this;
    }

    /**
     * Get modePaiementEau
     *
     * @return smallint 
     */
    public function getModePaiementEau() {
        return $this->modePaiementEau;
    }

    /**
     * Set montantForfaitEau
     *
     * @param float $montantForfaitEau
     * @return BienImmobilier
     */
    public function setMontantForfaitEau($montantForfaitEau) {
        $this->montantForfaitEau = $montantForfaitEau;

        return $this;
    }

    /**
     * Get montantForfaitEau
     *
     * @return float 
     */
    public function getMontantForfaitEau() {
        return $this->montantForfaitEau;
    }

    /**
     * Set modePaiementElectricite
     *
     * @param smallint $modePaiementElectricite
     * @return BienImmobilier
     */
    public function setModePaiementElectricite($modePaiementElectricite) {
        $this->modePaiementElectricite = $modePaiementElectricite;

        return $this;
    }

    /**
     * Get modePaiementElectricite
     *
     * @return smallint 
     */
    public function getModePaiementElectricite() {
        return $this->modePaiementElectricite;
    }

    /**
     * Set montantForfaitElectricite
     *
     * @param float $montantForfaitElectricite
     * @return BienImmobilier
     */
    public function setMontantForfaitElectricite($montantForfaitElectricite) {
        $this->montantForfaitElectricite = $montantForfaitElectricite;

        return $this;
    }

    /**
     * Get montantForfaitElectricite
     *
     * @return float 
     */
    public function getMontantForfaitElectricite() {
        return $this->montantForfaitElectricite;
    }

    /**
     * Set etatSol
     *
     * @param smallint $etatSol
     * @return BienImmobilier
     */
    public function setEtatSol($etatSol) {
        $this->etatSol = $etatSol;

        return $this;
    }

    /**
     * Get etatSol
     *
     * @return smallint 
     */
    public function getEtatSol() {
        return $this->etatSol;
    }

    /**
     * Set avecClimatiseur
     *
     * @param boolean $avecClimatiseur
     * @return BienImmobilier
     */
    public function setAvecClimatiseur($avecClimatiseur) {
        $this->avecClimatiseur = $avecClimatiseur;

        return $this;
    }

    /**
     * Get avecClimatiseur
     *
     * @return boolean 
     */
    public function getAvecClimatiseur() {
        return $this->avecClimatiseur;
    }

    /**
     * Set etatImmeuble
     *
     * @param smallint $etatImmeuble
     * @return BienImmobilier
     */
    public function setEtatImmeuble($etatImmeuble) {
        $this->etatImmeuble = $etatImmeuble;

        return $this;
    }

    /**
     * Get etatImmeuble
     *
     * @return smallint 
     */
    public function getEtatImmeuble() {
        return $this->etatImmeuble;
    }

    /**
     * Set avecAscenseur
     *
     * @param boolean $avecAscenseur
     * @return BienImmobilier
     */
    public function setAvecAscenseur($avecAscenseur) {
        $this->avecAscenseur = $avecAscenseur;

        return $this;
    }

    /**
     * Get avecAscenseur
     *
     * @return boolean 
     */
    public function getAvecAscenseur() {
        return $this->avecAscenseur;
    }

    /**
     * Set autresInfos
     *
     * @param string $autresInfos
     * @return BienImmobilier
     */
    public function setAutresInfos($autresInfos) {
        $this->autresInfos = $autresInfos;

        return $this;
    }

    /**
     * Get autresInfos
     *
     * @return string 
     */
    public function getAutresInfos() {
        return $this->autresInfos;
    }

    /**
     * Set avecPlacards
     *
     * @param boolean $avecPlacards
     * @return BienImmobilier
     */
    public function setAvecPlacards($avecPlacards) {
        $this->avecPlacards = $avecPlacards;

        return $this;
    }

    /**
     * Get avecPlacards
     *
     * @return boolean 
     */
    public function getAvecPlacards() {
        return $this->avecPlacards;
    }

    /**
     * Set situationSalleDeBains
     *
     * @param smallint $situationSalleDeBains
     * @return BienImmobilier
     */
    public function setSituationSalleDeBains($situationSalleDeBains) {
        $this->situationSalleDeBains = $situationSalleDeBains;

        return $this;
    }

    /**
     * Get situationSalleDeBains
     *
     * @return smallint 
     */
    public function getSituationSalleDeBains() {
        return $this->situationSalleDeBains;
    }

    /**
     * Set situationToilettes
     *
     * @param smallint $situationToilettes
     * @return BienImmobilier
     */
    public function setSituationToilettes($situationToilettes) {
        $this->situationToilettes = $situationToilettes;

        return $this;
    }

    /**
     * Get situationToilettes
     *
     * @return smallint 
     */
    public function getSituationToilettes() {
        return $this->situationToilettes;
    }

    /**
     * Set isTerrainTitre
     *
     * @param boolean $isTerrainTitre
     * @return BienImmobilier
     */
    public function setIsTerrainTitre($isTerrainTitre) {
        $this->isTerrainTitre = $isTerrainTitre;

        return $this;
    }

    /**
     * Get isTerrainTitre
     *
     * @return boolean 
     */
    public function getIsTerrainTitre() {
        return $this->isTerrainTitre;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return BienImmobilier
     */
    public function setCreatedAt($createdAt) {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt() {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return BienImmobilier
     */
    public function setUpdatedAt($updatedAt) {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt() {
        return $this->updatedAt;
    }

    /**
     * Set classKey
     *
     * @param string $classKey
     * @return BienImmobilier
     */
    public function setClassKey($classKey) {
        $this->classKey = $classKey;

        return $this;
    }

    /**
     * Get classKey
     *
     * @return string 
     */
    public function getClassKey() {
        return $this->classKey;
    }

    /**
     * Set nombreHits
     *
     * @param integer $nombreHits
     * @return BienImmobilier
     */
    public function setNombreHits($nombreHits) {
        $this->nombreHits = $nombreHits;

        return $this;
    }

    /**
     * Get nombreHits
     *
     * @return integer 
     */
    public function getNombreHits() {
        return $this->nombreHits;
    }

    /**
     * Set etat
     *
     * @param smallint $etat
     * @return BienImmobilier
     */
    public function setEtat($etat) {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return smallint 
     */
    public function getEtat() {
        return $this->etat;
    }

    /**
     * Set avecDouche
     *
     * @param boolean $avecDouche
     * @return BienImmobilier
     */
    public function setAvecDouche($avecDouche) {
        $this->avecDouche = $avecDouche;

        return $this;
    }

    /**
     * Get avecDouche
     *
     * @return boolean 
     */
    public function getAvecDouche() {
        return $this->avecDouche;
    }

    /**
     * Set annonceur
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Annonceur $annonceur
     * @return BienImmobilier
     */
//    public function setAnnonceur(\Koutchoumi\FrontendBundle\Entity\Annonceur $annonceur = null) {
//        $this->annonceur = $annonceur;
//
//        return $this;
//    }

    /**
     * Get annonceur
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Annonceur 
     */
    public function getAnnonceur() {
//        return $this->annonceur;
        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $annonceur=$em->getRepository('KoutchoumiFrontendBundle:Annonceur')->findOneBy(array('id' => $this->annonceurId));
        return $annonceur;
    }

    /**
     * Set ville
     *
     * @param \Koutchoumi\FrontendBundle\Entity\Ville $ville
     * @return BienImmobilier
     */
//    public function setVille(\Koutchoumi\FrontendBundle\Entity\Ville $ville = null) {
//        $this->ville = $ville;
//
//        return $this;
//    }

    /**
     * Get ville
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Ville 
     */
    public function getVille() {
        return Ville::getVille($this->villeId);
    }

    /**
     * Get Quartier
     *
     * @return \Koutchoumi\FrontendBundle\Entity\Quartier 
     */
    public function getQuartier() {
        return Quartier::getQuartier($this->quartierId);
    }
    
//    /**
//     * Set typeMaison
//     *
//     * @param \Koutchoumi\FrontendBundle\Entity\TypeMaison $typeMaison
//     * @return BienImmobilier
//     */
//    public function setTypeMaison(\Koutchoumi\FrontendBundle\Entity\TypeMaison $typeMaison = null) {
//        $this->typeMaison = $typeMaison;
//        return $this;
//    }

//    /**
//     * Get typeMaison
//     *
//     * @return \Koutchoumi\FrontendBundle\Entity\TypeMaison 
//     */
//    public function getTypeMaison() {
//        return $this->typeMaison;
//    }

//    /**
//     * Set blocBien
//     *
//     * @param \Koutchoumi\FrontendBundle\Entity\BienImmobilier $blocBien
//     * @return BienImmobilier
//     */
//    public function setBlocBien(\Koutchoumi\FrontendBundle\Entity\BienImmobilier $blocBien = null) {
//        $this->blocBien = $blocBien;
//
//        return $this;
//    }

//    /**
//     * Get blocBien
//     *
//     * @return \Koutchoumi\FrontendBundle\Entity\BienImmobilier 
//     */
//    public function getBlocBien() {
//        return $this->blocBien;
//    }

    //Code métier
    public static function save($bien) {
        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $em->persist($bien);
        $em->flush();
    }

    /**
     * Retourne le nombre de photos d'un bien immobilier
     * @return int Le nombre de photos du bien immobilier
     */
    public function getNombrePhotos() {
        return \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                        ->select('count(ph)')
                        ->from('KoutchoumiFrontendBundle:Photo', 'ph')
                        ->innerJoin('KoutchoumiFrontendBundle:BienImmobilier', 'bi', 'WITH', 'ph.bienImmobilier=:photo_bien_immo')
                        ->setParameter('photo_bien_immo', $this->id)
                        ->getQuery()
                        ->getResult();
    }

    /*
     * Retourne les photos du bien immobilier courant. 
     * @Return array (Photo)
     */

    public function getPhotos() {
        $result = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                ->select('ph')
                ->from('KoutchoumiFrontendBundle:Photo', 'ph')
                ->innerJoin('KoutchoumiFrontendBundle:BienImmobilier', 'bi', 'WITH', 'ph.bienImmobilier=:photo_bien_immo')
                ->setParameter('photo_bien_immo', $this->id)
                ->getQuery()
                ->getResult();
        return new Collections\ArrayCollection($result);
    }

    /**
     * Retourne la photo principale d'un bien immobilier ou NULL s'il n'y a pas de photo principale
     * @return Photo Photo principale du bien immobilier
     */
    public function getPhotoPrincipale() {
        $photos = $this->getPhotos();
        if ($photos->count() > 0) {
            foreach ($photos as $photo) {
                if ($photo->getIsPrincipale()) {
                    return $photo;
                }
            }
        }
        return NULL;
    }

    /**
     * @return Description en français dans le texte du bien immobilier. Implémentée
     * par les descendants Appartement, Maison, Terrain, Studio
     */
    public function getDescription() {
//        $shortDes = BienImmobilier::getLibelleTypeBien(). ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
        $des = ReferenceData::getLibelleTypeBien($this->classKey) . ' ' . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - ' .
                Ville::getVille($this->getVilleId())->getNom() . ', ' . Quartier::getQuartier($this->getQuartierId())->getNom() . ', ' . $this->getSecteur();
        return $des;
    }

    public function getShortDescription() {
//        $shortDes = BienImmobilier::getLibelleTypeBien(). ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
        $shortDes = ReferenceData::getLibelleTypeBien($this->classKey) . ' ' . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - ' .
                $this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur();
        return $shortDes;
    }

    public function getShortDescriptionWithoutPrice() {
//        $shortDes = BienImmobilier::getLibelleTypeBien(). ' ' .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - '.
        $shortDes = ReferenceData::getLibelleTypeBien($this->classKey) . ' ' . ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()) . ' - ' .
                $this->getVille()->getNom() . ', ' . $this->getQuartier()->getNom() . ', ' . $this->getSecteur();
        return $shortDes;
    }

    public static function getLibelleTypeBien() {
        return "bien immobilier";
    }

    public function getTitle() {
        return "bien immobilier";
    }

    /**
     * Initializes internal state of BaseBienImmobilier object.
     * @see        applyDefaults()
     */
    public function __construct() {
        $this->applyDefaultValues();
        $this->ville = new Ville();
        $this->quartier = new Quartier();
    }

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues() {
        $this->nombre_hits = 0;
    }

    /*
     * Supprime cette instance de BienImmobilier de la base de données
     * 
     */

    public function delete() {
        $this->getDoctrine()->getManager()->remove($this);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param      string $name name
     * @param      string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return     mixed Value of field.
     */
    public function getByName($name) {
        return $em->createQueryBuilder()
                        ->select('ph.:fieldname')
                        ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                        ->setParameter('fieldname', $name)
                        ->getQuery()
                        ->getResult();
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param      int $pos position in xml schema
     * @return     mixed Value of field at $pos
     */
    public function getByPosition($pos) {
        switch ($pos) {
            case 0:
                return $this->getId();
                break;
            case 1:
                return $this->getReference();
                break;
            case 2:
                return $this->getReferenceMetier();
                break;
            case 3:
                return $this->getReferenceBienReferentielAnnonceur();
                break;
            case 4:
                return $this->getBlocBienId();
                break;
            case 5:
                return $this->getStatut();
                break;
            case 6:
                return $this->getDatePublication();
                break;
            case 7:
                return $this->getDateExpiration();
                break;
            case 8:
                return $this->getSecteur();
                break;
            case 9:
                return $this->getTypeTransaction();
                break;
            case 10:
                return $this->getPrix();
                break;
            case 11:
                return $this->getCaution();
                break;
            case 12:
                return $this->getNombreMoisAavancer();
                break;
            case 13:
                return $this->getSurface();
                break;
            case 14:
                return $this->getDistanceDeLaRoute();
                break;
            case 15:
                return $this->getIsAccessibleEnVoiture();
                break;
            case 16:
                return $this->getTitre();
                break;
            case 17:
                return $this->getBati();
                break;
            case 18:
                return $this->getSurfaceHabitable();
                break;
            case 19:
                return $this->getNombrePieces();
                break;
            case 20:
                return $this->getNombreChambres();
                break;
            case 21:
                return $this->getNombreSalons();
                break;
            case 22:
                return $this->getAutresInfosSurChambres();
                break;
            case 23:
                return $this->getIsMeuble();
                break;
            case 24:
                return $this->getMobilierDisponible();
                break;
            case 25:
                return $this->getNombreSallesDeBains();
                break;
            case 26:
                return $this->getAutresInfosSallesDeBains();
                break;
            case 27:
                return $this->getNombreCuisines();
                break;
            case 28:
                return $this->getAvecBalcon();
                break;
            case 29:
                return $this->getAvecParkings();
                break;
            case 30:
                return $this->getNombrePlacesParking();
                break;
            case 31:
                return $this->getSitueDans();
                break;
            case 32:
                return $this->getNiveauDansImmeuble();
                break;
            case 33:
                return $this->getNombreNiveauxImmeuble();
                break;
            case 34:
                return $this->getAvecBarriere();
                break;
            case 35:
                return $this->getGardien();
                break;
            case 36:
                return $this->getAutresDispositifsSecurite();
                break;
            case 37:
                return $this->getIsAlimenteParSnec();
                break;
            case 38:
                return $this->getModePaiementEau();
                break;
            case 39:
                return $this->getMontantForfaitEau();
                break;
            case 40:
                return $this->getModePaiementElectricite();
                break;
            case 41:
                return $this->getMontantForfaitElectricite();
                break;
            case 42:
                return $this->getEtatSol();
                break;
            case 43:
                return $this->getAvecClimatiseur();
                break;
            case 44:
                return $this->getEtatImmeuble();
                break;
            case 45:
                return $this->getAvecAscenseur();
                break;
            case 46:
                return $this->getAutresInfos();
                break;
            case 47:
                return $this->getAvecPlacards();
                break;
            case 48:
                return $this->getSituationSalleDeBains();
                break;
            case 49:
                return $this->getSituationToilettes();
                break;
            case 50:
                return $this->getTypeMaisonId();
                break;
            case 51:
                return $this->getIsTerrainTitre();
                break;
            case 52:
                return $this->getEtat();
                break;
            case 53:
                return $this->getAvecDouche();
                break;
            case 54:
                return $this->getCreatedAt();
                break;
            case 55:
                return $this->getUpdatedAt();
                break;
            case 56:
                return $this->getClassKey();
                break;
            case 57:
                return $this->getAnnonceurId();
                break;
            case 58:
                return $this->getVilleId();
                break;
            case 59:
                return $this->getQuartierId();
                break;
            case 60:
                return $this->getNombreHits();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Get the [annonceur_id] column value.
     * 
     * @return     int
     */
    public function getAnnonceurId() {
        return $this->annonceurId;
    }

    /**
     * Set the [annonceur_id] column value.
     * 
     * @return     BienImmobilier
     */
    public function setAnnonceurId($annonceurId) {
        $this->annonceurId = $annonceurId;
        return $this;
    }

    /**
     * Get the [ville_id] column value.
     * 
     * @return     int
     */
    public function getVilleId() {
        return $this->villeId;
    }

    /**
     * Set the [ville_id] column value.
     * 
     * @return     BienImmobilier
     */
    public function setVilleId($villeId) {
        $this->villeId = $villeId;
        return $this;
    }

    /**
     * Get the [quartier_id] column value.
     * 
     * @return     int
     */
    public function getQuartierId() {
        return $this->quartierId;
    }

    /**
     * Set the [quartier_id] column value.
     * 
     * @return     BienImmobilier
     */
    public function setQuartierId($quartierId) {
        $this->quartierId = $quartierId;
        return $this;
    }

    /**
     * Get the [typemaison_id] column value.
     * 
     * @return     int
     */
    public function getTypeMaisonId() {
        return $this->typeMaisonId;
    }

    /**
     * Set the [typemaison_id] column value.
     * 
     * @return     BienImmobilier
     */
    public function setTypeMaisonId($typemaisonId) {
        $this->typeMaisonId = $typemaisonId;
        return $this;
    }

    /**
     * Get the [blocbien_id] column value.
     * 
     * @return     int
     */
    public function getBlocBienId() {
        return $this->blocBienId;
    }

    /**
     * Set the [blocbien_id] column value.
     * 
     * @return     int
     */
    public function setBlocBienId($blocBienId) {
        $this->blocBienId = $blocBienId;
        return $this;
    }

    protected $collBienImmobiliersRelatedByBlocBienId;
    private $lastBienImmobilierRelatedByBlocBienIdCriteria = null;

    public function getBienImmobiliersRelatedByBlocBienId($qb = null) {
        if ($qb === null) {
            $qb = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                    ->select('bi')
                    ->from('KoutchoumiFrontendBundle:BienImmobilier', 'bi')
                    ->where('1=1');
        } elseif ($qb instanceof QueryBuilder) {
            $qb = clone $qb;
        }

        if ($this->collBienImmobiliersRelatedByBlocBienId === null) {
//            if ($this->isNew()) {
                $this->collBienImmobiliersRelatedByBlocBienId = array();
//            } else {
//
//                $qb->andWhere('bi.' . BLOC_BIEN_ID . '=:bbId')
//                        ->setParameter(bbId, $this->id);
//
//                $this->collBienImmobiliersRelatedByBlocBienId = $qb->getQuery()->getResult();
//            }
        } else {
            // criteria has no effect for a new object
//            if (!$this->isNew()) {
                // the following code is to determine if a new query is
                // called for.  If the criteria is the same as the last
                // one, just return the collection.

                $qb->andWhere('bi.' . BLOC_BIEN_ID . '=:bbId')
                        ->setParameter(bbId, $this->id);

                if (!isset($this->lastBienImmobilierRelatedByBlocBienIdCriteria) || !$this->lastBienImmobilierRelatedByBlocBienIdCriteria->equals($qb)) {
                    $this->collBienImmobiliersRelatedByBlocBienId = $qb->getQuery()->getResult();
                }
//            }
        }
        $this->lastBienImmobilierRelatedByBlocBienIdCriteria = $qb;
        return $this->collBienImmobiliersRelatedByBlocBienId;
    }

    public function serialize() {
        return serialize(array(
//                    'annonceur' => $this->annonceur,
                    'autresDispositifsSecurite' => $this->autresDispositifsSecurite,
                    'autresInfos' => $this->autresInfos,
                    'autresInfosSallesDeBains' => $this->autresInfosSallesDeBains,
                    'autresInfosSurChambres' => $this->autresInfosSurChambres,
                    'avecAscenseur' => $this->avecAscenseur,
                    'avecBalcon' => $this->avecBalcon,
                    'avecBarriere' => $this->avecBarriere,
                    'avecClimatiseur' => $this->avecClimatiseur,
                    'avecDouche' => $this->avecDouche,
                    'avecParkings' => $this->avecParkings,
                    'avecPlacards' => $this->avecPlacards,
                    'bati' => $this->bati,
                    'blocBienId' => $this->blocBienId,
                    'caution' => $this->caution,
                    'classKey' => $this->classKey,
                    'createdAt' => $this->createdAt,
                    'dateExpiration' => $this->dateExpiration,
                    'datePublication' => $this->datePublication,
                    'distanceDeLaRoute' => $this->distanceDeLaRoute,
                    'etat' => $this->etat,
                    'etatImmeuble' => $this->etatImmeuble,
                    'etatSol' => $this->etatSol,
                    'gardien' => $this->gardien,
                    'id' => $this->id,
                    'isAccessibleEnVoiture' => $this->isAccessibleEnVoiture,
                    'isAlimenteParSnec' => $this->isAlimenteParSnec,
                    'isMeuble' => $this->isMeuble,
                    'isTerrainTitre' => $this->isTerrainTitre,
                    'mobilierDisponible' => $this->mobilierDisponible,
                    'modePaiementEau' => $this->modePaiementEau,
                    'modePaiementElectricite' => $this->modePaiementElectricite,
                    'montantForfaitEau' => $this->montantForfaitEau,
                    'montantForfaitElectricite' => $this->montantForfaitElectricite,
                    'niveauDansImmeuble' => $this->niveauDansImmeuble,
                    'nombreChambres' => $this->nombreChambres,
                    'nombreCuisines' => $this->nombreCuisines,
                    'nombreHits' => $this->nombreHits,
                    'nombreMoisAavancer' => $this->nombreMoisAavancer,
                    'nombreNiveauxImmeuble' => $this->nombreNiveauxImmeuble,
                    'nombrePieces' => $this->nombrePieces,
                    'nombrePlacesParking' => $this->nombrePlacesParking,
                    'nombreSallesDeBains' => $this->nombreSallesDeBains,
                    'nombreSalons' => $this->nombreSalons,
                    'prix' => $this->prix,
                    'quartierId' => $this->quartierId,
                    'reference' => $this->reference,
                    'referenceBienReferentielAnnonceur' => $this->referenceBienReferentielAnnonceur,
                    'referenceMetier' => $this->referenceMetier,
                    'secteur' => $this->secteur,
                    'situationSalleDeBains' => $this->situationSalleDeBains,
                    'situationToilettes' => $this->situationToilettes,
                    'situeDans' => $this->situeDans,
                    'statut' => $this->statut,
                    'surface' => $this->surface,
                    'surfaceHabitable' => $this->surfaceHabitable,
                    'titre' => $this->titre,
                    'typeMaisonId' => $this->typeMaisonId,
                    'typeTransaction' => $this->typeTransaction,
                    'updatedAt' => $this->updatedAt,
                    'villeId' => $this->villeId
                        )
        );
    }

    public function unserialize($serialized) {
        $array = unserialize($serialized);
//        die(var_dump($array));
//        $this->annonceur = $array['annonceur'];
        $this->autresDispositifsSecurite = $array['autresDispositifsSecurite'];
        $this->autresInfos = $array['autresInfos'];
        $this->autresInfosSallesDeBains = $array['autresInfosSallesDeBains'];
        $this->autresInfosSurChambres = $array['autresInfosSurChambres'];
        $this->avecAscenseur = $array['avecAscenseur'];
        $this->avecBalcon = $array['avecBalcon'];
        $this->avecBarriere = $array['avecBarriere'];
        $this->avecClimatiseur = $array['avecClimatiseur'];
        $this->avecDouche = $array['avecDouche'];
        $this->avecParkings = $array['avecParkings'];
        $this->avecPlacards = $array['avecPlacards'];
        $this->bati = $array['bati'];
        $this->blocBienId = $array['blocBienId'];
        $this->caution = $array['caution'];
        $this->classKey = $array['classKey'];
        $this->createdAt = $array['createdAt'];
        $this->dateExpiration = $array['dateExpiration'];
        $this->datePublication = $array['datePublication'];
        $this->distanceDeLaRoute = $array['distanceDeLaRoute'];
        $this->etat = $array['etat'];
        $this->etatImmeuble = $array['etatImmeuble'];
        $this->etatSol = $array['etatSol'];
        $this->gardien = $array['gardien'];
        $this->id = $array['id'];
        $this->isAccessibleEnVoiture = $array['isAccessibleEnVoiture'];
        $this->isAlimenteParSnec = $array['isAlimenteParSnec'];
        $this->isMeuble = $array['isMeuble'];
        $this->isTerrainTitre = $array['isTerrainTitre'];
        $this->mobilierDisponible = $array['mobilierDisponible'];
        $this->modePaiementEau = $array['modePaiementEau'];
        $this->modePaiementElectricite = $array['modePaiementElectricite'];
        $this->montantForfaitEau = $array['montantForfaitEau'];
        $this->montantForfaitElectricite = $array['montantForfaitElectricite'];
        $this->niveauDansImmeuble = $array['niveauDansImmeuble'];
        $this->nombreChambres = $array['nombreChambres'];
        $this->nombreCuisines = $array['nombreCuisines'];
        $this->nombreHits = $array['nombreHits'];
        $this->nombreMoisAavancer = $array['nombreMoisAavancer'];
        $this->nombreNiveauxImmeuble = $array['nombreNiveauxImmeuble'];
        $this->nombrePieces = $array['nombrePieces'];
        $this->nombrePlacesParking = $array['nombrePlacesParking'];
        $this->nombreSallesDeBains = $array['nombreSallesDeBains'];
        $this->nombreSalons = $array['classKey'];
        $this->prix = $array['prix'];
        $this->quartierId = $array['quartierId'];
        $this->reference = $array['reference'];
        $this->referenceBienReferentielAnnonceur = $array['referenceBienReferentielAnnonceur'];
        $this->referenceMetier = $array['referenceMetier'];
        $this->secteur = $array['secteur'];
        $this->situationSalleDeBains = $array['situationSalleDeBains'];
        $this->situationToilettes = $array['situationToilettes'];
        $this->situeDans = $array['situeDans'];
        $this->statut = $array['statut'];
        $this->surface = $array['surface'];
        $this->surfaceHabitable = $array['surfaceHabitable'];
        $this->titre = $array['titre'];
        $this->typeMaisonId = $array['typeMaisonId'];
        $this->typeTransaction = $array['typeTransaction'];
        $this->updatedAt = $array['updatedAt'];
        $this->villeId = $array['villeId'];
    }

    //Constantes exposant les attributs des classes à l'extérieur

    const STATUT = "statut";
    const DATE_EXPIRATION = "dateExpiration";
    const TYPE_TRANSACTION = "typeTransaction";
    const CLASS_KEY = "classKey";
    const ID = "id";
    const VILLE_ID = "villeId";
    const ANNONCEUR_ID = "annonceur";
    const PRIX = "prix";
    const DATE_PUBLICATION = "datePublication";
    const SURFACE = "surface";
    const NOMBRE_PIECES = "nombrePieces";
    const NOMBRE_HITS = "nombreHits";
    const NOMBRE_CHAMBRES = "nombreChambres";
    const AVEC_PARKINGS = "avecParkings";
    const BLOC_BIEN_ID = "blocBien";
    const CLASSKEY_APPARTEMENT = 'AP';
    const CLASSKEY_STUDIO = 'ST';
    const CLASSKEY_MAISON = 'MA';
    const CLASSKEY_TERRAIN = 'TE';
    const CLASSKEY_BLOCTERRAIN = 'BT';
    const CLASSKEY_ENTREPOT = 'EN';
    const CLASSKEY_MAGASIN = 'MG';
    const CLASSKEY_BOUTIQUE = 'BO';
    const CLASSKEY_BUREAU = 'BU';

}