<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Domaine
 *
 * @ORM\Table(name="domaine")
 * @ORM\Entity
 */
class Domaine
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=5, nullable=false)
     */
    protected $code;

    /**
     * @var integer
     *
     * @ORM\Column(name="priorite", type="integer", nullable=true)
     */
    protected $priorite;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Domaine
     */
    public function setCode($code)
    {
        $this->code = $code;
    
        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set priorite
     *
     * @param integer $priorite
     * @return Domaine
     */
    public function setPriorite($priorite)
    {
        $this->priorite = $priorite;
    
        return $this;
    }

    /**
     * Get priorite
     *
     * @return integer 
     */
    public function getPriorite()
    {
        return $this->priorite;
    }
    
    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom(){
        $noms= \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                        ->select('doI18n.nom')
                        ->from('KoutchoumiFrontendBundle:DomaineI18n','doI18n')
                        ->where('doI18n.id=:id')
                        ->andWhere('doI18n.culture=:locale')
                        ->setParameters(array('id'=> ($this->id), 'locale'=>(\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('locale'))))                    
                        ->getQuery()
                        ->getResult();
            if(!empty($noms)) {
                $nom=(string)$noms[0];
            }
            else $nom="";
            return $nom;
    }
}