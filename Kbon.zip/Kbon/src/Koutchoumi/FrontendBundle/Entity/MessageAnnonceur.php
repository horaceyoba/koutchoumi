<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MessageAnnonceur
 *
 * @ORM\Table(name="message_annonceur")
 * @ORM\Entity
 */
class MessageAnnonceur
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="from_email", type="string", length=255, nullable=false)
     */
    protected $fromEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="from_numero_telephone", type="string", length=255, nullable=true)
     */
    protected $fromNumeroTelephone;

    /**
     * @var string
     *
     * @ORM\Column(name="from_name", type="string", length=255, nullable=true)
     */
    protected $fromName;

    /**
     * @var string
     *
     * @ORM\Column(name="class_key", type="string", length=1, nullable=false)
     */
    protected $classKey;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_heure_visite", type="datetime", nullable=true)
     */
    protected $dateHeureVisite;

    /**
     * @var string
     *
     * @ORM\Column(name="precisions_visite", type="text", nullable=true)
     */
    protected $precisionsVisite;

    /**
     * @var string
     *
     * @ORM\Column(name="questions", type="text", nullable=true)
     */
    protected $questions;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_read", type="boolean", nullable=false)
     */
    protected $isRead;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var \BienImmobilier
     *
     * @ORM\ManyToOne(targetEntity="BienImmobilier")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bien_immobilier_id", referencedColumnName="id")
     * })
     */
    protected $bienImmobilier;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fromEmail
     *
     * @param string $fromEmail
     * @return MessageAnnonceur
     */
    public function setFromEmail($fromEmail)
    {
        $this->fromEmail = $fromEmail;
    
        return $this;
    }

    /**
     * Get fromEmail
     *
     * @return string 
     */
    public function getFromEmail()
    {
        return $this->fromEmail;
    }

    /**
     * Set fromNumeroTelephone
     *
     * @param string $fromNumeroTelephone
     * @return MessageAnnonceur
     */
    public function setFromNumeroTelephone($fromNumeroTelephone)
    {
        $this->fromNumeroTelephone = $fromNumeroTelephone;
    
        return $this;
    }

    /**
     * Get fromNumeroTelephone
     *
     * @return string 
     */
    public function getFromNumeroTelephone()
    {
        return $this->fromNumeroTelephone;
    }

    /**
     * Set fromName
     *
     * @param string $fromName
     * @return MessageAnnonceur
     */
    public function setFromName($fromName)
    {
        $this->fromName = $fromName;
    
        return $this;
    }

    /**
     * Get fromName
     *
     * @return string 
     */
    public function getFromName()
    {
        return $this->fromName;
    }

    /**
     * Set classKey
     *
     * @param string $classKey
     * @return MessageAnnonceur
     */
    public function setClassKey($classKey)
    {
        $this->classKey = $classKey;
    
        return $this;
    }

    /**
     * Get classKey
     *
     * @return string 
     */
    public function getClassKey()
    {
        return $this->classKey;
    }

    /**
     * Set dateHeureVisite
     *
     * @param \DateTime $dateHeureVisite
     * @return MessageAnnonceur
     */
    public function setDateHeureVisite($dateHeureVisite)
    {
        $this->dateHeureVisite = $dateHeureVisite;
    
        return $this;
    }

    /**
     * Get dateHeureVisite
     *
     * @return \DateTime 
     */
    public function getDateHeureVisite()
    {
        return $this->dateHeureVisite;
    }

    /**
     * Set precisionsVisite
     *
     * @param string $precisionsVisite
     * @return MessageAnnonceur
     */
    public function setPrecisionsVisite($precisionsVisite)
    {
        $this->precisionsVisite = $precisionsVisite;
    
        return $this;
    }

    /**
     * Get precisionsVisite
     *
     * @return string 
     */
    public function getPrecisionsVisite()
    {
        return $this->precisionsVisite;
    }

    /**
     * Set questions
     *
     * @param string $questions
     * @return MessageAnnonceur
     */
    public function setQuestions($questions)
    {
        $this->questions = $questions;
    
        return $this;
    }

    /**
     * Get questions
     *
     * @return string 
     */
    public function getQuestions()
    {
        return $this->questions;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return MessageAnnonceur
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set isRead
     *
     * @param boolean $isRead
     * @return MessageAnnonceur
     */
    public function setIsRead($isRead)
    {
        $this->isRead = $isRead;
    
        return $this;
    }

    /**
     * Get isRead
     *
     * @return boolean 
     */
    public function getIsRead()
    {
        return $this->isRead;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return MessageAnnonceur
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set bienImmobilier
     *
     * @param \Koutchoumi\FrontendBundle\Entity\BienImmobilier $bienImmobilier
     * @return MessageAnnonceur
     */
    public function setBienImmobilier(\Koutchoumi\FrontendBundle\Entity\BienImmobilier $bienImmobilier = null)
    {
        $this->bienImmobilier = $bienImmobilier;
    
        return $this;
    }

    /**
     * Get bienImmobilier
     *
     * @return \Koutchoumi\FrontendBundle\Entity\BienImmobilier 
     */
    public function getBienImmobilier()
    {
        return $this->bienImmobilier;
    }
}