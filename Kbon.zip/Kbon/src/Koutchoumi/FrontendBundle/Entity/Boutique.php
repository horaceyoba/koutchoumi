<?php


/**
 *Représente une instance d'un BienImmobilier de type boutique
 */
namespace Koutchoumi\FrontendBundle\Entity;
class Boutique extends BienImmobilier {

	/**
	 * Constructs a new Boutique class, setting the class_key column to BienImmobilierPeer::CLASSKEY_BO.
	 */
    private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_BOUTIQUE);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Boutique");
        }

        public function getDescription(){
            return $this->getShortDescription();
        }

        public function getShortDescription()
        {
            $shortDes = self::getLibelleTypeBien() ." ". ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()). " - " .$this->getVille()->getNom() . "," .
                    $this->getQuartier()->getNom() . "," . $this->getSecteur() . " - ".
                    number_format($this->getPrix(), 0, '.', ' ') . " FCFA - ". $this->getSurface()." m2";

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = self::getLibelleTypeBien() ." ". ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()). " - " .$this->getVille()->getNom() . "," .
                    $this->getQuartier()->getNom() . "," . $this->getSecteur() . " - ". $this->getSurface()." m2";

            return $shortDes;            
        }

        /**
         * Boutique à louer à Douala, Akwa I - 20 000 Fcfa
         */
        public function getTitle()
        {
            $title = Boutique::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';

            return $title;
        }

} // Boutique
