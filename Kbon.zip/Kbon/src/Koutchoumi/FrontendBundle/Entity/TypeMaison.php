<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TypeMaison
 *
 * @ORM\Table(name="type_maison")
 * @ORM\Entity(repositoryClass="Koutchoumi\FrontendBundle\Entity\TypeMaisonRepository")
 * @ORM\Entity
 */
class TypeMaison {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    /**
     * The value for the culture field.
     * @var string
     */
    protected $culture;

//    public function getCurrentTypeMaisonI18n($locale)
//    {
//        if (is_null($locale))
//        {
//            $locale = is_null($this->culture) ? \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('locale') : $this->culture;
//        }
//
//        if (!isset($this->current_i18n[$culture]))
//        {
//        $obj = TypeMaisonI18nPeer::retrieveByPK($this->getId(), $culture);
//        if ($obj)
//        {
//            $this->setTypeMaisonI18nForCulture($obj, $culture);
//        }
//        else
//        {
//            $this->setTypeMaisonI18nForCulture(new TypeMaisonI18n(), $culture);
//            $this->current_i18n[$culture]->setCulture($culture);
//        }
//        }
//
//        return $this->current_i18n[$culture];
//    }
//    
//    public function setTypeMaisonI18nForCulture($object, $culture)
//    {
//        $this->current_i18n[$culture] = $object;
//        $this->addTypeMaisonI18n($object);
//    }
//    
//    public function addTypeMaisonI18n(TypeMaisonI18n $l)
//	{
//		if ($this->collTypeMaisonI18ns === null) {
//			$this->initTypeMaisonI18ns();
//		}
//		if (!in_array($l, $this->collTypeMaisonI18ns, true)) { // only add it if the **same** object is not already associated
//			array_push($this->collTypeMaisonI18ns, $l);
//			$l->setTypeMaison($this);
//		}
//	}
//        
//        public function initTypeMaisonI18ns()
//	{
//		$this->collTypeMaisonI18ns = array();
//	}


    public function getLibelle() {

        $libelles = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager()->createQueryBuilder()
                ->select('tmI18n.libelle')
                ->from('KoutchoumiFrontendBundle:TypeMaisonI18n', 'tmI18n')
                ->where('tmI18n.id=:id')
                ->andWhere('tmI18n.culture=:locale')
                ->setParameters(array('id' => ($this->id), 'locale' => (\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->getParameter('locale'))))
                ->getQuery()
                ->getResult();
        if (!empty($libelles)) {
            $lib = (string) $libelles[0]['libelle'];
        }
        else
            $lib = "";
        return $lib;
    }

    public function __toString() {
        return (string)$this->getLibelle();
    }

}