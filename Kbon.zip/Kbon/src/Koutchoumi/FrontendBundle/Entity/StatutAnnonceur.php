<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Valeurs possibles du statut d'un annonceur
 *
 * @author pattchen
 */
namespace Koutchoumi\FrontendBundle\Entity;
class StatutAnnonceur {
    //put your code here
    const EN_ATTENTE_DE_VALIDATION_EMAIL = 0;
    const EN_ATTENTE_DE_VALIDATION_KOUTCHOUMI = 1;
    const PAS_DIGNE_DE_CONFIANCE = 2;
    const DIGNE_DE_CONFIANCE = 3;
    const SUSPENDU = 4;
    const DESACTIVE = 5;
}
?>
