<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TypeServiceI18n
 *
 * @ORM\Table(name="type_service_i18n")
 * @ORM\Entity
 */
class TypeServiceI18n
{
    /**
     * @var string
     *
     * @ORM\Column(name="culture", type="string", length=7, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $culture;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

//    /**
//     * @var \TypeService
//     *
//     * @ORM\Id
//     * @ORM\GeneratedValue(strategy="NONE")
//     * @ORM\OneToOne(targetEntity="TypeService")
//     * @ORM\JoinColumns({
//     *   @ORM\JoinColumn(name="id", referencedColumnName="id")
//     * })
//     */
//    protected $id;

/**
     * @var integer
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\Column(name="id", type="integer", nullable=false)
     */
    protected $id;

    /**
     * Set culture
     *
     * @param string $culture
     * @return TypeServiceI18n
     */
    public function setCulture($culture)
    {
        $this->culture = $culture;
    
        return $this;
    }

    /**
     * Get culture
     *
     * @return string 
     */
    public function getCulture()
    {
        return $this->culture;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return TypeServiceI18n
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    
        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set id
     *
     * @param \Koutchoumi\FrontendBundle\Entity\TypeService $id
     * @return TypeServiceI18n
     */
    public function setId(\Koutchoumi\FrontendBundle\Entity\TypeService $id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return \Koutchoumi\FrontendBundle\Entity\TypeService 
     */
    public function getId()
    {
        return $this->id;
    }
}