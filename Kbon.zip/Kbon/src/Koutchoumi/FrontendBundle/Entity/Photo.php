<?php

namespace Koutchoumi\FrontendBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Photo
 *
 * @ORM\Table(name="photo")
 * @ORM\Entity
 */
class Photo
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="chemin", type="string", length=255, nullable=false)
     */
    protected $chemin;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_principale", type="boolean", nullable=false)
     */
    protected $isPrincipale;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     */
    protected $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    protected $updatedAt;

    /**
     * @var \BienImmobilier
     *
     * @ORM\ManyToOne(targetEntity="BienImmobilier")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bien_immobilier_id", referencedColumnName="id")
     * })
     */
    protected $bienImmobilier;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set chemin
     *
     * @param string $chemin
     * @return Photo
     */
    public function setChemin($chemin)
    {
        $this->chemin = $chemin;
    
        return $this;
    }

    /**
     * Get chemin
     *
     * @return string 
     */
    public function getChemin()
    {
        return $this->chemin;
    }

    /**
     * Set isPrincipale
     *
     * @param boolean $isPrincipale
     * @return Photo
     */
    public function setIsPrincipale($isPrincipale)
    {
        $this->isPrincipale = $isPrincipale;
    
        return $this;
    }

    /**
     * Get isPrincipale
     *
     * @return boolean 
     */
    public function getIsPrincipale()
    {
        return $this->isPrincipale;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Photo
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return Photo
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set bienImmobilierId
     *
     * @param int $bienImmobilierId
     * @return Photo
     */
    public function setBienImmobilierId($bienImmobilierId)
    {
        $this->bienImmobilierId = $bienImmobilierId;
    
        return $this;
    }

    /**
     * Get bienImmobilierId
     *
     * @return int
     */
    public function getBienImmobilierId()
    {
        return $this->bienImmobilierId;
    }
    
    public function save(){
        $em = \Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('doctrine')->getManager();
        $em->persist($this);
        $em->flush();
    }
}