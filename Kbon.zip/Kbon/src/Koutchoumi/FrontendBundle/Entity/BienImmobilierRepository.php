<?php

namespace Koutchoumi\FrontendBundleBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Tools\Pagination\Paginator;

/**
 * Description of BienImmobilierRepository
 *
 * @author J
 */
class BienImmobilierRepository extends EntityRepository{
    //put your code here
    public function getBiensImmobiliers($nombreParPage, $page, $criteria){
        if( $page < 1 OR $page > $nb_pages ){
                throw $this->createNotFoundException('Page inexistante (page = '.$page.')');
        }
    }
}

?>
