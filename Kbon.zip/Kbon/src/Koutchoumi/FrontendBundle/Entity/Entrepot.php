<?php
/**
 *Représente une instance d'un BienImmobilier de type entrepôt
 */
namespace Koutchoumi\FrontendBundle\Entity; 

class Entrepot extends BienImmobilier {

	/**
	 * Constructs a new Entrepot class, setting the class_key column to BienImmobilierPeer::CLASSKEY_EN.
	 */
    private $translator;
	public function __construct()
	{
		parent::__construct();
		$this->setClassKey(BienImmobilier::CLASSKEY_ENTREPOT);
                $this->translator=\Koutchoumi\FrontendBundle\KoutchoumiFrontendBundle::getContainer()->get('translator');
	}

        public static function getLibelleTypeBien() {
            return $this->translator->trans("Entrepôt");
        }

        public function getDescription(){
            return $this->getShortDescription();
        }

        public function getShortDescription()
        {
            $shortDes = self::getLibelleTypeBien() ." ". ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()). " - " .$this->getVille()->getNom() . "," .
                    $this->getQuartier()->getNom() . "," . $this->getSecteur() . " - ".
                    number_format($this->getPrix(), 0, '.', ' ') . " FCFA - ". $this->getSurface()." m2";

            return $shortDes;
        }
        
        public function getShortDescriptionWithoutPrice(){
            $shortDes = self::getLibelleTypeBien() ." ". ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction()). " - " .$this->getVille()->getNom() . "," .
                    $this->getQuartier()->getNom() . "," . $this->getSecteur() . " - ". $this->getSurface()." m2";

            return $shortDes;            
        }

        /**
         * Entrepôt à louer - Douala,Bonamoussadi - 80 000 FCFA - 100 m2
         */
        public function getTitle()
        {
            $title = Entrepot::getLibelleTypeBien(). " " .ReferenceData::getTypeLibelleTransaction($this->getTypeTransaction());
            $title .= " " . $this->translator->trans("à %CITY%", array("%CITY%"=>$this->getVille()->getNom())). ', ' . $this->getQuartier()->getNom();
            $title .= " - " . number_format($this->getPrix(), 0, '.', ' ') . ' FCFA';
            $title .= " - " . $this->getSurface() . " m2";
            return $title;
        }

} // Entrepot
